USE VARSITYVAULT2;
GO
-- Run AFTER the completed 2.6.0 migration. Stop the app and back up both databases first.
-- This removes the four obsolete role ID columns to match the shared-key ERD exactly.
SET NOCOUNT ON;
SET XACT_ABORT ON;
IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND name=N'VarsityVaultERDVersion' AND CONVERT(NVARCHAR(50),value)=N'2.7.0')
BEGIN PRINT 'Strict person-key alignment 2.7.0 is already installed.'; RETURN; END;
IF NOT EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND name=N'VarsityVaultERDVersion' AND CONVERT(NVARCHAR(50),value)=N'2.6.0')
 THROW 51100,'Complete the 2.6.0 migration before this shared-key migration.',1;
IF @@TRANCOUNT<>0 THROW 51100,'Use a query connection with no open transaction.',1;
IF DB_ID(N'VarsityVaultSecurity') IS NULL THROW 51100,'VarsityVaultSecurity must be available to retain version-history lookups.',1;
IF COL_LENGTH(N'dbo.LEARNERS',N'LEARNER_ID') IS NULL OR COL_LENGTH(N'dbo.TEACHERS',N'TEACHER_ID') IS NULL
OR COL_LENGTH(N'dbo.ITADMINS',N'ITADMIN_IID') IS NULL OR COL_LENGTH(N'dbo.UNIVERSITY_REPS',N'REP_ID') IS NULL
 THROW 51100,'Some legacy role columns are already missing. Inspect the schema instead of partially reapplying this migration.',1;
BEGIN TRY
 BEGIN TRANSACTION;
 -- The existing PERSON_ID primary keys provide one-to-one maps.
 CREATE TABLE #LearnerMap(oldId INT PRIMARY KEY,personId INT NOT NULL UNIQUE);
 INSERT #LearnerMap EXEC sys.sp_executesql N'SELECT LEARNER_ID,PERSON_ID FROM dbo.LEARNERS WITH (TABLOCKX,HOLDLOCK);';
 CREATE TABLE #TeacherMap(oldId INT PRIMARY KEY,personId INT NOT NULL UNIQUE);
 INSERT #TeacherMap EXEC sys.sp_executesql N'SELECT TEACHER_ID,PERSON_ID FROM dbo.TEACHERS WITH (TABLOCKX,HOLDLOCK);';
 CREATE TABLE #RepMap(oldId INT PRIMARY KEY,personId INT NOT NULL UNIQUE);
 INSERT #RepMap EXEC sys.sp_executesql N'SELECT REP_ID,PERSON_ID FROM dbo.UNIVERSITY_REPS WITH (TABLOCKX,HOLDLOCK);';
 CREATE TABLE #AdminMap(oldId INT PRIMARY KEY,personId INT NOT NULL UNIQUE);
 INSERT #AdminMap EXEC sys.sp_executesql N'SELECT ITADMIN_IID,PERSON_ID FROM dbo.ITADMINS WITH (TABLOCKX,HOLDLOCK);';
 IF EXISTS(SELECT 1 FROM #LearnerMap WHERE oldId<=0 OR personId<=0)
 OR EXISTS(SELECT 1 FROM #TeacherMap WHERE oldId<=0 OR personId<=0)
 OR EXISTS(SELECT 1 FROM #RepMap WHERE oldId<=0 OR personId<=0)
 OR EXISTS(SELECT 1 FROM #AdminMap WHERE oldId<=0 OR personId<=0)
 THROW 51101,'Positive role and person identifiers are required for collision-safe remapping.',1;
 DECLARE @Roles TABLE(TableName SYSNAME PRIMARY KEY,OldColumn SYSNAME,MapTable SYSNAME);
 INSERT @Roles VALUES(N'LEARNERS',N'LEARNER_ID',N'#LearnerMap'),(N'TEACHERS',N'TEACHER_ID',N'#TeacherMap'),
 (N'UNIVERSITY_REPS',N'REP_ID',N'#RepMap'),(N'ITADMINS',N'ITADMIN_IID',N'#AdminMap');
 IF EXISTS(SELECT 1 FROM @Roles r WHERE NOT EXISTS(
 SELECT 1 FROM sys.key_constraints k WHERE k.parent_object_id=OBJECT_ID(N'dbo.'+QUOTENAME(r.TableName)) AND k.type='PK'
 AND (SELECT COUNT(*) FROM sys.index_columns ic WHERE ic.object_id=k.parent_object_id AND ic.index_id=k.unique_index_id AND ic.key_ordinal>0)=1
 AND EXISTS(SELECT 1 FROM sys.index_columns ic JOIN sys.columns c ON c.object_id=ic.object_id AND c.column_id=ic.column_id
 WHERE ic.object_id=k.parent_object_id AND ic.index_id=k.unique_index_id AND ic.key_ordinal=1 AND c.name=N'PERSON_ID')))
 THROW 51102,'The completed 2.6.0 shared PERSON_ID primary keys are required before removing role identities.',1;
 DECLARE @ExpectedRoleRefs TABLE(ChildTable SYSNAME,ChildColumn SYSNAME,ParentTable SYSNAME);
 INSERT @ExpectedRoleRefs VALUES
 (N'APPLICATIONS',N'LEARNER_ID',N'LEARNERS'),(N'APPLICATIONS',N'TEACHER_ID',N'TEACHERS'),
 (N'APPLICATIONS',N'REVIEWED_BY_REP_ID',N'UNIVERSITY_REPS'),(N'DOCUMENTS',N'VERIFIED_BY_TEACHER_ID',N'TEACHERS'),
 (N'LEARNER_RESULTS',N'LEARNER_ID',N'LEARNERS'),(N'LEARNER_RESULTS',N'VERIFIED_BY_TEACHER_ID',N'TEACHERS'),
 (N'LEARNER_SUBJECTS',N'LEARNER_ID',N'LEARNERS');
 IF EXISTS(SELECT 1 FROM @ExpectedRoleRefs e JOIN @Roles r ON r.TableName=e.ParentTable
 WHERE (SELECT COUNT(*) FROM sys.foreign_keys f JOIN sys.foreign_key_columns fc ON fc.constraint_object_id=f.object_id
 JOIN sys.columns cc ON cc.object_id=fc.parent_object_id AND cc.column_id=fc.parent_column_id
 JOIN sys.columns pc ON pc.object_id=fc.referenced_object_id AND pc.column_id=fc.referenced_column_id
 WHERE f.parent_object_id=OBJECT_ID(N'dbo.'+QUOTENAME(e.ChildTable)) AND f.referenced_object_id=OBJECT_ID(N'dbo.'+QUOTENAME(e.ParentTable))
 AND cc.name=e.ChildColumn AND pc.name IN (r.OldColumn,N'PERSON_ID') AND f.is_disabled=0 AND f.is_not_trusted=0
 AND (SELECT COUNT(*) FROM sys.foreign_key_columns x WHERE x.constraint_object_id=f.object_id)=1)<>1)
 THROW 51102,'An expected role foreign key is missing, disabled, untrusted or duplicated. Verify the 2.6.0 schema first.',1;
 DECLARE @References TABLE(FkId INT PRIMARY KEY,ChildTable SYSNAME,ChildColumn SYSNAME,ParentTable SYSNAME,MapTable SYSNAME,DropSql NVARCHAR(MAX),CreateSql NVARCHAR(MAX));
 -- Preserve every FK that currently points to an obsolete role identifier.
 INSERT @References
 SELECT f.object_id,ct.name,cc.name,rt.TableName,rt.MapTable,
 N'ALTER TABLE [dbo].'+QUOTENAME(ct.name)+N' DROP CONSTRAINT '+QUOTENAME(f.name)+N';',
 N'ALTER TABLE [dbo].'+QUOTENAME(ct.name)+N' WITH CHECK ADD CONSTRAINT '+QUOTENAME(f.name)+N' FOREIGN KEY ('+QUOTENAME(cc.name)+N') REFERENCES [dbo].'+QUOTENAME(rt.TableName)+N' ([PERSON_ID])'+
 CASE WHEN f.delete_referential_action=0 THEN N'' ELSE N' ON DELETE '+REPLACE(f.delete_referential_action_desc,N'_',N' ') END+
 CASE WHEN f.update_referential_action=0 THEN N'' ELSE N' ON UPDATE '+REPLACE(f.update_referential_action_desc,N'_',N' ') END+
 CASE WHEN f.is_not_for_replication=1 THEN N' NOT FOR REPLICATION' ELSE N'' END+N';'
 FROM sys.foreign_keys f JOIN sys.foreign_key_columns fc ON fc.constraint_object_id=f.object_id
 JOIN @Roles rt ON f.referenced_object_id=OBJECT_ID(N'dbo.'+QUOTENAME(rt.TableName))
 JOIN sys.columns pc ON pc.object_id=fc.referenced_object_id AND pc.column_id=fc.referenced_column_id AND pc.name=rt.OldColumn
 JOIN sys.tables ct ON ct.object_id=f.parent_object_id AND ct.schema_id=SCHEMA_ID(N'dbo')
 JOIN sys.columns cc ON cc.object_id=fc.parent_object_id AND cc.column_id=fc.parent_column_id;
 IF EXISTS(SELECT 1 FROM @References r WHERE (SELECT COUNT(*) FROM sys.foreign_key_columns fc WHERE fc.constraint_object_id=r.FkId)<>1)
 THROW 51102,'A composite foreign key uses an old role ID. Inspect it before migrating.',1;
 IF EXISTS(SELECT 1 FROM @References WHERE ChildTable NOT IN (N'APPLICATIONS',N'LEARNER_RESULTS',N'LEARNER_SUBJECTS',N'DOCUMENTS'))
 THROW 51102,'An unexpected table references an obsolete role ID. Review that relationship before migration.',1;
 -- Keep the original audit records unchanged. Store the old-to-person mapping and an exact
 -- allowlist of legacy audit IDs so old and new numeric keys can never be confused.
 DECLARE @MapDetail NVARCHAR(MAX)=(SELECT N'2.7.0' AS version,
 JSON_QUERY((SELECT oldId,personId FROM #LearnerMap FOR JSON PATH)) AS learners,
 JSON_QUERY((SELECT oldId,personId FROM #TeacherMap FOR JSON PATH)) AS teachers,
 JSON_QUERY((SELECT oldId,personId FROM #RepMap FOR JSON PATH)) AS representatives,
 JSON_QUERY((SELECT oldId,personId FROM #AdminMap FOR JSON PATH)) AS administrators,
 JSON_QUERY((SELECT AUDIT_ID AS auditId FROM VarsityVaultSecurity.dbo.Audit WITH (TABLOCKX,HOLDLOCK)
 WHERE EVENT IN ('admissions.results','admissions.verification','admissions.binding') FOR JSON PATH)) AS legacyAuditIds
 FOR JSON PATH,WITHOUT_ARRAY_WRAPPER);
 DECLARE @MigrationActor INT=COALESCE((SELECT MIN(PERSON_ID) FROM dbo.ITADMINS),(SELECT MIN(PERSON_ID) FROM dbo.PERSONS));
 IF @MigrationActor IS NULL THROW 51105,'An existing person is required to record this populated-database migration.',1;
 INSERT VarsityVaultSecurity.dbo.Audit(AUDIT_ID,PERSON_ID,EVENT,DETAIL,CREATED_AT)
 VALUES(CONVERT(VARCHAR(36),NEWID()),@MigrationActor,'schema.person-keys',@MapDetail,CONVERT(VARCHAR(27),SYSUTCDATETIME(),126)+'Z');
 DECLARE @Sql NVARCHAR(MAX),@Child SYSNAME,@Column SYSNAME,@Map SYSNAME,@Parent SYSNAME,@OldColumn SYSNAME,@IndexName SYSNAME,@IsConstraint BIT;
 DECLARE validate_refs CURSOR LOCAL FAST_FORWARD FOR SELECT ChildTable,ChildColumn,MapTable FROM @References;
 OPEN validate_refs; FETCH NEXT FROM validate_refs INTO @Child,@Column,@Map;
 WHILE @@FETCH_STATUS=0 BEGIN
  SET @Sql=N'IF EXISTS(SELECT 1 FROM [dbo].'+QUOTENAME(@Child)+N' c LEFT JOIN '+QUOTENAME(@Map)+N' m ON c.'+QUOTENAME(@Column)+N'=m.oldId WHERE c.'+QUOTENAME(@Column)+N' IS NOT NULL AND m.oldId IS NULL) THROW 51103,''A role reference has no person mapping. No rows were deleted.'',1;';
  EXEC sys.sp_executesql @Sql;
  FETCH NEXT FROM validate_refs INTO @Child,@Column,@Map;
 END;
 CLOSE validate_refs; DEALLOCATE validate_refs;
 DECLARE drop_refs CURSOR LOCAL FAST_FORWARD FOR SELECT DropSql FROM @References ORDER BY FkId;
 OPEN drop_refs; FETCH NEXT FROM drop_refs INTO @Sql;
 WHILE @@FETCH_STATUS=0 BEGIN EXEC sys.sp_executesql @Sql; FETCH NEXT FROM drop_refs INTO @Sql; END;
 CLOSE drop_refs; DEALLOCATE drop_refs;
 -- Negative staging avoids unique-key collisions when one old ID equals another person's ID.
 -- Every changed value is checked against the one-to-one map first and restored to a positive person ID.
 DECLARE rekey_refs CURSOR LOCAL FAST_FORWARD FOR SELECT DISTINCT ChildTable,ChildColumn,MapTable FROM @References;
 OPEN rekey_refs; FETCH NEXT FROM rekey_refs INTO @Child,@Column,@Map;
 WHILE @@FETCH_STATUS=0 BEGIN
  SET @Sql=N'UPDATE [dbo].'+QUOTENAME(@Child)+N' SET '+QUOTENAME(@Column)+N'=-'+QUOTENAME(@Column)+N' WHERE '+QUOTENAME(@Column)+N' IS NOT NULL; '+
  N'UPDATE c SET '+QUOTENAME(@Column)+N'=m.personId FROM [dbo].'+QUOTENAME(@Child)+N' c JOIN '+QUOTENAME(@Map)+N' m ON c.'+QUOTENAME(@Column)+N'=-m.oldId;';
  EXEC sys.sp_executesql @Sql;
  FETCH NEXT FROM rekey_refs INTO @Child,@Column,@Map;
 END;
 CLOSE rekey_refs; DEALLOCATE rekey_refs;
 -- Recreate all app views, functions, procedures and triggers with shared-key joins.
 EXEC(N'CREATE OR ALTER FUNCTION dbo.fn_GetLearnerAps (@LearnerId INT, @ExamTypeId INT)
RETURNS INT
AS
BEGIN
    RETURN ISNULL((
        SELECT SUM(al.APS_POINTS)
        FROM LEARNER_RESULTS lr
        JOIN SUBJECTS s ON s.SUBJECT_ID = lr.SUBJECT_ID
        CROSS APPLY (
            SELECT TOP 1 APS_POINTS
            FROM ACHIEVEMENT_LEVELS
            WHERE MIN_PERCENT <= lr.PERCENTAGE
            ORDER BY MIN_PERCENT DESC
        ) al
        WHERE lr.LEARNER_ID = @LearnerId
          AND lr.EXAM_TYPE_ID = @ExamTypeId
          AND s.SUBJECT_CATEGORY <> ''LIFE_ORIENTATION''
    ), 0);
END;');
 EXEC(N'CREATE OR ALTER FUNCTION dbo.fn_GetEligibility (@LearnerId INT, @UniQualId INT, @ExamTypeId INT)
RETURNS VARCHAR(50)
AS
BEGIN
    DECLARE @MinAps INT;
    DECLARE @MinMath DECIMAL(5,2);
    DECLARE @MinEng DECIMAL(5,2);

    SELECT @MinAps = MIN_APS_SCORE, @MinMath = MIN_MATH_SCORE, @MinEng = MIN_ENG_SCORE
    FROM QUALIFICATION_REQUIREMENTS
    WHERE UNI_QUAL_ID = @UniQualId;

    IF @MinAps IS NULL
        RETURN ''Requirements Not Set'';

    IF dbo.fn_GetLearnerAps(@LearnerId, @ExamTypeId) < @MinAps
        RETURN ''Below Minimum APS'';

    IF @MinMath IS NOT NULL AND ISNULL((
        SELECT MAX(lr.PERCENTAGE)
        FROM LEARNER_RESULTS lr
        JOIN SUBJECTS s ON s.SUBJECT_ID = lr.SUBJECT_ID
        WHERE lr.LEARNER_ID = @LearnerId AND lr.EXAM_TYPE_ID = @ExamTypeId AND s.SUBJECT_CATEGORY = ''MATHEMATICS''
    ), 0) < @MinMath
        RETURN ''Below Minimum Subject Requirements'';

    IF @MinEng IS NOT NULL AND ISNULL((
        SELECT MAX(lr.PERCENTAGE)
        FROM LEARNER_RESULTS lr
        JOIN SUBJECTS s ON s.SUBJECT_ID = lr.SUBJECT_ID
        WHERE lr.LEARNER_ID = @LearnerId AND lr.EXAM_TYPE_ID = @ExamTypeId AND s.SUBJECT_NAME LIKE ''English%''
    ), 0) < @MinEng
        RETURN ''Below Minimum Subject Requirements'';

    RETURN ''Meets Minimum Requirements'';
END;');
 EXEC(N'CREATE OR ALTER VIEW VIEW_SCHOOL_DIRECTORY AS
SELECT
    s.SCHOOL_ID,
    s.SCHOOL_NAME,
    s.EMIS_NUMBER,
    c.CITY_NAME,
    pr.PROVINCE_ID,
    pr.PROVINCE_NAME
FROM SCHOOLS s
JOIN PROVINCES pr ON s.PROVINCE_ID = pr.PROVINCE_ID
LEFT JOIN CITIES c ON s.CITY_ID = c.CITY_ID;');
 EXEC(N'CREATE OR ALTER VIEW VIEW_UNIVERSITY_DIRECTORY AS
SELECT
    u.UNIVERSITY_ID,
    u.UNIVERSITY_NAME,
    u.WEBSITE,
    pr.PROVINCE_ID,
    pr.PROVINCE_NAME
FROM UNIVERSITIES u
JOIN PROVINCES pr ON u.PROVINCE_ID = pr.PROVINCE_ID;');
 EXEC(N'CREATE OR ALTER VIEW VIEW_USER_CONTEXT AS
SELECT
    p.PERSON_ID,
    p.USERNAME,
    p.EMAIL,
    CASE
        WHEN r.PERSON_ID IS NOT NULL THEN ''University Rep''
        WHEN t.PERSON_ID IS NOT NULL THEN ''Career Guidance Teacher''
        WHEN ia.PERSON_ID IS NOT NULL THEN ''ITAdmin''
        WHEN l.PERSON_ID IS NOT NULL THEN ''Learner''
    END AS USER_ROLE,
    r.PERSON_ID AS REP_PERSON_ID,
    r.UNIVERSITY_ID AS USER_UNIVERSITY_ID,
    t.PERSON_ID AS TEACHER_PERSON_ID,
    l.PERSON_ID AS LEARNER_ID,
    COALESCE(t.SCHOOL_ID, l.SCHOOL_ID, ia.SCHOOL_ID) AS USER_SCHOOL_ID
FROM PERSONS p
LEFT JOIN UNIVERSITY_REPS r ON r.PERSON_ID = p.PERSON_ID
LEFT JOIN TEACHERS t ON t.PERSON_ID = p.PERSON_ID
LEFT JOIN ITADMINS ia ON ia.PERSON_ID = p.PERSON_ID
LEFT JOIN LEARNERS l ON l.PERSON_ID = p.PERSON_ID;');
 EXEC(N'CREATE OR ALTER VIEW VIEW_LEARNER_RESULTS_DETAIL AS
SELECT
    lr.LEARNER_ID,
    lr.SUBJECT_ID,
    lr.EXAM_TYPE_ID,
    et.EXAM_TYPE_NAME,
    s.SUBJECT_NAME,
    s.SUBJECT_CATEGORY,
    lr.PERCENTAGE,
    al.LEVEL_NO,
    al.APS_POINTS,
    vs.VERIFICATION_STATUS_NAME AS VERIFICATION_STATUS
FROM LEARNER_RESULTS lr
JOIN SUBJECTS s ON s.SUBJECT_ID = lr.SUBJECT_ID
JOIN EXAM_TYPES et ON et.EXAM_TYPE_ID = lr.EXAM_TYPE_ID
LEFT JOIN VERIFICATION_STATUSES vs ON vs.VERIFICATION_STATUS_ID = lr.VERIFICATION_STATUS_ID
OUTER APPLY (
    SELECT TOP 1 LEVEL_NO, APS_POINTS
    FROM ACHIEVEMENT_LEVELS
    WHERE MIN_PERCENT <= lr.PERCENTAGE
    ORDER BY MIN_PERCENT DESC
) al;');
 EXEC(N'CREATE OR ALTER VIEW VIEW_LEARNER_SUBMISSION_CHECK AS
SELECT
    l.PERSON_ID AS LEARNER_ID,
    COUNT(lr.SUBJECT_ID) AS SUBJECT_COUNT,
    MAX(CASE WHEN s.SUBJECT_CATEGORY = ''HOME_LANGUAGE'' THEN 1 ELSE 0 END) AS HAS_HOME_LANGUAGE,
    MAX(CASE WHEN s.SUBJECT_CATEGORY = ''FIRST_ADDITIONAL_LANGUAGE'' THEN 1 ELSE 0 END) AS HAS_FIRST_ADDITIONAL_LANGUAGE,
    MAX(CASE WHEN s.SUBJECT_CATEGORY IN (''MATHEMATICS'', ''MATHEMATICAL_LITERACY'') THEN 1 ELSE 0 END) AS HAS_MATHS_OR_LITERACY,
    MAX(CASE WHEN s.SUBJECT_CATEGORY = ''LIFE_ORIENTATION'' THEN 1 ELSE 0 END) AS HAS_LIFE_ORIENTATION,
    CASE
        WHEN COUNT(lr.SUBJECT_ID) >= 7
         AND MAX(CASE WHEN s.SUBJECT_CATEGORY = ''HOME_LANGUAGE'' THEN 1 ELSE 0 END) = 1
         AND MAX(CASE WHEN s.SUBJECT_CATEGORY = ''FIRST_ADDITIONAL_LANGUAGE'' THEN 1 ELSE 0 END) = 1
         AND MAX(CASE WHEN s.SUBJECT_CATEGORY IN (''MATHEMATICS'', ''MATHEMATICAL_LITERACY'') THEN 1 ELSE 0 END) = 1
         AND MAX(CASE WHEN s.SUBJECT_CATEGORY = ''LIFE_ORIENTATION'' THEN 1 ELSE 0 END) = 1
        THEN 1 ELSE 0
    END AS IS_READY
FROM LEARNERS l
LEFT JOIN EXAM_TYPES et ON et.EXAM_TYPE_NAME = ''Grade 11 Final''
LEFT JOIN LEARNER_RESULTS lr ON lr.LEARNER_ID = l.PERSON_ID AND lr.EXAM_TYPE_ID = et.EXAM_TYPE_ID AND lr.PERCENTAGE IS NOT NULL
LEFT JOIN SUBJECTS s ON s.SUBJECT_ID = lr.SUBJECT_ID
GROUP BY l.PERSON_ID;');
 EXEC(N'CREATE OR ALTER VIEW VIEW_APPLICATION_TIMELINE AS
SELECT
    ap.APP_PROC_ID,
    ap.APPLICATION_ID,
    act.ACTION_NAME AS STATUS_UPDATE,
    ap.ACTION_DATE AS STATUS_DATE
FROM APPLICATION_PROCESSES ap
JOIN ACTIONS act ON ap.ACTION_ID = act.ACTION_ID;');
 EXEC(N'CREATE OR ALTER VIEW VIEW_LEARNER_APPLICATIONS AS
SELECT
    a.APPLICATION_ID,
    a.LEARNER_ID,
    u.UNIVERSITY_NAME AS INSTITUTION,
    pr.PROVINCE_NAME AS PROVINCE,
    p.PROGRAM_NAME AS QUALIFICATION,
    q.QUAL_NAME,
    sm.STUDY_MODE_NAME AS STUDY_MODE,
    a.ACADEMIC_YEAR AS INTAKE_YEAR,
    a.APPLICATION_DATE AS DATE_APPLIED,
    st.STATUS_NAME AS STATUS,
    dbo.fn_GetLearnerAps(a.LEARNER_ID, et.EXAM_TYPE_ID) AS APS_SCORE,
    rq.MIN_APS_SCORE,
    rq.MIN_MATH_SCORE,
    rq.MIN_ENG_SCORE,
    rq.NOTES AS REQUIREMENT_NOTES,
    uq.APPLICATION_CLOSING_DATE AS CLOSING_DATE,
    dbo.fn_GetEligibility(a.LEARNER_ID, a.UNI_QUAL_ID, et.EXAM_TYPE_ID) AS ELIGIBILITY
FROM APPLICATIONS a
JOIN UNI_QUALIFICATIONS uq ON a.UNI_QUAL_ID = uq.UNI_QUAL_ID
JOIN UNIVERSITIES u ON uq.UNIVERSITY_ID = u.UNIVERSITY_ID
JOIN PROVINCES pr ON u.PROVINCE_ID = pr.PROVINCE_ID
JOIN QUALIFICATIONS q ON uq.QUAL_ID = q.QUAL_ID
JOIN PROGRAMS p ON q.PROGRAM_ID = p.PROGRAM_ID
JOIN STUDY_MODES sm ON a.STUDY_MODE_ID = sm.STUDY_MODE_ID
JOIN APPLICATION_STATUSES st ON a.STATUS_ID = st.STATUS_ID
LEFT JOIN QUALIFICATION_REQUIREMENTS rq ON rq.UNI_QUAL_ID = a.UNI_QUAL_ID
CROSS APPLY (
    SELECT TOP 1 EXAM_TYPE_ID
    FROM EXAM_TYPES
    WHERE EXAM_TYPE_NAME = CASE WHEN st.USES_FINAL_RESULTS = 1 THEN ''Grade 12 Final (NSC)'' ELSE ''Grade 11 Final'' END
) et;');
 EXEC(N'CREATE OR ALTER VIEW VIEW_UNIVERSITY_APPLICATIONS AS
SELECT
    a.APPLICATION_ID,
    uq.UNIVERSITY_ID,
    u.UNIVERSITY_NAME,
    a.LEARNER_ID,
    pe.PERSON_ID AS APPLICANT_PERSON_ID,
    pe.FIRST_NAME,
    pe.LAST_NAME,
    p.PROGRAM_NAME,
    q.QUAL_NAME AS QUALIFICATION,
    sm.STUDY_MODE_NAME AS STUDY_MODE,
    a.ACADEMIC_YEAR AS INTAKE_YEAR,
    a.APPLICATION_DATE AS DATE_APPLIED,
    st.STATUS_ID,
    st.STATUS_NAME AS STATUS,
    dbo.fn_GetLearnerAps(a.LEARNER_ID, et.EXAM_TYPE_ID) AS APS_SCORE,
    rq.MIN_APS_SCORE,
    rq.MIN_MATH_SCORE,
    rq.MIN_ENG_SCORE,
    rq.NOTES AS REQUIREMENT_NOTES,
    dbo.fn_GetEligibility(a.LEARNER_ID, a.UNI_QUAL_ID, et.EXAM_TYPE_ID) AS ELIGIBILITY,
    a.REVIEWED_BY_REP_ID,
    a.REVIEW_DATE,
    a.REVIEW_NOTES
FROM APPLICATIONS a
JOIN UNI_QUALIFICATIONS uq ON a.UNI_QUAL_ID = uq.UNI_QUAL_ID
JOIN UNIVERSITIES u ON uq.UNIVERSITY_ID = u.UNIVERSITY_ID
JOIN QUALIFICATIONS q ON uq.QUAL_ID = q.QUAL_ID
JOIN PROGRAMS p ON q.PROGRAM_ID = p.PROGRAM_ID
JOIN STUDY_MODES sm ON a.STUDY_MODE_ID = sm.STUDY_MODE_ID
JOIN LEARNERS l ON a.LEARNER_ID = l.PERSON_ID
JOIN PERSONS pe ON l.PERSON_ID = pe.PERSON_ID
JOIN APPLICATION_STATUSES st ON a.STATUS_ID = st.STATUS_ID
LEFT JOIN QUALIFICATION_REQUIREMENTS rq ON rq.UNI_QUAL_ID = a.UNI_QUAL_ID
CROSS APPLY (
    SELECT TOP 1 EXAM_TYPE_ID
    FROM EXAM_TYPES
    WHERE EXAM_TYPE_NAME = CASE WHEN st.USES_FINAL_RESULTS = 1 THEN ''Grade 12 Final (NSC)'' ELSE ''Grade 11 Final'' END
) et;');
 EXEC(N'CREATE OR ALTER PROCEDURE usp_SubmitApplication
    @LearnerId INT,
    @UniQualId INT,
    @StudyModeId INT,
    @AcademicYear SMALLINT,
    @ApplicationId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @PersonId INT;
    DECLARE @ClosingDate DATE;
    DECLARE @SubmittedId INT;

    SELECT @PersonId = PERSON_ID FROM LEARNERS WHERE PERSON_ID = @LearnerId;
    SELECT @SubmittedId = STATUS_ID FROM APPLICATION_STATUSES WHERE STATUS_NAME = ''Submitted'';
    SELECT @ClosingDate = APPLICATION_CLOSING_DATE FROM UNI_QUALIFICATIONS WHERE UNI_QUAL_ID = @UniQualId;

    IF @PersonId IS NULL
        THROW 50001, ''Learner not found.'', 1;

    IF NOT EXISTS (SELECT 1 FROM VIEW_LEARNER_SUBMISSION_CHECK WHERE LEARNER_ID = @LearnerId AND IS_READY = 1)
        THROW 50002, ''Grade 11 results are incomplete. Capture at least 7 subjects including Home Language, First Additional Language, Mathematics or Mathematical Literacy, and Life Orientation.'', 1;

    IF EXISTS (
        SELECT 1 FROM DOCUMENT_TYPES dt
        WHERE dt.IS_MANDATORY = 1
          AND NOT EXISTS (SELECT 1 FROM DOCUMENTS d WHERE d.PERSON_ID = @PersonId AND d.DOCUMENT_TYPE_ID = dt.DOCUMENT_TYPE_ID)
    )
        THROW 50003, ''Mandatory documents are missing. Upload the Grade 11 Final Report and a certified copy of your ID.'', 1;

    IF @ClosingDate IS NOT NULL AND @ClosingDate < CAST(GETDATE() AS DATE)
        THROW 50004, ''Applications for this qualification are closed.'', 1;

    IF EXISTS (SELECT 1 FROM APPLICATIONS WHERE LEARNER_ID = @LearnerId AND UNI_QUAL_ID = @UniQualId AND ACADEMIC_YEAR = @AcademicYear)
        THROW 50005, ''You have already applied for this qualification in this intake year.'', 1;

    BEGIN TRANSACTION;

    INSERT INTO APPLICATIONS (APPLICATION_DATE, ACADEMIC_YEAR, STUDY_MODE_ID, UNI_QUAL_ID, LEARNER_ID, STATUS_ID)
    VALUES (CONVERT(VARCHAR(10), GETDATE(), 23), @AcademicYear, @StudyModeId, @UniQualId, @LearnerId, @SubmittedId);

    SET @ApplicationId = SCOPE_IDENTITY();

    INSERT INTO APPLICATION_PROCESSES (APPLICATION_ID, ACTION_ID, ACTION_DATE)
    SELECT @ApplicationId, ACTION_ID, CONVERT(VARCHAR(10), GETDATE(), 23)
    FROM ACTIONS
    WHERE ACTION_NAME = ''Submitted'';

    COMMIT TRANSACTION;
END;');
 EXEC(N'CREATE OR ALTER PROCEDURE usp_ScreenApplication
    @ApplicationId INT,
    @TeacherId INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @SubmittedId INT;
    DECLARE @ScreenedId INT;

    SELECT @SubmittedId = STATUS_ID FROM APPLICATION_STATUSES WHERE STATUS_NAME = ''Submitted'';
    SELECT @ScreenedId = STATUS_ID FROM APPLICATION_STATUSES WHERE STATUS_NAME = ''Screened by Career Teacher'';

    IF NOT EXISTS (
        SELECT 1
        FROM APPLICATIONS a
        JOIN LEARNERS l ON l.PERSON_ID = a.LEARNER_ID
        JOIN TEACHERS t ON t.SCHOOL_ID = l.SCHOOL_ID
        WHERE a.APPLICATION_ID = @ApplicationId AND t.PERSON_ID = @TeacherId AND a.STATUS_ID = @SubmittedId
    )
        THROW 50020, ''Application not found, not in Submitted status, or the learner is not at this teacher''''s school.'', 1;

    BEGIN TRANSACTION;

    UPDATE APPLICATIONS
    SET STATUS_ID = @ScreenedId, TEACHER_ID = @TeacherId
    WHERE APPLICATION_ID = @ApplicationId;

    INSERT INTO APPLICATION_PROCESSES (APPLICATION_ID, ACTION_ID, ACTION_DATE)
    SELECT @ApplicationId, ACTION_ID, CONVERT(VARCHAR(10), GETDATE(), 23)
    FROM ACTIONS
    WHERE ACTION_NAME = ''Screened by Career Teacher'';

    COMMIT TRANSACTION;
END;');
 EXEC(N'CREATE OR ALTER PROCEDURE usp_ReviewApplication
    @ApplicationId INT,
    @RepId INT,
    @Decision VARCHAR(50),
    @Notes VARCHAR(400) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @ScreenedId INT;
    DECLARE @DecisionStatusId INT;

    SELECT @ScreenedId = STATUS_ID FROM APPLICATION_STATUSES WHERE STATUS_NAME = ''Screened by Career Teacher'';
    SELECT @DecisionStatusId = STATUS_ID FROM APPLICATION_STATUSES WHERE STATUS_NAME = @Decision;

    IF @Decision NOT IN (''Provisionally Accepted'', ''Rejected'')
        THROW 50030, ''Decision must be Provisionally Accepted or Rejected.'', 1;

    IF NOT EXISTS (
        SELECT 1
        FROM APPLICATIONS a
        JOIN UNI_QUALIFICATIONS uq ON uq.UNI_QUAL_ID = a.UNI_QUAL_ID
        JOIN UNIVERSITY_REPS r ON r.UNIVERSITY_ID = uq.UNIVERSITY_ID
        WHERE a.APPLICATION_ID = @ApplicationId AND r.PERSON_ID = @RepId AND a.STATUS_ID = @ScreenedId
    )
        THROW 50031, ''Application not found, not yet screened by a Career Guidance Teacher, or not for this representative''''s university.'', 1;

    BEGIN TRANSACTION;

    UPDATE APPLICATIONS
    SET STATUS_ID = @DecisionStatusId,
        REVIEWED_BY_REP_ID = @RepId,
        REVIEW_DATE = CONVERT(VARCHAR(10), GETDATE(), 23),
        REVIEW_NOTES = @Notes
    WHERE APPLICATION_ID = @ApplicationId;

    INSERT INTO APPLICATION_PROCESSES (APPLICATION_ID, ACTION_ID, ACTION_DATE)
    SELECT @ApplicationId, ACTION_ID, CONVERT(VARCHAR(10), GETDATE(), 23)
    FROM ACTIONS
    WHERE ACTION_NAME = @Decision;

    COMMIT TRANSACTION;
END;');
 EXEC(N'CREATE OR ALTER TRIGGER TRG_DOCUMENTS_LOCK_FINAL ON DOCUMENTS
AFTER INSERT
AS
BEGIN
    IF EXISTS (
        SELECT 1
        FROM inserted i
        JOIN DOCUMENT_TYPES dt ON dt.DOCUMENT_TYPE_ID = i.DOCUMENT_TYPE_ID
        WHERE dt.IS_LOCKED_UNTIL_FINAL = 1
          AND NOT EXISTS (
              SELECT 1
              FROM APPLICATIONS a
              JOIN LEARNERS l ON l.PERSON_ID = a.LEARNER_ID
              JOIN APPLICATION_STATUSES st ON st.STATUS_ID = a.STATUS_ID
              WHERE l.PERSON_ID = i.PERSON_ID
                AND st.STATUS_NAME IN (''Provisionally Accepted'', ''Final Matric Verified'', ''Admitted'', ''Offer Revoked'')
          )
    )
    BEGIN
        ROLLBACK TRANSACTION;
        THROW 50010, ''The Final NSC Certificate can only be uploaded after provisional acceptance.'', 1;
    END
END;');
 EXEC(N'CREATE OR ALTER TRIGGER dbo.TRG_PERSONS_ROLE ON dbo.PERSONS AFTER INSERT, UPDATE AS
BEGIN
 SET NOCOUNT ON;
 IF EXISTS(SELECT 1 FROM inserted i JOIN deleted d ON i.PERSON_ID=d.PERSON_ID WHERE i.PERSON_TYPE<>d.PERSON_TYPE)
  THROW 51010, ''Person type cannot be changed independently of its subtype.'', 1;
 -- New people must receive their mandatory subtype within this same statement.
 DECLARE @SchoolId INT=TRY_CONVERT(INT,SESSION_CONTEXT(N''VV_SCHOOL_ID'')),
         @UniversityId INT=TRY_CONVERT(INT,SESSION_CONTEXT(N''VV_UNIVERSITY_ID''));
 IF EXISTS(SELECT 1 FROM inserted i LEFT JOIN deleted d ON d.PERSON_ID=i.PERSON_ID
           WHERE d.PERSON_ID IS NULL AND ((i.PERSON_TYPE=''R'' AND @UniversityId IS NULL) OR (i.PERSON_TYPE<>''R'' AND @SchoolId IS NULL)))
  THROW 51011, ''Create a person with dbo.usp_CreatePersonWithRole and a school or university.'', 1;
 INSERT dbo.LEARNERS(PERSON_ID,SCHOOL_ID)
 SELECT i.PERSON_ID,@SchoolId FROM inserted i LEFT JOIN deleted d ON d.PERSON_ID=i.PERSON_ID WHERE d.PERSON_ID IS NULL AND i.PERSON_TYPE=''L'';
 INSERT dbo.TEACHERS(PERSON_ID,SCHOOL_ID,DEPARTMENT,DESIGNATION)
 SELECT i.PERSON_ID,@SchoolId,''Career Guidance'',''Career Guidance Teacher'' FROM inserted i LEFT JOIN deleted d ON d.PERSON_ID=i.PERSON_ID WHERE d.PERSON_ID IS NULL AND i.PERSON_TYPE=''T'';
 INSERT dbo.ITADMINS(PERSON_ID,SCHOOL_ID)
 SELECT i.PERSON_ID,@SchoolId FROM inserted i LEFT JOIN deleted d ON d.PERSON_ID=i.PERSON_ID WHERE d.PERSON_ID IS NULL AND i.PERSON_TYPE=''A'';
 INSERT dbo.UNIVERSITY_REPS(PERSON_ID,UNIVERSITY_ID)
 SELECT i.PERSON_ID,@UniversityId FROM inserted i LEFT JOIN deleted d ON d.PERSON_ID=i.PERSON_ID WHERE d.PERSON_ID IS NULL AND i.PERSON_TYPE=''R'';
END;');
 EXEC(N'CREATE OR ALTER TRIGGER dbo.TRG_LEARNERS_ROLE ON dbo.LEARNERS AFTER INSERT, UPDATE, DELETE AS
BEGIN
 SET NOCOUNT ON;
 -- Lock the common parent to serialize concurrent membership changes.
 DECLARE @LockId INT;
 SELECT @LockId=p.PERSON_ID FROM dbo.PERSONS p WITH (UPDLOCK,HOLDLOCK)
 JOIN (SELECT PERSON_ID FROM inserted UNION SELECT PERSON_ID FROM deleted) a ON a.PERSON_ID=p.PERSON_ID;
 IF EXISTS(SELECT 1 FROM dbo.PERSONS p
 JOIN (SELECT PERSON_ID FROM inserted UNION SELECT PERSON_ID FROM deleted) a ON a.PERSON_ID=p.PERSON_ID
 OUTER APPLY(SELECT COUNT(*) AS n,MIN(r.PERSON_TYPE) AS t FROM (SELECT PERSON_ID,''L'' AS PERSON_TYPE FROM dbo.LEARNERS UNION ALL SELECT PERSON_ID,''T'' AS PERSON_TYPE FROM dbo.TEACHERS UNION ALL SELECT PERSON_ID,''A'' AS PERSON_TYPE FROM dbo.ITADMINS UNION ALL SELECT PERSON_ID,''R'' AS PERSON_TYPE FROM dbo.UNIVERSITY_REPS) r WHERE r.PERSON_ID=p.PERSON_ID) x
 WHERE x.n<>1 OR x.t<>p.PERSON_TYPE)
 THROW 51012, ''Each person must have exactly one matching learner, teacher, administrator or representative subtype.'', 1;
END;');
 EXEC(N'CREATE OR ALTER TRIGGER dbo.TRG_TEACHERS_ROLE ON dbo.TEACHERS AFTER INSERT, UPDATE, DELETE AS
BEGIN
 SET NOCOUNT ON;
 -- Lock the common parent to serialize concurrent membership changes.
 DECLARE @LockId INT;
 SELECT @LockId=p.PERSON_ID FROM dbo.PERSONS p WITH (UPDLOCK,HOLDLOCK)
 JOIN (SELECT PERSON_ID FROM inserted UNION SELECT PERSON_ID FROM deleted) a ON a.PERSON_ID=p.PERSON_ID;
 IF EXISTS(SELECT 1 FROM dbo.PERSONS p
 JOIN (SELECT PERSON_ID FROM inserted UNION SELECT PERSON_ID FROM deleted) a ON a.PERSON_ID=p.PERSON_ID
 OUTER APPLY(SELECT COUNT(*) AS n,MIN(r.PERSON_TYPE) AS t FROM (SELECT PERSON_ID,''L'' AS PERSON_TYPE FROM dbo.LEARNERS UNION ALL SELECT PERSON_ID,''T'' AS PERSON_TYPE FROM dbo.TEACHERS UNION ALL SELECT PERSON_ID,''A'' AS PERSON_TYPE FROM dbo.ITADMINS UNION ALL SELECT PERSON_ID,''R'' AS PERSON_TYPE FROM dbo.UNIVERSITY_REPS) r WHERE r.PERSON_ID=p.PERSON_ID) x
 WHERE x.n<>1 OR x.t<>p.PERSON_TYPE)
 THROW 51012, ''Each person must have exactly one matching learner, teacher, administrator or representative subtype.'', 1;
END;');
 EXEC(N'CREATE OR ALTER TRIGGER dbo.TRG_ITADMINS_ROLE ON dbo.ITADMINS AFTER INSERT, UPDATE, DELETE AS
BEGIN
 SET NOCOUNT ON;
 -- Lock the common parent to serialize concurrent membership changes.
 DECLARE @LockId INT;
 SELECT @LockId=p.PERSON_ID FROM dbo.PERSONS p WITH (UPDLOCK,HOLDLOCK)
 JOIN (SELECT PERSON_ID FROM inserted UNION SELECT PERSON_ID FROM deleted) a ON a.PERSON_ID=p.PERSON_ID;
 IF EXISTS(SELECT 1 FROM dbo.PERSONS p
 JOIN (SELECT PERSON_ID FROM inserted UNION SELECT PERSON_ID FROM deleted) a ON a.PERSON_ID=p.PERSON_ID
 OUTER APPLY(SELECT COUNT(*) AS n,MIN(r.PERSON_TYPE) AS t FROM (SELECT PERSON_ID,''L'' AS PERSON_TYPE FROM dbo.LEARNERS UNION ALL SELECT PERSON_ID,''T'' AS PERSON_TYPE FROM dbo.TEACHERS UNION ALL SELECT PERSON_ID,''A'' AS PERSON_TYPE FROM dbo.ITADMINS UNION ALL SELECT PERSON_ID,''R'' AS PERSON_TYPE FROM dbo.UNIVERSITY_REPS) r WHERE r.PERSON_ID=p.PERSON_ID) x
 WHERE x.n<>1 OR x.t<>p.PERSON_TYPE)
 THROW 51012, ''Each person must have exactly one matching learner, teacher, administrator or representative subtype.'', 1;
END;');
 EXEC(N'CREATE OR ALTER TRIGGER dbo.TRG_UNIVERSITY_REPS_ROLE ON dbo.UNIVERSITY_REPS AFTER INSERT, UPDATE, DELETE AS
BEGIN
 SET NOCOUNT ON;
 -- Lock the common parent to serialize concurrent membership changes.
 DECLARE @LockId INT;
 SELECT @LockId=p.PERSON_ID FROM dbo.PERSONS p WITH (UPDLOCK,HOLDLOCK)
 JOIN (SELECT PERSON_ID FROM inserted UNION SELECT PERSON_ID FROM deleted) a ON a.PERSON_ID=p.PERSON_ID;
 IF EXISTS(SELECT 1 FROM dbo.PERSONS p
 JOIN (SELECT PERSON_ID FROM inserted UNION SELECT PERSON_ID FROM deleted) a ON a.PERSON_ID=p.PERSON_ID
 OUTER APPLY(SELECT COUNT(*) AS n,MIN(r.PERSON_TYPE) AS t FROM (SELECT PERSON_ID,''L'' AS PERSON_TYPE FROM dbo.LEARNERS UNION ALL SELECT PERSON_ID,''T'' AS PERSON_TYPE FROM dbo.TEACHERS UNION ALL SELECT PERSON_ID,''A'' AS PERSON_TYPE FROM dbo.ITADMINS UNION ALL SELECT PERSON_ID,''R'' AS PERSON_TYPE FROM dbo.UNIVERSITY_REPS) r WHERE r.PERSON_ID=p.PERSON_ID) x
 WHERE x.n<>1 OR x.t<>p.PERSON_TYPE)
 THROW 51012, ''Each person must have exactly one matching learner, teacher, administrator or representative subtype.'', 1;
END;');
 EXEC(N'CREATE OR ALTER PROCEDURE dbo.usp_CreatePersonWithRole
 @FIRST_NAME VARCHAR(100), @LAST_NAME VARCHAR(100), @EMAIL VARCHAR(255), @USERNAME VARCHAR(100),
 @PHONE_NUMBER VARCHAR(10)=NULL, @SA_ID_NUMBER VARCHAR(13)=NULL,
 @PERSON_TYPE VARCHAR(1)=NULL, @SCHOOL_ID INT=NULL, @UNIVERSITY_ID INT=NULL
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 IF @PERSON_TYPE IS NULL OR @PERSON_TYPE NOT IN (''L'',''T'',''A'',''R'') THROW 51013,''Choose L, T, A or R.'',1;
 IF (@PERSON_TYPE=''R'' AND NOT EXISTS(SELECT 1 FROM dbo.UNIVERSITIES WHERE UNIVERSITY_ID=@UNIVERSITY_ID))
 OR (@PERSON_TYPE<>''R'' AND NOT EXISTS(SELECT 1 FROM dbo.SCHOOLS WHERE SCHOOL_ID=@SCHOOL_ID))
 THROW 51014,''Choose an existing school or university.'',1;
 DECLARE @Own BIT=CASE WHEN @@TRANCOUNT=0 THEN 1 ELSE 0 END, @PersonId INT;
 BEGIN TRY
  IF @Own=1 BEGIN TRANSACTION;
  EXEC sys.sp_set_session_context @key=N''VV_SCHOOL_ID'',@value=@SCHOOL_ID;
  EXEC sys.sp_set_session_context @key=N''VV_UNIVERSITY_ID'',@value=@UNIVERSITY_ID;
  INSERT dbo.PERSONS(FIRST_NAME,LAST_NAME,EMAIL,USERNAME,PHONE_NUMBER,SA_ID_NUMBER,PERSON_TYPE)
  VALUES(@FIRST_NAME,@LAST_NAME,@EMAIL,@USERNAME,@PHONE_NUMBER,@SA_ID_NUMBER,@PERSON_TYPE);
  SET @PersonId=CONVERT(INT,SCOPE_IDENTITY());
  EXEC sys.sp_set_session_context @key=N''VV_SCHOOL_ID'',@value=NULL;
  EXEC sys.sp_set_session_context @key=N''VV_UNIVERSITY_ID'',@value=NULL;
  IF @Own=1 COMMIT;
  SELECT * FROM dbo.PERSONS WHERE PERSON_ID=@PersonId;
 END TRY
 BEGIN CATCH
  EXEC sys.sp_set_session_context @key=N''VV_SCHOOL_ID'',@value=NULL;
  EXEC sys.sp_set_session_context @key=N''VV_UNIVERSITY_ID'',@value=NULL;
  IF @Own=1 AND XACT_STATE()<>0 ROLLBACK;
  THROW;
 END CATCH
END;');
 EXEC(N'CREATE OR ALTER TRIGGER dbo.TRG_SCHOOLS_GEOGRAPHY ON dbo.SCHOOLS AFTER INSERT,UPDATE AS
BEGIN
 SET NOCOUNT ON;
 IF EXISTS(SELECT 1 FROM inserted s JOIN dbo.CITIES c ON c.CITY_ID=s.CITY_ID WHERE c.PROVINCE_ID<>s.PROVINCE_ID)
 THROW 51015,''The school province must match the city province.'',1;
END;');
 EXEC(N'CREATE OR ALTER TRIGGER dbo.TRG_CITIES_GEOGRAPHY ON dbo.CITIES AFTER UPDATE AS
BEGIN
 SET NOCOUNT ON;
 IF EXISTS(SELECT 1 FROM inserted c JOIN dbo.SCHOOLS s ON s.CITY_ID=c.CITY_ID WHERE s.PROVINCE_ID<>c.PROVINCE_ID)
 THROW 51015,''This city is used by a school in a different province.'',1;
END;');
 -- Remove only indexes/unique constraints that depend on a removed role column.
 -- A unique key on other columns with the old ID merely included requires manual review.
 IF EXISTS(SELECT 1 FROM @Roles r JOIN sys.indexes i ON i.object_id=OBJECT_ID(N'dbo.'+QUOTENAME(r.TableName))
 JOIN sys.index_columns ic ON ic.object_id=i.object_id AND ic.index_id=i.index_id
 JOIN sys.columns c ON c.object_id=ic.object_id AND c.column_id=ic.column_id
 WHERE c.name=r.OldColumn AND ic.is_included_column=1 AND i.is_unique=1)
 THROW 51104,'An old ID is included in another unique index. Preserve that unique key before continuing.',1;
 DECLARE old_indexes CURSOR LOCAL FAST_FORWARD FOR
 SELECT DISTINCT r.TableName,i.name,i.is_unique_constraint
 FROM @Roles r JOIN sys.indexes i ON i.object_id=OBJECT_ID(N'dbo.'+QUOTENAME(r.TableName))
 JOIN sys.index_columns ic ON ic.object_id=i.object_id AND ic.index_id=i.index_id
 JOIN sys.columns c ON c.object_id=ic.object_id AND c.column_id=ic.column_id
 WHERE c.name=r.OldColumn AND i.is_primary_key=0;
 OPEN old_indexes; FETCH NEXT FROM old_indexes INTO @Parent,@IndexName,@IsConstraint;
 WHILE @@FETCH_STATUS=0 BEGIN
  SET @Sql=CASE WHEN @IsConstraint=1 THEN N'ALTER TABLE [dbo].'+QUOTENAME(@Parent)+N' DROP CONSTRAINT '+QUOTENAME(@IndexName)+N';'
  ELSE N'DROP INDEX '+QUOTENAME(@IndexName)+N' ON [dbo].'+QUOTENAME(@Parent)+N';' END;
  EXEC sys.sp_executesql @Sql;
  FETCH NEXT FROM old_indexes INTO @Parent,@IndexName,@IsConstraint;
 END;
 CLOSE old_indexes; DEALLOCATE old_indexes;
 DECLARE old_columns CURSOR LOCAL FAST_FORWARD FOR SELECT TableName,OldColumn FROM @Roles;
 OPEN old_columns; FETCH NEXT FROM old_columns INTO @Parent,@OldColumn;
 WHILE @@FETCH_STATUS=0 BEGIN
  SET @Sql=N'ALTER TABLE [dbo].'+QUOTENAME(@Parent)+N' DROP COLUMN '+QUOTENAME(@OldColumn)+N';';
  EXEC sys.sp_executesql @Sql;
  FETCH NEXT FROM old_columns INTO @Parent,@OldColumn;
 END;
 CLOSE old_columns; DEALLOCATE old_columns;
 DECLARE create_refs CURSOR LOCAL FAST_FORWARD FOR SELECT CreateSql FROM @References ORDER BY FkId;
 OPEN create_refs; FETCH NEXT FROM create_refs INTO @Sql;
 WHILE @@FETCH_STATUS=0 BEGIN EXEC sys.sp_executesql @Sql; FETCH NEXT FROM create_refs INTO @Sql; END;
 CLOSE create_refs; DEALLOCATE create_refs;
 -- Existing sign-in accounts and passwords stay intact; fresh sessions load the new role IDs.
 DELETE FROM VarsityVaultSecurity.dbo.Sessions;
 EXEC sys.sp_updateextendedproperty @name=N'VarsityVaultERDVersion',@value=N'2.7.0';
 DROP TABLE #LearnerMap; DROP TABLE #TeacherMap; DROP TABLE #RepMap; DROP TABLE #AdminMap;
 COMMIT;
 PRINT 'Strict person-key alignment 2.7.0 completed. Role tables now use PERSON_ID only. Install the 2.7.0 app and sign in again.';
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK;
 THROW;
END CATCH;
GO
