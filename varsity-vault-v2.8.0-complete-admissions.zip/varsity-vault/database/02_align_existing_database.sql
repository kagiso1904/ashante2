USE VARSITYVAULT2;
GO
-- Corrected 2026-10-27: preserve dependent indexes and foreign keys during NOT NULL changes.
-- Corrected 2026-10-27: post-rename column checks execute in a separately compiled batch.
-- Upgrade existing data; never rerun the original CREATE DATABASE script against a populated DB.
-- Stop the app and take a full database backup in SSMS first.
SET NOCOUNT ON;
SET XACT_ABORT ON;
IF EXISTS(SELECT 1 FROM sys.extended_properties WHERE class=0 AND name=N'VarsityVaultERDVersion' AND CONVERT(NVARCHAR(50),value)=N'2.6.0')
BEGIN PRINT 'ERD alignment 2.6.0 is already installed.'; RETURN; END;
IF COL_LENGTH('dbo.PERSONS','PERSON_TYPE') IS NOT NULL OR COL_LENGTH('dbo.CITIES','PROVINCE_ID') IS NOT NULL
 THROW 51000,'This is not the expected pre-alignment schema. Inspect existing changes rather than applying a partial upgrade.',1;
IF @@TRANCOUNT <> 0
 THROW 51007,'An existing transaction is open in this query session. Resolve it or use a fresh connection before running this migration.',1;
IF OBJECT_ID(N'dbo.usp_AlignRequiredIntColumn', N'P') IS NOT NULL
 THROW 51009,'The temporary migration helper name is already in use. Inspect that procedure before continuing.',1;
BEGIN TRY
 BEGIN TRANSACTION;
-- Capture and rebuild indexes/foreign keys around nullable-to-required changes.
EXEC(N'CREATE PROCEDURE dbo.usp_AlignRequiredIntColumn
 @TableName SYSNAME,
 @ColumnName SYSNAME
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @ObjectId INT=OBJECT_ID(N''dbo.''+QUOTENAME(@TableName),N''U''),@ColumnId INT,@Nullable BIT;
 SELECT @ColumnId=column_id,@Nullable=is_nullable FROM sys.columns WHERE object_id=@ObjectId AND name=@ColumnName;
 IF @ColumnId IS NULL THROW 51008,''A required migration column is missing.'',1;
 IF @Nullable=0 RETURN;
 IF NOT EXISTS(SELECT 1 FROM sys.columns WHERE object_id=@ObjectId AND column_id=@ColumnId AND system_type_id=56)
  THROW 51008,''The required-column helper only supports existing INT columns.'',1;
 DECLARE @Target NVARCHAR(520)=N''[dbo].''+QUOTENAME(@TableName),@Sql NVARCHAR(MAX);
 DECLARE @Indexes TABLE(IndexId INT PRIMARY KEY,DropSql NVARCHAR(MAX),CreateSql NVARCHAR(MAX),DisableSql NVARCHAR(MAX));
 INSERT @Indexes(IndexId,DropSql,CreateSql,DisableSql)
 SELECT i.index_id,
 CASE WHEN i.is_unique_constraint=1 THEN N''ALTER TABLE ''+@Target+N'' DROP CONSTRAINT ''+QUOTENAME(i.name)+N'';''
 ELSE N''DROP INDEX ''+QUOTENAME(i.name)+N'' ON ''+@Target+N'';'' END,
 CASE WHEN i.is_unique_constraint=1 THEN N''ALTER TABLE ''+@Target+N'' ADD CONSTRAINT ''+QUOTENAME(i.name)+N'' UNIQUE ''
 ELSE N''CREATE ''+CASE WHEN i.is_unique=1 THEN N''UNIQUE '' ELSE N'''' END END+
 CASE WHEN i.type=1 THEN N''CLUSTERED '' ELSE N''NONCLUSTERED '' END+
 CASE WHEN i.is_unique_constraint=1 THEN N'''' ELSE N''INDEX ''+QUOTENAME(i.name)+N'' ON ''+@Target+N'' '' END+
 N''(''+k.KeyColumns+N'')''+
 CASE WHEN i.is_unique_constraint=0 AND inc.IncludedColumns IS NOT NULL THEN N'' INCLUDE (''+inc.IncludedColumns+N'')'' ELSE N'''' END+
 CASE WHEN i.has_filter=1 THEN N'' WHERE ''+i.filter_definition ELSE N'''' END+
 N'' WITH (PAD_INDEX=''+CASE WHEN i.is_padded=1 THEN N''ON'' ELSE N''OFF'' END+
 N'', FILLFACTOR=''+CONVERT(NVARCHAR(3),CASE WHEN i.fill_factor=0 THEN 100 ELSE i.fill_factor END)+
 N'', IGNORE_DUP_KEY=''+CASE WHEN i.ignore_dup_key=1 THEN N''ON'' ELSE N''OFF'' END+
 N'', ALLOW_ROW_LOCKS=''+CASE WHEN i.allow_row_locks=1 THEN N''ON'' ELSE N''OFF'' END+
 N'', ALLOW_PAGE_LOCKS=''+CASE WHEN i.allow_page_locks=1 THEN N''ON'' ELSE N''OFF'' END+N'') ON ''+QUOTENAME(ds.name)+N'';'',
 CASE WHEN i.is_disabled=1 THEN N''ALTER INDEX ''+QUOTENAME(i.name)+N'' ON ''+@Target+N'' DISABLE;'' ELSE NULL END
 FROM sys.indexes i
 JOIN sys.data_spaces ds ON ds.data_space_id=i.data_space_id
 CROSS APPLY(SELECT STUFF((SELECT N'',''+QUOTENAME(c.name)+CASE WHEN ic.is_descending_key=1 THEN N'' DESC'' ELSE N'' ASC'' END
   FROM sys.index_columns ic JOIN sys.columns c ON c.object_id=ic.object_id AND c.column_id=ic.column_id
   WHERE ic.object_id=i.object_id AND ic.index_id=i.index_id AND ic.key_ordinal>0
   ORDER BY ic.key_ordinal FOR XML PATH(''''),TYPE).value(''.'',''nvarchar(max)''),1,1,N'''') AS KeyColumns)k
 CROSS APPLY(SELECT STUFF((SELECT N'',''+QUOTENAME(c.name)
   FROM sys.index_columns ic JOIN sys.columns c ON c.object_id=ic.object_id AND c.column_id=ic.column_id
   WHERE ic.object_id=i.object_id AND ic.index_id=i.index_id AND ic.is_included_column=1
   ORDER BY ic.index_column_id FOR XML PATH(''''),TYPE).value(''.'',''nvarchar(max)''),1,1,N'''') AS IncludedColumns)inc
 WHERE i.object_id=@ObjectId AND i.is_primary_key=0 AND i.type IN (1,2) AND ds.type=''FG'' AND i.is_hypothetical=0;
 -- Preserve foreign keys that touch the column, or use an index being rebuilt.
 DECLARE @ForeignKeys TABLE(FkId INT PRIMARY KEY,DropSql NVARCHAR(MAX),CreateSql NVARCHAR(MAX),DisableSql NVARCHAR(MAX));
 INSERT @ForeignKeys(FkId,DropSql,CreateSql,DisableSql)
 SELECT f.object_id,
 N''ALTER TABLE ''+QUOTENAME(OBJECT_SCHEMA_NAME(f.parent_object_id))+N''.''+QUOTENAME(OBJECT_NAME(f.parent_object_id))+N'' DROP CONSTRAINT ''+QUOTENAME(f.name)+N'';'',
 N''ALTER TABLE ''+QUOTENAME(OBJECT_SCHEMA_NAME(f.parent_object_id))+N''.''+QUOTENAME(OBJECT_NAME(f.parent_object_id))+
 CASE WHEN f.is_not_trusted=0 THEN N'' WITH CHECK'' ELSE N'' WITH NOCHECK'' END+
 N'' ADD CONSTRAINT ''+QUOTENAME(f.name)+N'' FOREIGN KEY (''+pc.ColumnList+N'') REFERENCES ''+
 QUOTENAME(OBJECT_SCHEMA_NAME(f.referenced_object_id))+N''.''+QUOTENAME(OBJECT_NAME(f.referenced_object_id))+N'' (''+rc.ColumnList+N'')''+
 CASE WHEN f.delete_referential_action=0 THEN N'''' ELSE N'' ON DELETE ''+REPLACE(f.delete_referential_action_desc,N''_'',N'' '') END+
 CASE WHEN f.update_referential_action=0 THEN N'''' ELSE N'' ON UPDATE ''+REPLACE(f.update_referential_action_desc,N''_'',N'' '') END+
 CASE WHEN f.is_not_for_replication=1 THEN N'' NOT FOR REPLICATION'' ELSE N'''' END+N'';'',
 CASE WHEN f.is_disabled=1 THEN N''ALTER TABLE ''+QUOTENAME(OBJECT_SCHEMA_NAME(f.parent_object_id))+N''.''+QUOTENAME(OBJECT_NAME(f.parent_object_id))+N'' NOCHECK CONSTRAINT ''+QUOTENAME(f.name)+N'';'' ELSE NULL END
 FROM sys.foreign_keys f
 CROSS APPLY(SELECT STUFF((SELECT N'',''+QUOTENAME(c.name) FROM sys.foreign_key_columns fc
   JOIN sys.columns c ON c.object_id=fc.parent_object_id AND c.column_id=fc.parent_column_id
   WHERE fc.constraint_object_id=f.object_id ORDER BY fc.constraint_column_id FOR XML PATH(''''),TYPE).value(''.'',''nvarchar(max)''),1,1,N'''') AS ColumnList)pc
 CROSS APPLY(SELECT STUFF((SELECT N'',''+QUOTENAME(c.name) FROM sys.foreign_key_columns fc
   JOIN sys.columns c ON c.object_id=fc.referenced_object_id AND c.column_id=fc.referenced_column_id
   WHERE fc.constraint_object_id=f.object_id ORDER BY fc.constraint_column_id FOR XML PATH(''''),TYPE).value(''.'',''nvarchar(max)''),1,1,N'''') AS ColumnList)rc
 WHERE EXISTS(SELECT 1 FROM sys.foreign_key_columns fc WHERE fc.constraint_object_id=f.object_id
   AND ((fc.parent_object_id=@ObjectId AND fc.parent_column_id=@ColumnId) OR (fc.referenced_object_id=@ObjectId AND fc.referenced_column_id=@ColumnId)))
 OR (f.referenced_object_id=@ObjectId AND EXISTS(SELECT 1 FROM @Indexes i WHERE i.IndexId=f.key_index_id));
 DECLARE fkdrop CURSOR LOCAL FAST_FORWARD FOR SELECT DropSql FROM @ForeignKeys ORDER BY FkId;
 OPEN fkdrop; FETCH NEXT FROM fkdrop INTO @Sql;
 WHILE @@FETCH_STATUS=0 BEGIN EXEC sys.sp_executesql @Sql; FETCH NEXT FROM fkdrop INTO @Sql; END;
 CLOSE fkdrop; DEALLOCATE fkdrop;
 DECLARE idxdrop CURSOR LOCAL FAST_FORWARD FOR SELECT DropSql FROM @Indexes ORDER BY IndexId;
 OPEN idxdrop; FETCH NEXT FROM idxdrop INTO @Sql;
 WHILE @@FETCH_STATUS=0 BEGIN EXEC sys.sp_executesql @Sql; FETCH NEXT FROM idxdrop INTO @Sql; END;
 CLOSE idxdrop; DEALLOCATE idxdrop;
 SET @Sql=N''ALTER TABLE ''+@Target+N'' ALTER COLUMN ''+QUOTENAME(@ColumnName)+N'' INT NOT NULL;'';
 EXEC sys.sp_executesql @Sql;
 DECLARE idxcreate CURSOR LOCAL FAST_FORWARD FOR SELECT CreateSql FROM @Indexes ORDER BY IndexId;
 OPEN idxcreate; FETCH NEXT FROM idxcreate INTO @Sql;
 WHILE @@FETCH_STATUS=0 BEGIN EXEC sys.sp_executesql @Sql; FETCH NEXT FROM idxcreate INTO @Sql; END;
 CLOSE idxcreate; DEALLOCATE idxcreate;
 DECLARE fkcreate CURSOR LOCAL FAST_FORWARD FOR SELECT CreateSql FROM @ForeignKeys ORDER BY FkId;
 OPEN fkcreate; FETCH NEXT FROM fkcreate INTO @Sql;
 WHILE @@FETCH_STATUS=0 BEGIN EXEC sys.sp_executesql @Sql; FETCH NEXT FROM fkcreate INTO @Sql; END;
 CLOSE fkcreate; DEALLOCATE fkcreate;
 DECLARE disablecommands CURSOR LOCAL FAST_FORWARD FOR
 SELECT DisableSql FROM @ForeignKeys WHERE DisableSql IS NOT NULL UNION ALL SELECT DisableSql FROM @Indexes WHERE DisableSql IS NOT NULL;
 OPEN disablecommands; FETCH NEXT FROM disablecommands INTO @Sql;
 WHILE @@FETCH_STATUS=0 BEGIN EXEC sys.sp_executesql @Sql; FETCH NEXT FROM disablecommands INTO @Sql; END;
 CLOSE disablecommands; DEALLOCATE disablecommands;
END;
');
-- Fill these two mapping tables only when the read-only preflight reports missing data.
-- Use real IDs from your database. Empty tables never invent a province or school.
DECLARE @CityProvinceMap TABLE(CITY_ID INT PRIMARY KEY,PROVINCE_ID INT NOT NULL);
-- INSERT @CityProvinceMap VALUES (actual_city_id, actual_province_id);
DECLARE @PersonSchoolMap TABLE(PERSON_ID INT PRIMARY KEY,SCHOOL_ID INT NOT NULL);
-- INSERT @PersonSchoolMap VALUES (actual_person_id, actual_school_id);
IF EXISTS(SELECT 1 FROM dbo.PERSONS p LEFT JOIN (
 SELECT PERSON_ID FROM dbo.LEARNERS UNION ALL SELECT PERSON_ID FROM dbo.TEACHERS
 UNION ALL SELECT PERSON_ID FROM dbo.ITADMINS UNION ALL SELECT PERSON_ID FROM dbo.UNIVERSITY_REPS
) r ON r.PERSON_ID=p.PERSON_ID GROUP BY p.PERSON_ID HAVING COUNT(r.PERSON_ID)<>1)
THROW 51001,'Some people have zero or multiple roles. Run 01_erd_preflight.sql and resolve their intended roles first.',1;
UPDATE r SET SCHOOL_ID=m.SCHOOL_ID FROM dbo.LEARNERS r JOIN @PersonSchoolMap m ON m.PERSON_ID=r.PERSON_ID WHERE r.SCHOOL_ID IS NULL;
UPDATE r SET SCHOOL_ID=m.SCHOOL_ID FROM dbo.TEACHERS r JOIN @PersonSchoolMap m ON m.PERSON_ID=r.PERSON_ID WHERE r.SCHOOL_ID IS NULL;
UPDATE r SET SCHOOL_ID=m.SCHOOL_ID FROM dbo.ITADMINS r JOIN @PersonSchoolMap m ON m.PERSON_ID=r.PERSON_ID WHERE r.SCHOOL_ID IS NULL;
ALTER TABLE dbo.CITIES ADD PROVINCE_ID INT NULL;
-- Known locations come from the project's existing 10_load_necessary_cities.sql. Unknown names are never guessed.
EXEC(N';WITH KnownCityProvince AS (
 SELECT v.CITY_NAME,v.PROVINCE_NAME FROM (VALUES
 (N''Alice'',N''Eastern Cape''),
 (N''Bellville'',N''Western Cape''),
 (N''Bloemfontein'',N''Free State''),
 (N''Cape Town'',N''Western Cape''),
 (N''Durban'',N''KwaZulu-Natal''),
 (N''East London'',N''Eastern Cape''),
 (N''Ga-Rankuwa'',N''Gauteng''),
 (N''Gqeberha'',N''Eastern Cape''),
 (N''Johannesburg'',N''Gauteng''),
 (N''Kimberley'',N''Northern Cape''),
 (N''KwaDlangezwa'',N''KwaZulu-Natal''),
 (N''Makhanda'',N''Eastern Cape''),
 (N''Mankweng'',N''Limpopo''),
 (N''Mbombela'',N''Mpumalanga''),
 (N''Mthatha'',N''Eastern Cape''),
 (N''Potchefstroom'',N''North West''),
 (N''Pretoria'',N''Gauteng''),
 (N''Stellenbosch'',N''Western Cape''),
 (N''Thohoyandou'',N''Limpopo''),
 (N''Vanderbijlpark'',N''Gauteng'')
 )v(CITY_NAME,PROVINCE_NAME)
), Evidence AS (
 SELECT CITY_ID,PROVINCE_ID FROM dbo.SCHOOLS WHERE CITY_ID IS NOT NULL
 UNION SELECT c.CITY_ID,p.PROVINCE_ID FROM dbo.CITIES c
 JOIN KnownCityProvince k ON UPPER(LTRIM(RTRIM(c.CITY_NAME)))=UPPER(k.CITY_NAME)
 JOIN dbo.PROVINCES p ON UPPER(LTRIM(RTRIM(p.PROVINCE_NAME)))=UPPER(k.PROVINCE_NAME)
), Inferred AS (SELECT CITY_ID,MIN(PROVINCE_ID) AS PROVINCE_ID FROM Evidence GROUP BY CITY_ID HAVING COUNT(DISTINCT PROVINCE_ID)=1)
UPDATE c SET PROVINCE_ID=e.PROVINCE_ID FROM dbo.CITIES c JOIN Inferred e ON e.CITY_ID=c.CITY_ID;
');
DECLARE @CityId INT,@ProvinceId INT;
DECLARE citymap CURSOR LOCAL FAST_FORWARD FOR SELECT CITY_ID,PROVINCE_ID FROM @CityProvinceMap;
OPEN citymap; FETCH NEXT FROM citymap INTO @CityId,@ProvinceId;
WHILE @@FETCH_STATUS=0 BEGIN
 EXEC sys.sp_executesql N'UPDATE dbo.CITIES SET PROVINCE_ID=@p WHERE CITY_ID=@c',N'@p INT,@c INT',@ProvinceId,@CityId;
 FETCH NEXT FROM citymap INTO @CityId,@ProvinceId;
END;
CLOSE citymap; DEALLOCATE citymap;
EXEC(N'IF EXISTS(SELECT 1 FROM dbo.CITIES WHERE PROVINCE_ID IS NULL) THROW 51002,''Some cities have no unambiguous province. Fill @CityProvinceMap in the migration.'',1; EXEC dbo.usp_AlignRequiredIntColumn N''CITIES'', N''PROVINCE_ID''; ALTER TABLE dbo.CITIES WITH CHECK ADD CONSTRAINT FK_CITY_PROVINCE FOREIGN KEY(PROVINCE_ID) REFERENCES dbo.PROVINCES(PROVINCE_ID);');
ALTER TABLE dbo.PERSONS ADD PERSON_TYPE VARCHAR(1) NULL;
EXEC(N'UPDATE p SET PERSON_TYPE=''L'' FROM dbo.PERSONS p JOIN dbo.LEARNERS r ON r.PERSON_ID=p.PERSON_ID;
UPDATE p SET PERSON_TYPE=''T'' FROM dbo.PERSONS p JOIN dbo.TEACHERS r ON r.PERSON_ID=p.PERSON_ID;
UPDATE p SET PERSON_TYPE=''A'' FROM dbo.PERSONS p JOIN dbo.ITADMINS r ON r.PERSON_ID=p.PERSON_ID;
UPDATE p SET PERSON_TYPE=''R'' FROM dbo.PERSONS p JOIN dbo.UNIVERSITY_REPS r ON r.PERSON_ID=p.PERSON_ID;
ALTER TABLE dbo.PERSONS ALTER COLUMN PERSON_TYPE VARCHAR(1) NOT NULL; ALTER TABLE dbo.PERSONS ADD CONSTRAINT CK_PERSONS_TYPE CHECK(PERSON_TYPE COLLATE Latin1_General_100_BIN2 IN (''L'',''T'',''A'',''R''));');
IF COL_LENGTH(N'dbo.UNIVERSITY_ADDRESSES', N'ADDRESS_TYPE_ID') IS NULL
BEGIN
 IF COL_LENGTH(N'dbo.UNIVERSITY_ADDRESSES', N'ADRRESS_TYPE_ID') IS NULL
  THROW 51006,'UNIVERSITY_ADDRESSES has no address-type column to rename.',1;
 EXEC sys.sp_rename N'dbo.UNIVERSITY_ADDRESSES.ADRRESS_TYPE_ID',N'ADDRESS_TYPE_ID',N'COLUMN';
END;
ELSE IF COL_LENGTH(N'dbo.UNIVERSITY_ADDRESSES', N'ADRRESS_TYPE_ID') IS NOT NULL
 THROW 51006,'Both address-type spellings exist. Inspect the schema before continuing.',1;
ALTER TABLE dbo.APPLICATIONS DROP CONSTRAINT FK_APPS_LEARNER;
ALTER TABLE dbo.APPLICATIONS DROP CONSTRAINT FK_APPS_TEACHER;
ALTER TABLE dbo.APPLICATIONS DROP CONSTRAINT FK_APPS_REVIEWER;
ALTER TABLE dbo.DOCUMENTS DROP CONSTRAINT FK_DOCS_VERTEACHER;
ALTER TABLE dbo.LEARNER_RESULTS DROP CONSTRAINT FK_LRESULTS_LEARNER_FK;
ALTER TABLE dbo.LEARNER_RESULTS DROP CONSTRAINT FK_LRESULTS_VERTEACHER;
ALTER TABLE dbo.LEARNER_SUBJECTS DROP CONSTRAINT FK_LSUBJ_LEARNER;
IF EXISTS(SELECT 1 FROM dbo.LEARNERS WHERE PERSON_ID IS NULL OR SCHOOL_ID IS NULL) THROW 51003,'LEARNERS has missing person or organisation references. Resolve preflight before migration.',1;
DECLARE @Pk_LEARNERS SYSNAME=(SELECT name FROM sys.key_constraints WHERE parent_object_id=OBJECT_ID(N'dbo.LEARNERS') AND type='PK');
DECLARE @DropPk_LEARNERS NVARCHAR(MAX)=N'ALTER TABLE dbo.LEARNERS DROP CONSTRAINT '+QUOTENAME(@Pk_LEARNERS);
EXEC sys.sp_executesql @DropPk_LEARNERS;
EXEC dbo.usp_AlignRequiredIntColumn N'LEARNERS', N'PERSON_ID';
ALTER TABLE dbo.LEARNERS ADD CONSTRAINT PK_LEARNERS_PERSON PRIMARY KEY(PERSON_ID);
ALTER TABLE dbo.LEARNERS ADD CONSTRAINT UQ_LEARNERS_IDENTIFIER UNIQUE(LEARNER_ID);
EXEC dbo.usp_AlignRequiredIntColumn N'LEARNERS', N'SCHOOL_ID';
IF EXISTS(SELECT 1 FROM dbo.TEACHERS WHERE PERSON_ID IS NULL OR SCHOOL_ID IS NULL) THROW 51003,'TEACHERS has missing person or organisation references. Resolve preflight before migration.',1;
DECLARE @Pk_TEACHERS SYSNAME=(SELECT name FROM sys.key_constraints WHERE parent_object_id=OBJECT_ID(N'dbo.TEACHERS') AND type='PK');
DECLARE @DropPk_TEACHERS NVARCHAR(MAX)=N'ALTER TABLE dbo.TEACHERS DROP CONSTRAINT '+QUOTENAME(@Pk_TEACHERS);
EXEC sys.sp_executesql @DropPk_TEACHERS;
EXEC dbo.usp_AlignRequiredIntColumn N'TEACHERS', N'PERSON_ID';
ALTER TABLE dbo.TEACHERS ADD CONSTRAINT PK_TEACHERS_PERSON PRIMARY KEY(PERSON_ID);
ALTER TABLE dbo.TEACHERS ADD CONSTRAINT UQ_TEACHERS_IDENTIFIER UNIQUE(TEACHER_ID);
EXEC dbo.usp_AlignRequiredIntColumn N'TEACHERS', N'SCHOOL_ID';
IF EXISTS(SELECT 1 FROM dbo.ITADMINS WHERE PERSON_ID IS NULL OR SCHOOL_ID IS NULL) THROW 51003,'ITADMINS has missing person or organisation references. Resolve preflight before migration.',1;
DECLARE @Pk_ITADMINS SYSNAME=(SELECT name FROM sys.key_constraints WHERE parent_object_id=OBJECT_ID(N'dbo.ITADMINS') AND type='PK');
DECLARE @DropPk_ITADMINS NVARCHAR(MAX)=N'ALTER TABLE dbo.ITADMINS DROP CONSTRAINT '+QUOTENAME(@Pk_ITADMINS);
EXEC sys.sp_executesql @DropPk_ITADMINS;
EXEC dbo.usp_AlignRequiredIntColumn N'ITADMINS', N'PERSON_ID';
ALTER TABLE dbo.ITADMINS ADD CONSTRAINT PK_ITADMINS_PERSON PRIMARY KEY(PERSON_ID);
ALTER TABLE dbo.ITADMINS ADD CONSTRAINT UQ_ITADMINS_IDENTIFIER UNIQUE(ITADMIN_IID);
EXEC dbo.usp_AlignRequiredIntColumn N'ITADMINS', N'SCHOOL_ID';
IF EXISTS(SELECT 1 FROM dbo.UNIVERSITY_REPS WHERE PERSON_ID IS NULL OR UNIVERSITY_ID IS NULL) THROW 51003,'UNIVERSITY_REPS has missing person or organisation references. Resolve preflight before migration.',1;
DECLARE @Pk_UNIVERSITY_REPS SYSNAME=(SELECT name FROM sys.key_constraints WHERE parent_object_id=OBJECT_ID(N'dbo.UNIVERSITY_REPS') AND type='PK');
DECLARE @DropPk_UNIVERSITY_REPS NVARCHAR(MAX)=N'ALTER TABLE dbo.UNIVERSITY_REPS DROP CONSTRAINT '+QUOTENAME(@Pk_UNIVERSITY_REPS);
EXEC sys.sp_executesql @DropPk_UNIVERSITY_REPS;
EXEC dbo.usp_AlignRequiredIntColumn N'UNIVERSITY_REPS', N'PERSON_ID';
ALTER TABLE dbo.UNIVERSITY_REPS ADD CONSTRAINT PK_UNIVERSITY_REPS_PERSON PRIMARY KEY(PERSON_ID);
ALTER TABLE dbo.UNIVERSITY_REPS ADD CONSTRAINT UQ_UNIVERSITY_REPS_IDENTIFIER UNIQUE(REP_ID);
ALTER TABLE dbo.APPLICATIONS WITH CHECK ADD CONSTRAINT FK_APPS_LEARNER FOREIGN KEY(LEARNER_ID) REFERENCES dbo.LEARNERS(LEARNER_ID) ON DELETE CASCADE;
ALTER TABLE dbo.APPLICATIONS WITH CHECK ADD CONSTRAINT FK_APPS_TEACHER FOREIGN KEY(TEACHER_ID) REFERENCES dbo.TEACHERS(TEACHER_ID);
ALTER TABLE dbo.APPLICATIONS WITH CHECK ADD CONSTRAINT FK_APPS_REVIEWER FOREIGN KEY(REVIEWED_BY_REP_ID) REFERENCES dbo.UNIVERSITY_REPS(REP_ID);
ALTER TABLE dbo.DOCUMENTS WITH CHECK ADD CONSTRAINT FK_DOCS_VERTEACHER FOREIGN KEY(VERIFIED_BY_TEACHER_ID) REFERENCES dbo.TEACHERS(TEACHER_ID);
ALTER TABLE dbo.LEARNER_RESULTS WITH CHECK ADD CONSTRAINT FK_LRESULTS_LEARNER_FK FOREIGN KEY(LEARNER_ID) REFERENCES dbo.LEARNERS(LEARNER_ID) ON DELETE CASCADE;
ALTER TABLE dbo.LEARNER_RESULTS WITH CHECK ADD CONSTRAINT FK_LRESULTS_VERTEACHER FOREIGN KEY(VERIFIED_BY_TEACHER_ID) REFERENCES dbo.TEACHERS(TEACHER_ID);
ALTER TABLE dbo.LEARNER_SUBJECTS WITH CHECK ADD CONSTRAINT FK_LSUBJ_LEARNER FOREIGN KEY(LEARNER_ID) REFERENCES dbo.LEARNERS(LEARNER_ID) ON DELETE CASCADE;
IF EXISTS(SELECT 1 FROM dbo.SCHOOLS WHERE CITY_ID IS NULL) THROW 51004,'SCHOOLS.CITY_ID has missing values. No fabricated references were assigned.',1;
EXEC dbo.usp_AlignRequiredIntColumn N'SCHOOLS', N'CITY_ID';
IF EXISTS(SELECT 1 FROM dbo.QUALIFICATIONS WHERE PROGRAM_ID IS NULL) THROW 51004,'QUALIFICATIONS.PROGRAM_ID has missing values. No fabricated references were assigned.',1;
EXEC dbo.usp_AlignRequiredIntColumn N'QUALIFICATIONS', N'PROGRAM_ID';
IF EXISTS(SELECT 1 FROM dbo.PERSON_ADDRESSES WHERE PERSON_ID IS NULL) THROW 51004,'PERSON_ADDRESSES.PERSON_ID has missing values. No fabricated references were assigned.',1;
EXEC dbo.usp_AlignRequiredIntColumn N'PERSON_ADDRESSES', N'PERSON_ID';
IF EXISTS(SELECT 1 FROM dbo.PERSON_ADDRESSES WHERE ADDRESS_TYPE_ID IS NULL) THROW 51004,'PERSON_ADDRESSES.ADDRESS_TYPE_ID has missing values. No fabricated references were assigned.',1;
EXEC dbo.usp_AlignRequiredIntColumn N'PERSON_ADDRESSES', N'ADDRESS_TYPE_ID';
IF EXISTS(SELECT 1 FROM dbo.PERSON_ADDRESSES WHERE CITY_ID IS NULL) THROW 51004,'PERSON_ADDRESSES.CITY_ID has missing values. No fabricated references were assigned.',1;
EXEC dbo.usp_AlignRequiredIntColumn N'PERSON_ADDRESSES', N'CITY_ID';
IF EXISTS(SELECT 1 FROM dbo.UNIVERSITY_ADDRESSES WHERE UNIVERSITY_ID IS NULL) THROW 51004,'UNIVERSITY_ADDRESSES.UNIVERSITY_ID has missing values. No fabricated references were assigned.',1;
EXEC dbo.usp_AlignRequiredIntColumn N'UNIVERSITY_ADDRESSES', N'UNIVERSITY_ID';
-- Compile these references only AFTER sp_rename has completed.
EXEC sys.sp_executesql N'
 IF EXISTS(SELECT 1 FROM dbo.UNIVERSITY_ADDRESSES WHERE ADDRESS_TYPE_ID IS NULL)
  THROW 51004,''UNIVERSITY_ADDRESSES.ADDRESS_TYPE_ID has missing values. No fabricated references were assigned.'',1;
 EXEC dbo.usp_AlignRequiredIntColumn N''UNIVERSITY_ADDRESSES'', N''ADDRESS_TYPE_ID'';
';
IF EXISTS(SELECT 1 FROM dbo.UNIVERSITY_ADDRESSES WHERE CITY_ID IS NULL) THROW 51004,'UNIVERSITY_ADDRESSES.CITY_ID has missing values. No fabricated references were assigned.',1;
EXEC dbo.usp_AlignRequiredIntColumn N'UNIVERSITY_ADDRESSES', N'CITY_ID';
IF EXISTS(SELECT 1 FROM dbo.PROSPECTUSES WHERE UNIVERSITY_ID IS NULL) THROW 51004,'PROSPECTUSES.UNIVERSITY_ID has missing values. No fabricated references were assigned.',1;
EXEC dbo.usp_AlignRequiredIntColumn N'PROSPECTUSES', N'UNIVERSITY_ID';
IF EXISTS(SELECT 1 FROM dbo.UNI_QUALIFICATIONS WHERE UNIVERSITY_ID IS NULL) THROW 51004,'UNI_QUALIFICATIONS.UNIVERSITY_ID has missing values. No fabricated references were assigned.',1;
EXEC dbo.usp_AlignRequiredIntColumn N'UNI_QUALIFICATIONS', N'UNIVERSITY_ID';
IF EXISTS(SELECT 1 FROM dbo.UNI_QUALIFICATIONS WHERE QUAL_ID IS NULL) THROW 51004,'UNI_QUALIFICATIONS.QUAL_ID has missing values. No fabricated references were assigned.',1;
EXEC dbo.usp_AlignRequiredIntColumn N'UNI_QUALIFICATIONS', N'QUAL_ID';
IF EXISTS(SELECT 1 FROM dbo.APPLICATIONS WHERE STUDY_MODE_ID IS NULL) THROW 51004,'APPLICATIONS.STUDY_MODE_ID has missing values. No fabricated references were assigned.',1;
EXEC dbo.usp_AlignRequiredIntColumn N'APPLICATIONS', N'STUDY_MODE_ID';
IF EXISTS(SELECT 1 FROM dbo.APPLICATIONS WHERE UNI_QUAL_ID IS NULL) THROW 51004,'APPLICATIONS.UNI_QUAL_ID has missing values. No fabricated references were assigned.',1;
EXEC dbo.usp_AlignRequiredIntColumn N'APPLICATIONS', N'UNI_QUAL_ID';
IF EXISTS(SELECT 1 FROM dbo.APPLICATIONS WHERE LEARNER_ID IS NULL) THROW 51004,'APPLICATIONS.LEARNER_ID has missing values. No fabricated references were assigned.',1;
EXEC dbo.usp_AlignRequiredIntColumn N'APPLICATIONS', N'LEARNER_ID';
IF EXISTS(SELECT 1 FROM dbo.APPLICATION_PROCESSES WHERE APPLICATION_ID IS NULL) THROW 51004,'APPLICATION_PROCESSES.APPLICATION_ID has missing values. No fabricated references were assigned.',1;
EXEC dbo.usp_AlignRequiredIntColumn N'APPLICATION_PROCESSES', N'APPLICATION_ID';
IF EXISTS(SELECT 1 FROM dbo.APPLICATION_PROCESSES WHERE ACTION_ID IS NULL) THROW 51004,'APPLICATION_PROCESSES.ACTION_ID has missing values. No fabricated references were assigned.',1;
EXEC dbo.usp_AlignRequiredIntColumn N'APPLICATION_PROCESSES', N'ACTION_ID';
IF EXISTS(SELECT 1 FROM dbo.DOCUMENTS WHERE DOCUMENT_TYPE_ID IS NULL) THROW 51004,'DOCUMENTS.DOCUMENT_TYPE_ID has missing values. No fabricated references were assigned.',1;
EXEC dbo.usp_AlignRequiredIntColumn N'DOCUMENTS', N'DOCUMENT_TYPE_ID';
IF EXISTS(SELECT 1 FROM dbo.DOCUMENTS WHERE PERSON_ID IS NULL) THROW 51004,'DOCUMENTS.PERSON_ID has missing values. No fabricated references were assigned.',1;
EXEC dbo.usp_AlignRequiredIntColumn N'DOCUMENTS', N'PERSON_ID';
IF EXISTS(SELECT 1 FROM dbo.DOCUMENTS WHERE VERIFICATION_STATUS_ID IS NULL) THROW 51004,'DOCUMENTS.VERIFICATION_STATUS_ID has missing values. No fabricated references were assigned.',1;
EXEC dbo.usp_AlignRequiredIntColumn N'DOCUMENTS', N'VERIFICATION_STATUS_ID';
IF EXISTS(SELECT 1 FROM dbo.LEARNER_RESULTS WHERE VERIFICATION_STATUS_ID IS NULL) THROW 51004,'LEARNER_RESULTS.VERIFICATION_STATUS_ID has missing values. No fabricated references were assigned.',1;
EXEC dbo.usp_AlignRequiredIntColumn N'LEARNER_RESULTS', N'VERIFICATION_STATUS_ID';
IF EXISTS(SELECT 1 FROM dbo.LEARNER_SUBJECTS WHERE LEARNER_ID IS NULL) THROW 51004,'LEARNER_SUBJECTS.LEARNER_ID has missing values. No fabricated references were assigned.',1;
EXEC dbo.usp_AlignRequiredIntColumn N'LEARNER_SUBJECTS', N'LEARNER_ID';
IF EXISTS(SELECT 1 FROM dbo.LEARNER_SUBJECTS WHERE SUBJECT_ID IS NULL) THROW 51004,'LEARNER_SUBJECTS.SUBJECT_ID has missing values. No fabricated references were assigned.',1;
EXEC dbo.usp_AlignRequiredIntColumn N'LEARNER_SUBJECTS', N'SUBJECT_ID';
EXEC(N'IF EXISTS(SELECT 1 FROM dbo.SCHOOLS s JOIN dbo.CITIES c ON c.CITY_ID=s.CITY_ID WHERE s.PROVINCE_ID<>c.PROVINCE_ID) THROW 51005,''Conflicting city and organisation provinces. Resolve actual locations first.'',1;');
EXEC(N'CREATE OR ALTER TRIGGER dbo.TRG_PERSONS_ROLE ON dbo.PERSONS AFTER INSERT, UPDATE AS
BEGIN
 SET NOCOUNT ON;
 IF EXISTS(SELECT 1 FROM inserted i JOIN deleted d ON i.PERSON_ID=d.PERSON_ID WHERE i.PERSON_TYPE<>d.PERSON_TYPE)
  THROW 51010, ''Person type cannot be changed independently of its subtype.'', 1;
 -- New people must receive their mandatory subtype within this same statement.
 DECLARE @SchoolId INT=TRY_CONVERT(INT,SESSION_CONTEXT(N''VV_SCHOOL_ID'')),
         @UniversityId INT=TRY_CONVERT(INT,SESSION_CONTEXT(N''VV_UNIVERSITY_ID''));
 IF EXISTS(SELECT 1 FROM inserted i LEFT JOIN deleted d ON d.PERSON_ID=i.PERSON_ID
           WHERE d.PERSON_ID IS NULL AND ((i.PERSON_TYPE=''R'' AND @UniversityId IS NULL) OR (i.PERSON_TYPE<>''R'' AND @SchoolId IS NULL)))
  THROW 51011, ''Create a person with dbo.usp_CreatePersonWithRole and a school or university.'', 1;
 INSERT dbo.LEARNERS(PERSON_ID,SCHOOL_ID)
 SELECT i.PERSON_ID,@SchoolId FROM inserted i LEFT JOIN deleted d ON d.PERSON_ID=i.PERSON_ID WHERE d.PERSON_ID IS NULL AND i.PERSON_TYPE=''L'';
 INSERT dbo.TEACHERS(PERSON_ID,SCHOOL_ID,DEPARTMENT,DESIGNATION)
 SELECT i.PERSON_ID,@SchoolId,''Career Guidance'',''Career Guidance Teacher'' FROM inserted i LEFT JOIN deleted d ON d.PERSON_ID=i.PERSON_ID WHERE d.PERSON_ID IS NULL AND i.PERSON_TYPE=''T'';
 INSERT dbo.ITADMINS(PERSON_ID,SCHOOL_ID)
 SELECT i.PERSON_ID,@SchoolId FROM inserted i LEFT JOIN deleted d ON d.PERSON_ID=i.PERSON_ID WHERE d.PERSON_ID IS NULL AND i.PERSON_TYPE=''A'';
 INSERT dbo.UNIVERSITY_REPS(PERSON_ID,UNIVERSITY_ID)
 SELECT i.PERSON_ID,@UniversityId FROM inserted i LEFT JOIN deleted d ON d.PERSON_ID=i.PERSON_ID WHERE d.PERSON_ID IS NULL AND i.PERSON_TYPE=''R'';
END;');
EXEC(N'CREATE OR ALTER TRIGGER dbo.TRG_LEARNERS_ROLE ON dbo.LEARNERS AFTER INSERT, UPDATE, DELETE AS
BEGIN
 SET NOCOUNT ON;
 -- Lock the common parent to serialize concurrent membership changes.
 DECLARE @LockId INT;
 SELECT @LockId=p.PERSON_ID FROM dbo.PERSONS p WITH (UPDLOCK,HOLDLOCK)
 JOIN (SELECT PERSON_ID FROM inserted UNION SELECT PERSON_ID FROM deleted) a ON a.PERSON_ID=p.PERSON_ID;
 IF EXISTS(SELECT 1 FROM dbo.PERSONS p
 JOIN (SELECT PERSON_ID FROM inserted UNION SELECT PERSON_ID FROM deleted) a ON a.PERSON_ID=p.PERSON_ID
 OUTER APPLY(SELECT COUNT(*) AS n,MIN(r.PERSON_TYPE) AS t FROM (SELECT PERSON_ID,''L'' AS PERSON_TYPE FROM dbo.LEARNERS UNION ALL SELECT PERSON_ID,''T'' AS PERSON_TYPE FROM dbo.TEACHERS UNION ALL SELECT PERSON_ID,''A'' AS PERSON_TYPE FROM dbo.ITADMINS UNION ALL SELECT PERSON_ID,''R'' AS PERSON_TYPE FROM dbo.UNIVERSITY_REPS) r WHERE r.PERSON_ID=p.PERSON_ID) x
 WHERE x.n<>1 OR x.t<>p.PERSON_TYPE)
 THROW 51012, ''Each person must have exactly one matching learner, teacher, administrator or representative subtype.'', 1;
END;');
EXEC(N'CREATE OR ALTER TRIGGER dbo.TRG_TEACHERS_ROLE ON dbo.TEACHERS AFTER INSERT, UPDATE, DELETE AS
BEGIN
 SET NOCOUNT ON;
 -- Lock the common parent to serialize concurrent membership changes.
 DECLARE @LockId INT;
 SELECT @LockId=p.PERSON_ID FROM dbo.PERSONS p WITH (UPDLOCK,HOLDLOCK)
 JOIN (SELECT PERSON_ID FROM inserted UNION SELECT PERSON_ID FROM deleted) a ON a.PERSON_ID=p.PERSON_ID;
 IF EXISTS(SELECT 1 FROM dbo.PERSONS p
 JOIN (SELECT PERSON_ID FROM inserted UNION SELECT PERSON_ID FROM deleted) a ON a.PERSON_ID=p.PERSON_ID
 OUTER APPLY(SELECT COUNT(*) AS n,MIN(r.PERSON_TYPE) AS t FROM (SELECT PERSON_ID,''L'' AS PERSON_TYPE FROM dbo.LEARNERS UNION ALL SELECT PERSON_ID,''T'' AS PERSON_TYPE FROM dbo.TEACHERS UNION ALL SELECT PERSON_ID,''A'' AS PERSON_TYPE FROM dbo.ITADMINS UNION ALL SELECT PERSON_ID,''R'' AS PERSON_TYPE FROM dbo.UNIVERSITY_REPS) r WHERE r.PERSON_ID=p.PERSON_ID) x
 WHERE x.n<>1 OR x.t<>p.PERSON_TYPE)
 THROW 51012, ''Each person must have exactly one matching learner, teacher, administrator or representative subtype.'', 1;
END;');
EXEC(N'CREATE OR ALTER TRIGGER dbo.TRG_ITADMINS_ROLE ON dbo.ITADMINS AFTER INSERT, UPDATE, DELETE AS
BEGIN
 SET NOCOUNT ON;
 -- Lock the common parent to serialize concurrent membership changes.
 DECLARE @LockId INT;
 SELECT @LockId=p.PERSON_ID FROM dbo.PERSONS p WITH (UPDLOCK,HOLDLOCK)
 JOIN (SELECT PERSON_ID FROM inserted UNION SELECT PERSON_ID FROM deleted) a ON a.PERSON_ID=p.PERSON_ID;
 IF EXISTS(SELECT 1 FROM dbo.PERSONS p
 JOIN (SELECT PERSON_ID FROM inserted UNION SELECT PERSON_ID FROM deleted) a ON a.PERSON_ID=p.PERSON_ID
 OUTER APPLY(SELECT COUNT(*) AS n,MIN(r.PERSON_TYPE) AS t FROM (SELECT PERSON_ID,''L'' AS PERSON_TYPE FROM dbo.LEARNERS UNION ALL SELECT PERSON_ID,''T'' AS PERSON_TYPE FROM dbo.TEACHERS UNION ALL SELECT PERSON_ID,''A'' AS PERSON_TYPE FROM dbo.ITADMINS UNION ALL SELECT PERSON_ID,''R'' AS PERSON_TYPE FROM dbo.UNIVERSITY_REPS) r WHERE r.PERSON_ID=p.PERSON_ID) x
 WHERE x.n<>1 OR x.t<>p.PERSON_TYPE)
 THROW 51012, ''Each person must have exactly one matching learner, teacher, administrator or representative subtype.'', 1;
END;');
EXEC(N'CREATE OR ALTER TRIGGER dbo.TRG_UNIVERSITY_REPS_ROLE ON dbo.UNIVERSITY_REPS AFTER INSERT, UPDATE, DELETE AS
BEGIN
 SET NOCOUNT ON;
 -- Lock the common parent to serialize concurrent membership changes.
 DECLARE @LockId INT;
 SELECT @LockId=p.PERSON_ID FROM dbo.PERSONS p WITH (UPDLOCK,HOLDLOCK)
 JOIN (SELECT PERSON_ID FROM inserted UNION SELECT PERSON_ID FROM deleted) a ON a.PERSON_ID=p.PERSON_ID;
 IF EXISTS(SELECT 1 FROM dbo.PERSONS p
 JOIN (SELECT PERSON_ID FROM inserted UNION SELECT PERSON_ID FROM deleted) a ON a.PERSON_ID=p.PERSON_ID
 OUTER APPLY(SELECT COUNT(*) AS n,MIN(r.PERSON_TYPE) AS t FROM (SELECT PERSON_ID,''L'' AS PERSON_TYPE FROM dbo.LEARNERS UNION ALL SELECT PERSON_ID,''T'' AS PERSON_TYPE FROM dbo.TEACHERS UNION ALL SELECT PERSON_ID,''A'' AS PERSON_TYPE FROM dbo.ITADMINS UNION ALL SELECT PERSON_ID,''R'' AS PERSON_TYPE FROM dbo.UNIVERSITY_REPS) r WHERE r.PERSON_ID=p.PERSON_ID) x
 WHERE x.n<>1 OR x.t<>p.PERSON_TYPE)
 THROW 51012, ''Each person must have exactly one matching learner, teacher, administrator or representative subtype.'', 1;
END;');
EXEC(N'CREATE OR ALTER PROCEDURE dbo.usp_CreatePersonWithRole
 @FIRST_NAME VARCHAR(100), @LAST_NAME VARCHAR(100), @EMAIL VARCHAR(255), @USERNAME VARCHAR(100),
 @PHONE_NUMBER VARCHAR(10)=NULL, @SA_ID_NUMBER VARCHAR(13)=NULL,
 @PERSON_TYPE VARCHAR(1)=NULL, @SCHOOL_ID INT=NULL, @UNIVERSITY_ID INT=NULL
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 IF @PERSON_TYPE IS NULL OR @PERSON_TYPE NOT IN (''L'',''T'',''A'',''R'') THROW 51013,''Choose L, T, A or R.'',1;
 IF (@PERSON_TYPE=''R'' AND NOT EXISTS(SELECT 1 FROM dbo.UNIVERSITIES WHERE UNIVERSITY_ID=@UNIVERSITY_ID))
 OR (@PERSON_TYPE<>''R'' AND NOT EXISTS(SELECT 1 FROM dbo.SCHOOLS WHERE SCHOOL_ID=@SCHOOL_ID))
 THROW 51014,''Choose an existing school or university.'',1;
 DECLARE @Own BIT=CASE WHEN @@TRANCOUNT=0 THEN 1 ELSE 0 END, @PersonId INT;
 BEGIN TRY
  IF @Own=1 BEGIN TRANSACTION;
  EXEC sys.sp_set_session_context @key=N''VV_SCHOOL_ID'',@value=@SCHOOL_ID;
  EXEC sys.sp_set_session_context @key=N''VV_UNIVERSITY_ID'',@value=@UNIVERSITY_ID;
  INSERT dbo.PERSONS(FIRST_NAME,LAST_NAME,EMAIL,USERNAME,PHONE_NUMBER,SA_ID_NUMBER,PERSON_TYPE)
  VALUES(@FIRST_NAME,@LAST_NAME,@EMAIL,@USERNAME,@PHONE_NUMBER,@SA_ID_NUMBER,@PERSON_TYPE);
  SET @PersonId=CONVERT(INT,SCOPE_IDENTITY());
  EXEC sys.sp_set_session_context @key=N''VV_SCHOOL_ID'',@value=NULL;
  EXEC sys.sp_set_session_context @key=N''VV_UNIVERSITY_ID'',@value=NULL;
  IF @Own=1 COMMIT;
  SELECT * FROM dbo.PERSONS WHERE PERSON_ID=@PersonId;
 END TRY
 BEGIN CATCH
  EXEC sys.sp_set_session_context @key=N''VV_SCHOOL_ID'',@value=NULL;
  EXEC sys.sp_set_session_context @key=N''VV_UNIVERSITY_ID'',@value=NULL;
  IF @Own=1 AND XACT_STATE()<>0 ROLLBACK;
  THROW;
 END CATCH
END;');
EXEC(N'CREATE OR ALTER TRIGGER dbo.TRG_SCHOOLS_GEOGRAPHY ON dbo.SCHOOLS AFTER INSERT,UPDATE AS
BEGIN
 SET NOCOUNT ON;
 IF EXISTS(SELECT 1 FROM inserted s JOIN dbo.CITIES c ON c.CITY_ID=s.CITY_ID WHERE c.PROVINCE_ID<>s.PROVINCE_ID)
 THROW 51015,''The school province must match the city province.'',1;
END;');
EXEC(N'CREATE OR ALTER TRIGGER dbo.TRG_CITIES_GEOGRAPHY ON dbo.CITIES AFTER UPDATE AS
BEGIN
 SET NOCOUNT ON;
 IF EXISTS(SELECT 1 FROM inserted c JOIN dbo.SCHOOLS s ON s.CITY_ID=c.CITY_ID WHERE s.PROVINCE_ID<>c.PROVINCE_ID)
 THROW 51015,''This city is used by a school in a different province.'',1;
END;');
DROP PROCEDURE dbo.usp_AlignRequiredIntColumn;
EXEC sys.sp_addextendedproperty @name=N'VarsityVaultERDVersion',@value=N'2.6.0';
 COMMIT;
 PRINT 'ERD alignment 2.6.0 completed. Existing person IDs, role identifiers, application references and passwords retained.';
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK;
 THROW;
END CATCH;
GO
