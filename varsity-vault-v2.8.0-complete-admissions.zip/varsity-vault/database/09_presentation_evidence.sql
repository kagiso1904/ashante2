USE [VARSITYVAULT2];
GO
-- Read-only evidence for video points 5 and 6.
-- Replace these two emails with the accounts you use in the recording.
DECLARE @RegistrationEmail varchar(100) = 'new-learner-email@example.com';
DECLARE @ResultsEmail varchar(100) = 'active-learner-email@example.com';

-- A: account creation. PERSON_ID is the learner subtype's PK and FK.
SELECT p.PERSON_ID,p.FIRST_NAME,p.LAST_NAME,p.EMAIL,
       l.PERSON_ID AS LEARNER_PK_FK,s.SCHOOL_NAME
FROM dbo.PERSONS p
JOIN dbo.LEARNERS l ON l.PERSON_ID=p.PERSON_ID
JOIN dbo.SCHOOLS s ON s.SCHOOL_ID=l.SCHOOL_ID
WHERE p.EMAIL=@RegistrationEmail;
SELECT a.PERSON_ID,a.USERNAME,a.DISABLED,
       CASE WHEN LEN(a.PASSWORD_HASH)>0 THEN 'Salted hash stored' ELSE 'Missing' END AS PasswordStorage
FROM [VarsityVaultSecurity].dbo.Accounts a
WHERE a.USERNAME=@RegistrationEmail;

-- B: mark capture/update and retrieval. Keep learner, subject and exam consistent.
SELECT p.PERSON_ID,p.FIRST_NAME,p.LAST_NAME,s.SUBJECT_NAME,
       e.EXAM_TYPE_NAME,r.PERCENTAGE
FROM dbo.LEARNER_RESULTS r
JOIN dbo.LEARNERS l ON l.PERSON_ID=r.LEARNER_ID
JOIN dbo.PERSONS p ON p.PERSON_ID=l.PERSON_ID
JOIN dbo.SUBJECTS s ON s.SUBJECT_ID=r.SUBJECT_ID
JOIN dbo.EXAM_TYPES e ON e.EXAM_TYPE_ID=r.EXAM_TYPE_ID
WHERE p.EMAIL=@ResultsEmail
ORDER BY e.EXAM_TYPE_NAME,s.SUBJECT_NAME;

-- C: run after create, update and delete. A deleted record produces zero rows.
SELECT PROGRAM_ID,PROGRAM_NAME FROM dbo.PROGRAMS
WHERE PROGRAM_NAME IN ('Digital Innovation','Digital Innovation and Business')
ORDER BY PROGRAM_ID;

-- D: admission data is stored in the existing academic and security databases.
SELECT u.UNIVERSITY_NAME,q.QUAL_NAME,r.MIN_APS_SCORE,
       JSON_VALUE(p.PAYLOAD,'$.scoring.label') AS ScoreMethod,
       JSON_QUERY(p.PAYLOAD,'$.subjectGroups') AS CommonSubjectRequirements,
       JSON_QUERY(p.PAYLOAD,'$.admissionRoutes') AS AlternativeSubjectRoutes,
       o.APPLICATION_CLOSING_DATE
FROM dbo.UNI_QUALIFICATIONS o
JOIN dbo.UNIVERSITIES u ON u.UNIVERSITY_ID=o.UNIVERSITY_ID
JOIN dbo.QUALIFICATIONS q ON q.QUAL_ID=o.QUAL_ID
JOIN dbo.QUALIFICATION_REQUIREMENTS r ON r.UNI_QUAL_ID=o.UNI_QUAL_ID
JOIN [VarsityVaultSecurity].dbo.Policies p ON p.UNI_QUAL_ID=o.UNI_QUAL_ID
WHERE JSON_VALUE(p.PAYLOAD,'$.requirementsImport')='complete-admissions-20261028'
ORDER BY u.UNIVERSITY_NAME,q.QUAL_NAME;
GO
