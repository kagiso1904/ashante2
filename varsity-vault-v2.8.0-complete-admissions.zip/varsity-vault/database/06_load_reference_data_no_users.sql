﻿/*
VARSITY VAULT 2.7 - MEANINGFUL REFERENCE CATALOGUE (SQL SERVER)
Prepared: 2026-10-28. Database: VARSITYVAULT2. Intake used by this app: 2028.

HOW TO RUN
1. Back up VARSITYVAULT2 and VarsityVaultSecurity in SSMS.
2. Stop the application while loading. Open this .sql file in SSMS against your
   existing SQL Server / SQLEXPRESS instance. Do not run an Oracle script.
3. This needs the existing academic schema and dbo.Policies in the existing
   VarsityVaultSecurity database. Use a login allowed to write both databases.
   If your app uses a different security database, change every occurrence of
   [VarsityVaultSecurity] below to its actual name before running.
4. Execute the WHOLE file (F5, with no text selected). It is one transaction.
5. Confirm the final 26-university / 260-selected-offering coverage report.
6. Restart the SQL Server-backed app and refresh Universities / Offerings.
   A representative/admin can verify sourced 2028 requirements and dates later.

WHAT THIS DOES
- Ensures 26 real public universities, 10 selected titles per university,
  useful programme categories, qualifications, provinces, selected cities,
  school subjects and the application's standard reference lists.
- Inserts only missing rows. Existing identifiers, names, policies, closing
  dates, requirements, fictional demo institutions and records are preserved.
- DOES NOT write PERSONS, role tables, Accounts, school records, documents,
  learner results, enrolments, applications, application processes or sessions.
- Does not change tables, columns, keys, constraints, or the ERD.
- May be rerun: matches by natural names / university aliases and website host;
  ambiguous existing duplicates abort with a rollback instead of guessing.

IMPORTANT DATA SCOPE
This is a selected catalogue, not an exhaustive national prospectus. 250 titles
come from your supplied Oracle export; 10 UMP titles come from official faculty
pages. Historical titles are not a certification of 2028 availability. No old
2027 dates, APS scores or subject rules are relabelled as verified 2028 rules.
Only newly inserted offerings receive a PENDING policy, NULL closing date and
NULL score thresholds. They are browseable but the existing app blocks applying
until a representative/admin verifies requirements, scoring and opening/closing
dates. Existing configured offerings keep their current behaviour.

Sources:
University directory: https://usaf.ac.za/prospective-students/
250 programme titles: your upload/report (6).csv (earlier Oracle catalogue).
UMP: official faculty pages recorded with each offering below.
Programme categories are local navigation groupings, not official faculty names.
University province is the principal-campus province, not a full campus list.
No fabricated users, prospectus files, official admissions thresholds or deadlines.
This script was statically checked and its matching logic tested locally;
it has NOT been executed against your Windows SQL Server by this assistant.
*/
USE [VARSITYVAULT2];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
IF @@TRANCOUNT <> 0
    THROW 51100, 'Use a fresh SSMS query with no open transaction.', 1;
IF OBJECT_ID(N'dbo.UNI_QUALIFICATIONS', N'U') IS NULL
 OR COL_LENGTH(N'dbo.QUALIFICATIONS',N'PROGRAM_ID') IS NULL
 OR COL_LENGTH(N'dbo.UNIVERSITIES',N'PROVINCE_ID') IS NULL
    THROW 51101, 'Expected Varsity Vault SQL Server schema is missing. Run the project setup/migrations first.', 1;
IF DB_ID(N'VarsityVaultSecurity') IS NULL
    THROW 51102, 'Existing VarsityVaultSecurity database is required. Check the database name in this script.', 1;
IF OBJECT_ID(N'[VarsityVaultSecurity].dbo.Policies',N'U') IS NULL
    THROW 51103, 'Existing VarsityVaultSecurity.dbo.Policies is required. Run database/security.sql first.', 1;

BEGIN TRY
BEGIN TRANSACTION;
DECLARE @LockResult int;
EXEC @LockResult = sys.sp_getapplock @Resource=N'VarsityVault.ReferenceCatalogue.2028',
    @LockMode=N'Exclusive', @LockOwner=N'Transaction', @LockTimeout=0;
IF @LockResult < 0 THROW 51104, 'Another catalogue load is running. Retry after it finishes.', 1;

DECLARE @Added TABLE (Entity varchar(60), RowsAdded int);
DECLARE @Province TABLE (Name varchar(50) PRIMARY KEY, ProvinceId int NULL);
INSERT @Province(Name) VALUES
    ('Eastern Cape'),('Free State'),('Gauteng'),('KwaZulu-Natal'),('Limpopo'),
    ('Mpumalanga'),('North West'),('Northern Cape'),('Western Cape');
UPDATE s SET ProvinceId=p.PROVINCE_ID FROM @Province s JOIN dbo.PROVINCES p
 ON REPLACE(REPLACE(LOWER(LTRIM(RTRIM(p.PROVINCE_NAME))),'-',''),' ','')=
    REPLACE(REPLACE(LOWER(s.Name),'-',''),' ','');
IF EXISTS (SELECT s.Name FROM @Province s JOIN dbo.PROVINCES p
 ON REPLACE(REPLACE(LOWER(LTRIM(RTRIM(p.PROVINCE_NAME))),'-',''),' ','')=
    REPLACE(REPLACE(LOWER(s.Name),'-',''),' ','') GROUP BY s.Name HAVING COUNT(*)>1)
 THROW 51105, 'Duplicate province aliases found. Resolve them before loading.', 1;
INSERT dbo.PROVINCES(PROVINCE_NAME) SELECT Name FROM @Province WHERE ProvinceId IS NULL;
INSERT @Added VALUES ('Provinces',@@ROWCOUNT);
UPDATE s SET ProvinceId=p.PROVINCE_ID FROM @Province s JOIN dbo.PROVINCES p
 ON REPLACE(REPLACE(LOWER(LTRIM(RTRIM(p.PROVINCE_NAME))),'-',''),' ','')=
    REPLACE(REPLACE(LOWER(s.Name),'-',''),' ','');

DECLARE @University TABLE (
 Name varchar(150) PRIMARY KEY, Host varchar(100), Province varchar(50), City varchar(100), UniversityId int NULL
);
INSERT @University(Name,Host,Province,City) VALUES
    (N'Cape Peninsula University of Technology', N'cput.ac.za', N'Western Cape', N'Cape Town'),
    (N'Central University of Technology', N'cut.ac.za', N'Free State', N'Bloemfontein'),
    (N'Durban University of Technology', N'dut.ac.za', N'KwaZulu-Natal', N'Durban'),
    (N'Mangosuthu University of Technology', N'mut.ac.za', N'KwaZulu-Natal', N'Durban'),
    (N'Nelson Mandela University', N'mandela.ac.za', N'Eastern Cape', N'Gqeberha'),
    (N'North-West University', N'nwu.ac.za', N'North West', N'Potchefstroom'),
    (N'Rhodes University', N'ru.ac.za', N'Eastern Cape', N'Makhanda'),
    (N'Sefako Makgatho Health Sciences University', N'smu.ac.za', N'Gauteng', N'Pretoria'),
    (N'Sol Plaatje University', N'spu.ac.za', N'Northern Cape', N'Kimberley'),
    (N'Stellenbosch University', N'sun.ac.za', N'Western Cape', N'Stellenbosch'),
    (N'Tshwane University of Technology', N'tut.ac.za', N'Gauteng', N'Pretoria'),
    (N'University of Cape Town', N'uct.ac.za', N'Western Cape', N'Cape Town'),
    (N'University of Fort Hare', N'ufh.ac.za', N'Eastern Cape', N'Alice'),
    (N'University of Johannesburg', N'uj.ac.za', N'Gauteng', N'Johannesburg'),
    (N'University of KwaZulu-Natal', N'ukzn.ac.za', N'KwaZulu-Natal', N'Durban'),
    (N'University of Limpopo', N'ul.ac.za', N'Limpopo', N'Mankweng'),
    (N'University of Mpumalanga', N'ump.ac.za', N'Mpumalanga', N'Mbombela'),
    (N'University of Pretoria', N'up.ac.za', N'Gauteng', N'Pretoria'),
    (N'University of South Africa', N'unisa.ac.za', N'Gauteng', N'Pretoria'),
    (N'University of Venda', N'univen.ac.za', N'Limpopo', N'Thohoyandou'),
    (N'University of Zululand', N'unizulu.ac.za', N'KwaZulu-Natal', N'KwaDlangezwa'),
    (N'University of the Free State', N'ufs.ac.za', N'Free State', N'Bloemfontein'),
    (N'University of the Western Cape', N'uwc.ac.za', N'Western Cape', N'Cape Town'),
    (N'University of the Witwatersrand', N'wits.ac.za', N'Gauteng', N'Johannesburg'),
    (N'Vaal University of Technology', N'vut.ac.za', N'Gauteng', N'Vanderbijlpark'),
    (N'Walter Sisulu University', N'wsu.ac.za', N'Eastern Cape', N'Mthatha');

DECLARE @Alias TABLE (Canonical varchar(150), Alias varchar(150), PRIMARY KEY(Canonical,Alias));
INSERT @Alias VALUES
    (N'Cape Peninsula University of Technology', N'Cape Peninsula University of Technology'),
    (N'Central University of Technology', N'Central University of Technology'),
    (N'Durban University of Technology', N'Durban University of Technology'),
    (N'Mangosuthu University of Technology', N'Mangosuthu University of Technology'),
    (N'Nelson Mandela University', N'Nelson Mandela University'),
    (N'North-West University', N'North-West University'),
    (N'Rhodes University', N'Rhodes University'),
    (N'Sefako Makgatho Health Sciences University', N'Sefako Makgatho Health Sciences University'),
    (N'Sol Plaatje University', N'Sol Plaatje University'),
    (N'Stellenbosch University', N'Stellenbosch University'),
    (N'Tshwane University of Technology', N'Tshwane University of Technology'),
    (N'University of Cape Town', N'University of Cape Town'),
    (N'University of Fort Hare', N'University of Fort Hare'),
    (N'University of Johannesburg', N'University of Johannesburg'),
    (N'University of KwaZulu-Natal', N'University of KwaZulu-Natal'),
    (N'University of Limpopo', N'University of Limpopo'),
    (N'University of Mpumalanga', N'University of Mpumalanga'),
    (N'University of Pretoria', N'University of Pretoria'),
    (N'University of South Africa', N'University of South Africa'),
    (N'University of Venda', N'University of Venda'),
    (N'University of Zululand', N'University of Zululand'),
    (N'University of the Free State', N'University of the Free State'),
    (N'University of the Western Cape', N'University of the Western Cape'),
    (N'University of the Witwatersrand', N'University of the Witwatersrand'),
    (N'Vaal University of Technology', N'Vaal University of Technology'),
    (N'Walter Sisulu University', N'Walter Sisulu University'),
    (N'Walter Sisulu University', N'iYunivesithi Walter Sisulu'),
    (N'Walter Sisulu University', N'iYunivesithi Walter Sisulu University'),
    (N'Nelson Mandela University', N'Nelson Mandela Metropolitan University'),
    (N'North-West University', N'North West University'),
    (N'University of KwaZulu-Natal', N'University of KwaZulu Natal'),
    (N'University of the Witwatersrand', N'University of Witwatersrand'),
    (N'Sol Plaatje University', N'Sol Plaatjie University');

DECLARE @UniversityMatch TABLE (Name varchar(150), UniversityId int, PRIMARY KEY(Name,UniversityId));
INSERT @UniversityMatch
SELECT DISTINCT s.Name,u.UNIVERSITY_ID FROM @University s CROSS JOIN dbo.UNIVERSITIES u
CROSS APPLY (SELECT LOWER(REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(COALESCE(u.WEBSITE,''))),
 'https://',''),'http://',''),'www.','')) AS DomainPath) d
CROSS APPLY (SELECT LEFT(d.DomainPath,CHARINDEX('/',d.DomainPath+'/')-1) AS Host) h
WHERE h.Host=s.Host OR EXISTS (SELECT 1 FROM @Alias a WHERE a.Canonical=s.Name
 AND LOWER(LTRIM(RTRIM(u.UNIVERSITY_NAME)))=LOWER(a.Alias));
IF EXISTS (SELECT Name FROM @UniversityMatch GROUP BY Name HAVING COUNT(*)>1)
 OR EXISTS (SELECT UniversityId FROM @UniversityMatch GROUP BY UniversityId HAVING COUNT(*)>1)
 THROW 51106, 'Ambiguous existing university duplicates. No data changed; resolve the duplicate institutions first.', 1;
UPDATE s SET UniversityId=m.UniversityId FROM @University s JOIN @UniversityMatch m ON m.Name=s.Name;
INSERT dbo.UNIVERSITIES(UNIVERSITY_NAME,WEBSITE,PROVINCE_ID)
SELECT s.Name,'https://www.'+s.Host+'/',p.ProvinceId FROM @University s JOIN @Province p ON p.Name=s.Province
WHERE s.UniversityId IS NULL;
INSERT @Added VALUES ('Universities',@@ROWCOUNT);
UPDATE s SET UniversityId=u.UNIVERSITY_ID FROM @University s JOIN dbo.UNIVERSITIES u
 ON LOWER(LTRIM(RTRIM(u.UNIVERSITY_NAME)))=LOWER(s.Name) WHERE s.UniversityId IS NULL;
IF EXISTS (SELECT 1 FROM @University WHERE UniversityId IS NULL)
 THROW 51107, 'A university could not be resolved.', 1;

-- Cities are matched by name AND province. Existing geography is not overwritten.
DECLARE @City TABLE(Name varchar(100), Province varchar(50), PRIMARY KEY(Name,Province));
INSERT @City SELECT DISTINCT City,Province FROM @University;
INSERT @City VALUES ('Mahikeng','North West'),('Siyabuswa','Mpumalanga'),('Komani','Eastern Cape'),
 ('Pietermaritzburg','KwaZulu-Natal'),('George','Western Cape'),('East London','Eastern Cape');
INSERT dbo.CITIES(CITY_NAME,PROVINCE_ID)
SELECT c.Name,p.ProvinceId FROM @City c JOIN @Province p ON p.Name=c.Province
WHERE NOT EXISTS (SELECT 1 FROM dbo.CITIES x WHERE LOWER(LTRIM(RTRIM(x.CITY_NAME)))=LOWER(c.Name)
 AND x.PROVINCE_ID=p.ProvinceId);
INSERT @Added VALUES ('Selected cities',@@ROWCOUNT);

DECLARE @Catalogue TABLE (
 University varchar(150), Qualification varchar(150), Programme varchar(100),
 Source nvarchar(2000), Origin nvarchar(300), PRIMARY KEY(University,Qualification)
);
INSERT @Catalogue VALUES
    (N'Cape Peninsula University of Technology', N'Bachelor in Environmental Health', N'Health Sciences', N'https://embed-rech-01.dialog.cm/cput6/docs/a4-prospectus-2026-1124-web', N'User Oracle export report (6).csv; offering 7; earlier prospectus edition, 2028 unconfirmed'),
    (N'Cape Peninsula University of Technology', N'Diploma in Agricultural Management', N'Agriculture and Environmental Studies', N'https://embed-rech-01.dialog.cm/cput6/docs/a4-prospectus-2026-1124-web', N'User Oracle export report (6).csv; offering 2; earlier prospectus edition, 2028 unconfirmed'),
    (N'Cape Peninsula University of Technology', N'Diploma in Agriculture', N'Agriculture and Environmental Studies', N'https://embed-rech-01.dialog.cm/cput6/docs/a4-prospectus-2026-1124-web', N'User Oracle export report (6).csv; offering 1; earlier prospectus edition, 2028 unconfirmed'),
    (N'Cape Peninsula University of Technology', N'Diploma in Analytical Chemistry', N'Natural and Mathematical Sciences', N'https://embed-rech-01.dialog.cm/cput6/docs/a4-prospectus-2026-1124-web', N'User Oracle export report (6).csv; offering 4; earlier prospectus edition, 2028 unconfirmed'),
    (N'Cape Peninsula University of Technology', N'Diploma in Biotechnology', N'Natural and Mathematical Sciences', N'https://embed-rech-01.dialog.cm/cput6/docs/a4-prospectus-2026-1124-web', N'User Oracle export report (6).csv; offering 3; earlier prospectus edition, 2028 unconfirmed'),
    (N'Cape Peninsula University of Technology', N'Diploma in Consumer Science: Food and Nutrition', N'Natural and Mathematical Sciences', N'https://embed-rech-01.dialog.cm/cput6/docs/a4-prospectus-2026-1124-web', N'User Oracle export report (6).csv; offering 5; earlier prospectus edition, 2028 unconfirmed'),
    (N'Cape Peninsula University of Technology', N'Diploma in Environmental Management', N'Agriculture and Environmental Studies', N'https://embed-rech-01.dialog.cm/cput6/docs/a4-prospectus-2026-1124-web', N'User Oracle export report (6).csv; offering 6; earlier prospectus edition, 2028 unconfirmed'),
    (N'Cape Peninsula University of Technology', N'Diploma in Horticulture', N'Agriculture and Environmental Studies', N'https://embed-rech-01.dialog.cm/cput6/docs/a4-prospectus-2026-1124-web', N'User Oracle export report (6).csv; offering 8; earlier prospectus edition, 2028 unconfirmed'),
    (N'Cape Peninsula University of Technology', N'Diploma in Landscape Architecture', N'Agriculture and Environmental Studies', N'https://embed-rech-01.dialog.cm/cput6/docs/a4-prospectus-2026-1124-web', N'User Oracle export report (6).csv; offering 9; earlier prospectus edition, 2028 unconfirmed'),
    (N'Cape Peninsula University of Technology', N'Diploma in Mathematical Sciences', N'Natural and Mathematical Sciences', N'https://embed-rech-01.dialog.cm/cput6/docs/a4-prospectus-2026-1124-web', N'User Oracle export report (6).csv; offering 10; earlier prospectus edition, 2028 unconfirmed'),
    (N'Central University of Technology', N'Bachelor of Management Sciences in Accountancy', N'Accounting and Finance', N'https://www.cut.ac.za/programmes-offered', N'User Oracle export report (6).csv; offering 16; earlier prospectus edition, 2028 unconfirmed'),
    (N'Central University of Technology', N'Bachelor of Management Sciences in Internal Auditing', N'Accounting and Finance', N'https://www.cut.ac.za/programmes-offered', N'User Oracle export report (6).csv; offering 18; earlier prospectus edition, 2028 unconfirmed'),
    (N'Central University of Technology', N'Diploma in Hospitality Management', N'Hospitality and Tourism', N'https://www.cut.ac.za/programmes-offered', N'User Oracle export report (6).csv; offering 13; earlier prospectus edition, 2028 unconfirmed'),
    (N'Central University of Technology', N'Diploma in Human Resources Management', N'Business and Economics', N'https://www.cut.ac.za/programmes-offered', N'User Oracle export report (6).csv; offering 15; earlier prospectus edition, 2028 unconfirmed'),
    (N'Central University of Technology', N'Diploma in Management', N'Business and Economics', N'https://www.cut.ac.za/programmes-offered', N'User Oracle export report (6).csv; offering 17; earlier prospectus edition, 2028 unconfirmed'),
    (N'Central University of Technology', N'Diploma in Marketing Management', N'Business and Economics', N'https://www.cut.ac.za/programmes-offered', N'User Oracle export report (6).csv; offering 19; earlier prospectus edition, 2028 unconfirmed'),
    (N'Central University of Technology', N'Diploma in Office Management and Technology', N'Public Administration and Management', N'https://www.cut.ac.za/programmes-offered', N'User Oracle export report (6).csv; offering 20; earlier prospectus edition, 2028 unconfirmed'),
    (N'Central University of Technology', N'Diploma in Public Management', N'Public Administration and Management', N'https://www.cut.ac.za/programmes-offered', N'User Oracle export report (6).csv; offering 12; earlier prospectus edition, 2028 unconfirmed'),
    (N'Central University of Technology', N'Diploma in Tourism Management', N'Hospitality and Tourism', N'https://www.cut.ac.za/programmes-offered', N'User Oracle export report (6).csv; offering 14; earlier prospectus edition, 2028 unconfirmed'),
    (N'Central University of Technology', N'Higher Certificate in Community Development Work', N'Humanities and Social Sciences', N'https://www.cut.ac.za/programmes-offered', N'User Oracle export report (6).csv; offering 11; earlier prospectus edition, 2028 unconfirmed'),
    (N'Durban University of Technology', N'Bachelor of Information and Communications Technology', N'Information Technology and Computing', N'https://www.dut.ac.za/wp-content/uploads/2026/06/Study-Opportunities-2027.pdf', N'User Oracle export report (6).csv; offering 21; earlier prospectus edition, 2028 unconfirmed'),
    (N'Durban University of Technology', N'Bachelor of Information and Communications Technology (Internet of Things)', N'Information Technology and Computing', N'https://www.dut.ac.za/wp-content/uploads/2026/06/Study-Opportunities-2027.pdf', N'User Oracle export report (6).csv; offering 22; earlier prospectus edition, 2028 unconfirmed'),
    (N'Durban University of Technology', N'Diploma in Accounting', N'Accounting and Finance', N'https://www.dut.ac.za/wp-content/uploads/2026/06/Study-Opportunities-2027.pdf', N'User Oracle export report (6).csv; offering 23; earlier prospectus edition, 2028 unconfirmed'),
    (N'Durban University of Technology', N'Diploma in Business and Information Management', N'Information Technology and Computing', N'https://www.dut.ac.za/wp-content/uploads/2026/06/Study-Opportunities-2027.pdf', N'User Oracle export report (6).csv; offering 24; earlier prospectus edition, 2028 unconfirmed'),
    (N'Durban University of Technology', N'Diploma in Information and Communications Technology: Application Development', N'Information Technology and Computing', N'https://www.dut.ac.za/wp-content/uploads/2026/06/Study-Opportunities-2027.pdf', N'User Oracle export report (6).csv; offering 25; earlier prospectus edition, 2028 unconfirmed'),
    (N'Durban University of Technology', N'Diploma in Information and Communications Technology: Business Analysis', N'Information Technology and Computing', N'https://www.dut.ac.za/wp-content/uploads/2026/06/Study-Opportunities-2027.pdf', N'User Oracle export report (6).csv; offering 26; earlier prospectus edition, 2028 unconfirmed'),
    (N'Durban University of Technology', N'Diploma in Internal Auditing', N'Accounting and Finance', N'https://www.dut.ac.za/wp-content/uploads/2026/06/Study-Opportunities-2027.pdf', N'User Oracle export report (6).csv; offering 27; earlier prospectus edition, 2028 unconfirmed'),
    (N'Durban University of Technology', N'Diploma in Library and Information Studies', N'Library and Information Science', N'https://www.dut.ac.za/wp-content/uploads/2026/06/Study-Opportunities-2027.pdf', N'User Oracle export report (6).csv; offering 28; earlier prospectus edition, 2028 unconfirmed'),
    (N'Durban University of Technology', N'Diploma in Management Accounting', N'Accounting and Finance', N'https://www.dut.ac.za/wp-content/uploads/2026/06/Study-Opportunities-2027.pdf', N'User Oracle export report (6).csv; offering 29; earlier prospectus edition, 2028 unconfirmed'),
    (N'Durban University of Technology', N'Diploma in Taxation', N'Accounting and Finance', N'https://www.dut.ac.za/wp-content/uploads/2026/06/Study-Opportunities-2027.pdf', N'User Oracle export report (6).csv; offering 30; earlier prospectus edition, 2028 unconfirmed'),
    (N'Mangosuthu University of Technology', N'Bachelor of Health Sciences in Medical Laboratory Science', N'Health Sciences', N'https://www.mut.ac.za/', N'User Oracle export report (6).csv; offering 37; earlier prospectus edition, 2028 unconfirmed'),
    (N'Mangosuthu University of Technology', N'Bachelor of Science in Environmental Health', N'Health Sciences', N'https://www.mut.ac.za/', N'User Oracle export report (6).csv; offering 36; earlier prospectus edition, 2028 unconfirmed'),
    (N'Mangosuthu University of Technology', N'Diploma in Agriculture', N'Agriculture and Environmental Studies', N'https://www.mut.ac.za/', N'User Oracle export report (6).csv; offering 31; earlier prospectus edition, 2028 unconfirmed'),
    (N'Mangosuthu University of Technology', N'Diploma in Analytical Chemistry', N'Natural and Mathematical Sciences', N'https://www.mut.ac.za/', N'User Oracle export report (6).csv; offering 32; earlier prospectus edition, 2028 unconfirmed'),
    (N'Mangosuthu University of Technology', N'Diploma in Building', N'Built Environment', N'https://www.mut.ac.za/', N'User Oracle export report (6).csv; offering 38; earlier prospectus edition, 2028 unconfirmed'),
    (N'Mangosuthu University of Technology', N'Diploma in Chemical Engineering', N'Engineering and Technology', N'https://www.mut.ac.za/', N'User Oracle export report (6).csv; offering 39; earlier prospectus edition, 2028 unconfirmed'),
    (N'Mangosuthu University of Technology', N'Diploma in Civil Engineering', N'Engineering and Technology', N'https://www.mut.ac.za/', N'User Oracle export report (6).csv; offering 40; earlier prospectus edition, 2028 unconfirmed'),
    (N'Mangosuthu University of Technology', N'Diploma in Community Extension', N'Humanities and Social Sciences', N'https://www.mut.ac.za/', N'User Oracle export report (6).csv; offering 33; earlier prospectus edition, 2028 unconfirmed'),
    (N'Mangosuthu University of Technology', N'Diploma in Information Technology', N'Information Technology and Computing', N'https://www.mut.ac.za/', N'User Oracle export report (6).csv; offering 34; earlier prospectus edition, 2028 unconfirmed'),
    (N'Mangosuthu University of Technology', N'Diploma in Nature Conservation', N'Agriculture and Environmental Studies', N'https://www.mut.ac.za/', N'User Oracle export report (6).csv; offering 35; earlier prospectus edition, 2028 unconfirmed'),
    (N'Nelson Mandela University', N'Bachelor of Commerce (Accounting)', N'Accounting and Finance', N'https://www.mandela.ac.za/www-new/media/Store/documents/StudyAtMandela/QuickGuides/Apply/NMU-Z-CARD-UNDERGRAD-PROGRAMME_DIGITAL-FA.pdf', N'User Oracle export report (6).csv; offering 41; earlier prospectus edition, 2028 unconfirmed'),
    (N'Nelson Mandela University', N'Bachelor of Commerce (Computer Science and Information Systems)', N'Information Technology and Computing', N'https://www.mandela.ac.za/www-new/media/Store/documents/StudyAtMandela/QuickGuides/Apply/NMU-Z-CARD-UNDERGRAD-PROGRAMME_DIGITAL-FA.pdf', N'User Oracle export report (6).csv; offering 45; earlier prospectus edition, 2028 unconfirmed'),
    (N'Nelson Mandela University', N'Bachelor of Commerce (Economics and Statistics)', N'Business and Economics', N'https://www.mandela.ac.za/www-new/media/Store/documents/StudyAtMandela/QuickGuides/Apply/NMU-Z-CARD-UNDERGRAD-PROGRAMME_DIGITAL-FA.pdf', N'User Oracle export report (6).csv; offering 49; earlier prospectus edition, 2028 unconfirmed'),
    (N'Nelson Mandela University', N'Bachelor of Education: Foundation Phase', N'Education', N'https://www.mandela.ac.za/www-new/media/Store/documents/StudyAtMandela/QuickGuides/Apply/NMU-Z-CARD-UNDERGRAD-PROGRAMME_DIGITAL-FA.pdf', N'User Oracle export report (6).csv; offering 50; earlier prospectus edition, 2028 unconfirmed'),
    (N'Nelson Mandela University', N'Bachelor of Engineering Technology in Civil Engineering', N'Engineering and Technology', N'https://www.mandela.ac.za/www-new/media/Store/documents/StudyAtMandela/QuickGuides/Apply/NMU-Z-CARD-UNDERGRAD-PROGRAMME_DIGITAL-FA.pdf', N'User Oracle export report (6).csv; offering 44; earlier prospectus edition, 2028 unconfirmed'),
    (N'Nelson Mandela University', N'Bachelor of Science (Construction Management)', N'Built Environment', N'https://www.mandela.ac.za/www-new/media/Store/documents/StudyAtMandela/QuickGuides/Apply/NMU-Z-CARD-UNDERGRAD-PROGRAMME_DIGITAL-FA.pdf', N'User Oracle export report (6).csv; offering 47; earlier prospectus edition, 2028 unconfirmed'),
    (N'Nelson Mandela University', N'Bachelor of Science (Dietetics)', N'Health Sciences', N'https://www.mandela.ac.za/www-new/media/Store/documents/StudyAtMandela/QuickGuides/Apply/NMU-Z-CARD-UNDERGRAD-PROGRAMME_DIGITAL-FA.pdf', N'User Oracle export report (6).csv; offering 48; earlier prospectus edition, 2028 unconfirmed'),
    (N'Nelson Mandela University', N'Bachelor of Science in Construction Economics', N'Built Environment', N'https://www.mandela.ac.za/www-new/media/Store/documents/StudyAtMandela/QuickGuides/Apply/NMU-Z-CARD-UNDERGRAD-PROGRAMME_DIGITAL-FA.pdf', N'User Oracle export report (6).csv; offering 46; earlier prospectus edition, 2028 unconfirmed'),
    (N'Nelson Mandela University', N'Diploma in Analytical Chemistry', N'Natural and Mathematical Sciences', N'https://www.mandela.ac.za/www-new/media/Store/documents/StudyAtMandela/QuickGuides/Apply/NMU-Z-CARD-UNDERGRAD-PROGRAMME_DIGITAL-FA.pdf', N'User Oracle export report (6).csv; offering 42; earlier prospectus edition, 2028 unconfirmed'),
    (N'Nelson Mandela University', N'Diploma in Chemical Process Technology', N'Engineering and Technology', N'https://www.mandela.ac.za/www-new/media/Store/documents/StudyAtMandela/QuickGuides/Apply/NMU-Z-CARD-UNDERGRAD-PROGRAMME_DIGITAL-FA.pdf', N'User Oracle export report (6).csv; offering 43; earlier prospectus edition, 2028 unconfirmed'),
    (N'North-West University', N'Bachelor of Health Sciences in Occupational Hygiene', N'Health Sciences', N'https://studies.nwu.ac.za/sites/studies.nwu.ac.za/files/files/undergrad/2027-Grade-12-prospectus.pdf', N'User Oracle export report (6).csv; offering 60; earlier prospectus edition, 2028 unconfirmed'),
    (N'North-West University', N'Bachelor of Nursing', N'Health Sciences', N'https://studies.nwu.ac.za/sites/studies.nwu.ac.za/files/files/undergrad/2027-Grade-12-prospectus.pdf', N'User Oracle export report (6).csv; offering 58; earlier prospectus edition, 2028 unconfirmed'),
    (N'North-West University', N'Bachelor of Science in Actuarial Sciences', N'Accounting and Finance', N'https://studies.nwu.ac.za/sites/studies.nwu.ac.za/files/files/undergrad/2027-Grade-12-prospectus.pdf', N'User Oracle export report (6).csv; offering 55; earlier prospectus edition, 2028 unconfirmed'),
    (N'North-West University', N'Bachelor of Science in Business Analytics', N'Information Technology and Computing', N'https://studies.nwu.ac.za/sites/studies.nwu.ac.za/files/files/undergrad/2027-Grade-12-prospectus.pdf', N'User Oracle export report (6).csv; offering 53; earlier prospectus edition, 2028 unconfirmed'),
    (N'North-West University', N'Bachelor of Science in Dietetics', N'Health Sciences', N'https://studies.nwu.ac.za/sites/studies.nwu.ac.za/files/files/undergrad/2027-Grade-12-prospectus.pdf', N'User Oracle export report (6).csv; offering 59; earlier prospectus edition, 2028 unconfirmed'),
    (N'North-West University', N'Bachelor of Science in Financial Mathematics', N'Accounting and Finance', N'https://studies.nwu.ac.za/sites/studies.nwu.ac.za/files/files/undergrad/2027-Grade-12-prospectus.pdf', N'User Oracle export report (6).csv; offering 52; earlier prospectus edition, 2028 unconfirmed'),
    (N'North-West University', N'Bachelor of Science in Information Technology', N'Information Technology and Computing', N'https://studies.nwu.ac.za/sites/studies.nwu.ac.za/files/files/undergrad/2027-Grade-12-prospectus.pdf', N'User Oracle export report (6).csv; offering 51; earlier prospectus edition, 2028 unconfirmed'),
    (N'North-West University', N'Bachelor of Science in Quantitative Risk Management', N'Accounting and Finance', N'https://studies.nwu.ac.za/sites/studies.nwu.ac.za/files/files/undergrad/2027-Grade-12-prospectus.pdf', N'User Oracle export report (6).csv; offering 54; earlier prospectus edition, 2028 unconfirmed'),
    (N'North-West University', N'Bachelor of Science in Urban and Regional Planning', N'Built Environment', N'https://studies.nwu.ac.za/sites/studies.nwu.ac.za/files/files/undergrad/2027-Grade-12-prospectus.pdf', N'User Oracle export report (6).csv; offering 56; earlier prospectus edition, 2028 unconfirmed'),
    (N'North-West University', N'Bachelor of Social Work', N'Humanities and Social Sciences', N'https://studies.nwu.ac.za/sites/studies.nwu.ac.za/files/files/undergrad/2027-Grade-12-prospectus.pdf', N'User Oracle export report (6).csv; offering 57; earlier prospectus edition, 2028 unconfirmed'),
    (N'Rhodes University', N'Bachelor of Arts', N'Humanities and Social Sciences', N'https://www.ru.ac.za/media/rhodesuniversity/content/registrar/documents/information/studentrecruitment/RU_READY_Undergraduate_Prospectus_2026_DIGITAL_A5_Landscape_24pp_18Mar2026.pdf', N'User Oracle export report (6).csv; offering 64; earlier prospectus edition, 2028 unconfirmed'),
    (N'Rhodes University', N'Bachelor of Business Science', N'Business and Economics', N'https://www.ru.ac.za/media/rhodesuniversity/content/registrar/documents/information/studentrecruitment/RU_READY_Undergraduate_Prospectus_2026_DIGITAL_A5_Landscape_24pp_18Mar2026.pdf', N'User Oracle export report (6).csv; offering 61; earlier prospectus edition, 2028 unconfirmed'),
    (N'Rhodes University', N'Bachelor of Commerce', N'Business and Economics', N'https://www.ru.ac.za/media/rhodesuniversity/content/registrar/documents/information/studentrecruitment/RU_READY_Undergraduate_Prospectus_2026_DIGITAL_A5_Landscape_24pp_18Mar2026.pdf', N'User Oracle export report (6).csv; offering 62; earlier prospectus edition, 2028 unconfirmed'),
    (N'Rhodes University', N'Bachelor of Economics', N'Business and Economics', N'https://www.ru.ac.za/media/rhodesuniversity/content/registrar/documents/information/studentrecruitment/RU_READY_Undergraduate_Prospectus_2026_DIGITAL_A5_Landscape_24pp_18Mar2026.pdf', N'User Oracle export report (6).csv; offering 63; earlier prospectus edition, 2028 unconfirmed'),
    (N'Rhodes University', N'Bachelor of Education (Foundation Phase Teaching)', N'Education', N'https://www.ru.ac.za/media/rhodesuniversity/content/registrar/documents/information/studentrecruitment/RU_READY_Undergraduate_Prospectus_2026_DIGITAL_A5_Landscape_24pp_18Mar2026.pdf', N'User Oracle export report (6).csv; offering 69; earlier prospectus edition, 2028 unconfirmed'),
    (N'Rhodes University', N'Bachelor of Fine Arts', N'Arts and Design', N'https://www.ru.ac.za/media/rhodesuniversity/content/registrar/documents/information/studentrecruitment/RU_READY_Undergraduate_Prospectus_2026_DIGITAL_A5_Landscape_24pp_18Mar2026.pdf', N'User Oracle export report (6).csv; offering 66; earlier prospectus edition, 2028 unconfirmed'),
    (N'Rhodes University', N'Bachelor of Journalism', N'Humanities and Social Sciences', N'https://www.ru.ac.za/media/rhodesuniversity/content/registrar/documents/information/studentrecruitment/RU_READY_Undergraduate_Prospectus_2026_DIGITAL_A5_Landscape_24pp_18Mar2026.pdf', N'User Oracle export report (6).csv; offering 68; earlier prospectus edition, 2028 unconfirmed'),
    (N'Rhodes University', N'Bachelor of Music', N'Arts and Design', N'https://www.ru.ac.za/media/rhodesuniversity/content/registrar/documents/information/studentrecruitment/RU_READY_Undergraduate_Prospectus_2026_DIGITAL_A5_Landscape_24pp_18Mar2026.pdf', N'User Oracle export report (6).csv; offering 67; earlier prospectus edition, 2028 unconfirmed'),
    (N'Rhodes University', N'Bachelor of Pharmacy', N'Health Sciences', N'https://www.ru.ac.za/media/rhodesuniversity/content/registrar/documents/information/studentrecruitment/RU_READY_Undergraduate_Prospectus_2026_DIGITAL_A5_Landscape_24pp_18Mar2026.pdf', N'User Oracle export report (6).csv; offering 70; earlier prospectus edition, 2028 unconfirmed'),
    (N'Rhodes University', N'Bachelor of Social Science', N'Humanities and Social Sciences', N'https://www.ru.ac.za/media/rhodesuniversity/content/registrar/documents/information/studentrecruitment/RU_READY_Undergraduate_Prospectus_2026_DIGITAL_A5_Landscape_24pp_18Mar2026.pdf', N'User Oracle export report (6).csv; offering 65; earlier prospectus edition, 2028 unconfirmed'),
    (N'Sefako Makgatho Health Sciences University', N'Bachelor of Dental Surgery', N'Health Sciences', N'https://www.smu.ac.za/schools/science-and-technology/school-of-science-and-technology-undergraduate-programmes/', N'User Oracle export report (6).csv; offering 75; earlier prospectus edition, 2028 unconfirmed'),
    (N'Sefako Makgatho Health Sciences University', N'Bachelor of Dental Therapy', N'Health Sciences', N'https://www.smu.ac.za/schools/science-and-technology/school-of-science-and-technology-undergraduate-programmes/', N'User Oracle export report (6).csv; offering 76; earlier prospectus edition, 2028 unconfirmed'),
    (N'Sefako Makgatho Health Sciences University', N'Bachelor of Medicine and Bachelor of Surgery', N'Health Sciences', N'https://www.smu.ac.za/schools/science-and-technology/school-of-science-and-technology-undergraduate-programmes/', N'User Oracle export report (6).csv; offering 80; earlier prospectus edition, 2028 unconfirmed'),
    (N'Sefako Makgatho Health Sciences University', N'Bachelor of Nursing and Midwifery', N'Health Sciences', N'https://www.smu.ac.za/schools/science-and-technology/school-of-science-and-technology-undergraduate-programmes/', N'User Oracle export report (6).csv; offering 79; earlier prospectus edition, 2028 unconfirmed'),
    (N'Sefako Makgatho Health Sciences University', N'Bachelor of Oral Hygiene', N'Health Sciences', N'https://www.smu.ac.za/schools/science-and-technology/school-of-science-and-technology-undergraduate-programmes/', N'User Oracle export report (6).csv; offering 77; earlier prospectus edition, 2028 unconfirmed'),
    (N'Sefako Makgatho Health Sciences University', N'Bachelor of Science in Dietetics', N'Health Sciences', N'https://www.smu.ac.za/schools/science-and-technology/school-of-science-and-technology-undergraduate-programmes/', N'User Oracle export report (6).csv; offering 78; earlier prospectus edition, 2028 unconfirmed'),
    (N'Sefako Makgatho Health Sciences University', N'Bachelor of Science in Life Sciences', N'Natural and Mathematical Sciences', N'https://www.smu.ac.za/schools/science-and-technology/school-of-science-and-technology-undergraduate-programmes/', N'User Oracle export report (6).csv; offering 71; earlier prospectus edition, 2028 unconfirmed'),
    (N'Sefako Makgatho Health Sciences University', N'Bachelor of Science in Mathematical Sciences', N'Natural and Mathematical Sciences', N'https://www.smu.ac.za/schools/science-and-technology/school-of-science-and-technology-undergraduate-programmes/', N'User Oracle export report (6).csv; offering 72; earlier prospectus edition, 2028 unconfirmed'),
    (N'Sefako Makgatho Health Sciences University', N'Bachelor of Science in Occupational and Environmental Health Sciences', N'Health Sciences', N'https://www.smu.ac.za/schools/science-and-technology/school-of-science-and-technology-undergraduate-programmes/', N'User Oracle export report (6).csv; offering 74; earlier prospectus edition, 2028 unconfirmed'),
    (N'Sefako Makgatho Health Sciences University', N'Bachelor of Science in Physical Sciences', N'Natural and Mathematical Sciences', N'https://www.smu.ac.za/schools/science-and-technology/school-of-science-and-technology-undergraduate-programmes/', N'User Oracle export report (6).csv; offering 73; earlier prospectus edition, 2028 unconfirmed'),
    (N'Sol Plaatje University', N'Bachelor of Arts', N'Humanities and Social Sciences', N'https://www.spu.ac.za/wp-content/uploads/2025/04/2026-Undergraduate-Prospectus.pdf', N'User Oracle export report (6).csv; offering 87; earlier prospectus edition, 2028 unconfirmed'),
    (N'Sol Plaatje University', N'Bachelor of Commerce in Accounting', N'Accounting and Finance', N'https://www.spu.ac.za/wp-content/uploads/2025/04/2026-Undergraduate-Prospectus.pdf', N'User Oracle export report (6).csv; offering 88; earlier prospectus edition, 2028 unconfirmed'),
    (N'Sol Plaatje University', N'Bachelor of Commerce in Economics', N'Business and Economics', N'https://www.spu.ac.za/wp-content/uploads/2025/04/2026-Undergraduate-Prospectus.pdf', N'User Oracle export report (6).csv; offering 89; earlier prospectus edition, 2028 unconfirmed'),
    (N'Sol Plaatje University', N'Bachelor of Science in Data Science', N'Information Technology and Computing', N'https://www.spu.ac.za/wp-content/uploads/2025/04/2026-Undergraduate-Prospectus.pdf', N'User Oracle export report (6).csv; offering 90; earlier prospectus edition, 2028 unconfirmed'),
    (N'Sol Plaatje University', N'Diploma in Agriculture', N'Agriculture and Environmental Studies', N'https://www.spu.ac.za/wp-content/uploads/2025/04/2026-Undergraduate-Prospectus.pdf', N'User Oracle export report (6).csv; offering 86; earlier prospectus edition, 2028 unconfirmed'),
    (N'Sol Plaatje University', N'Diploma in Information and Communication Technology in Applications Development', N'Information Technology and Computing', N'https://www.spu.ac.za/wp-content/uploads/2025/04/2026-Undergraduate-Prospectus.pdf', N'User Oracle export report (6).csv; offering 84; earlier prospectus edition, 2028 unconfirmed'),
    (N'Sol Plaatje University', N'Diploma in Retail Business Management', N'Business and Economics', N'https://www.spu.ac.za/wp-content/uploads/2025/04/2026-Undergraduate-Prospectus.pdf', N'User Oracle export report (6).csv; offering 85; earlier prospectus edition, 2028 unconfirmed'),
    (N'Sol Plaatje University', N'Higher Certificate in Court Interpreting', N'Law and Justice', N'https://www.spu.ac.za/wp-content/uploads/2025/04/2026-Undergraduate-Prospectus.pdf', N'User Oracle export report (6).csv; offering 81; earlier prospectus edition, 2028 unconfirmed'),
    (N'Sol Plaatje University', N'Higher Certificate in Entrepreneurship', N'Business and Economics', N'https://www.spu.ac.za/wp-content/uploads/2025/04/2026-Undergraduate-Prospectus.pdf', N'User Oracle export report (6).csv; offering 83; earlier prospectus edition, 2028 unconfirmed'),
    (N'Sol Plaatje University', N'Higher Certificate in Heritage Studies', N'Humanities and Social Sciences', N'https://www.spu.ac.za/wp-content/uploads/2025/04/2026-Undergraduate-Prospectus.pdf', N'User Oracle export report (6).csv; offering 82; earlier prospectus edition, 2028 unconfirmed'),
    (N'Stellenbosch University', N'Bachelor of Agriculture in Agribusiness Management', N'Agriculture and Environmental Studies', N'https://files.su.ac.za/public/undergraduate-maties/documents/2026-01/su-admissions-booklet-2027.pdf', N'User Oracle export report (6).csv; offering 91; earlier prospectus edition, 2028 unconfirmed'),
    (N'Stellenbosch University', N'Bachelor of Data Science', N'Information Technology and Computing', N'https://files.su.ac.za/public/undergraduate-maties/documents/2026-01/su-admissions-booklet-2027.pdf', N'User Oracle export report (6).csv; offering 98; earlier prospectus edition, 2028 unconfirmed'),
    (N'Stellenbosch University', N'Bachelor of Music', N'Arts and Design', N'https://files.su.ac.za/public/undergraduate-maties/documents/2026-01/su-admissions-booklet-2027.pdf', N'User Oracle export report (6).csv; offering 100; earlier prospectus edition, 2028 unconfirmed'),
    (N'Stellenbosch University', N'Bachelor of Science in Agriculture in Agricultural Economics', N'Agriculture and Environmental Studies', N'https://files.su.ac.za/public/undergraduate-maties/documents/2026-01/su-admissions-booklet-2027.pdf', N'User Oracle export report (6).csv; offering 92; earlier prospectus edition, 2028 unconfirmed'),
    (N'Stellenbosch University', N'Bachelor of Science in Agriculture in Animal Production Systems', N'Agriculture and Environmental Studies', N'https://files.su.ac.za/public/undergraduate-maties/documents/2026-01/su-admissions-booklet-2027.pdf', N'User Oracle export report (6).csv; offering 96; earlier prospectus edition, 2028 unconfirmed'),
    (N'Stellenbosch University', N'Bachelor of Science in Agriculture in Plant and Soil Science', N'Agriculture and Environmental Studies', N'https://files.su.ac.za/public/undergraduate-maties/documents/2026-01/su-admissions-booklet-2027.pdf', N'User Oracle export report (6).csv; offering 94; earlier prospectus edition, 2028 unconfirmed'),
    (N'Stellenbosch University', N'Bachelor of Science in Agriculture in Viticulture and Oenology', N'Agriculture and Environmental Studies', N'https://files.su.ac.za/public/undergraduate-maties/documents/2026-01/su-admissions-booklet-2027.pdf', N'User Oracle export report (6).csv; offering 95; earlier prospectus edition, 2028 unconfirmed'),
    (N'Stellenbosch University', N'Bachelor of Science in Conservation Ecology', N'Agriculture and Environmental Studies', N'https://files.su.ac.za/public/undergraduate-maties/documents/2026-01/su-admissions-booklet-2027.pdf', N'User Oracle export report (6).csv; offering 97; earlier prospectus edition, 2028 unconfirmed'),
    (N'Stellenbosch University', N'Bachelor of Science in Food Science', N'Natural and Mathematical Sciences', N'https://files.su.ac.za/public/undergraduate-maties/documents/2026-01/su-admissions-booklet-2027.pdf', N'User Oracle export report (6).csv; offering 99; earlier prospectus edition, 2028 unconfirmed'),
    (N'Stellenbosch University', N'Bachelor of Science in Forestry (Forestry and Wood Sciences)', N'Agriculture and Environmental Studies', N'https://files.su.ac.za/public/undergraduate-maties/documents/2026-01/su-admissions-booklet-2027.pdf', N'User Oracle export report (6).csv; offering 93; earlier prospectus edition, 2028 unconfirmed'),
    (N'Tshwane University of Technology', N'Diploma in Accounting', N'Accounting and Finance', N'https://www.tut.ac.za/media/tshwane-interim/site-content/documents/First-Year-Course_Information.pdf', N'User Oracle export report (6).csv; offering 101; earlier prospectus edition, 2028 unconfirmed'),
    (N'Tshwane University of Technology', N'Diploma in Commercial Photography', N'Arts and Design', N'https://www.tut.ac.za/media/tshwane-interim/site-content/documents/First-Year-Course_Information.pdf', N'User Oracle export report (6).csv; offering 108; earlier prospectus edition, 2028 unconfirmed'),
    (N'Tshwane University of Technology', N'Diploma in Economics', N'Business and Economics', N'https://www.tut.ac.za/media/tshwane-interim/site-content/documents/First-Year-Course_Information.pdf', N'User Oracle export report (6).csv; offering 102; earlier prospectus edition, 2028 unconfirmed'),
    (N'Tshwane University of Technology', N'Diploma in Fashion Design and Technology', N'Arts and Design', N'https://www.tut.ac.za/media/tshwane-interim/site-content/documents/First-Year-Course_Information.pdf', N'User Oracle export report (6).csv; offering 109; earlier prospectus edition, 2028 unconfirmed'),
    (N'Tshwane University of Technology', N'Diploma in Financial Management', N'Accounting and Finance', N'https://www.tut.ac.za/media/tshwane-interim/site-content/documents/First-Year-Course_Information.pdf', N'User Oracle export report (6).csv; offering 103; earlier prospectus edition, 2028 unconfirmed'),
    (N'Tshwane University of Technology', N'Diploma in Financial Planning', N'Accounting and Finance', N'https://www.tut.ac.za/media/tshwane-interim/site-content/documents/First-Year-Course_Information.pdf', N'User Oracle export report (6).csv; offering 104; earlier prospectus edition, 2028 unconfirmed'),
    (N'Tshwane University of Technology', N'Diploma in Fine and Applied Arts', N'Arts and Design', N'https://www.tut.ac.za/media/tshwane-interim/site-content/documents/First-Year-Course_Information.pdf', N'User Oracle export report (6).csv; offering 110; earlier prospectus edition, 2028 unconfirmed'),
    (N'Tshwane University of Technology', N'Diploma in Internal Auditing', N'Accounting and Finance', N'https://www.tut.ac.za/media/tshwane-interim/site-content/documents/First-Year-Course_Information.pdf', N'User Oracle export report (6).csv; offering 105; earlier prospectus edition, 2028 unconfirmed'),
    (N'Tshwane University of Technology', N'Diploma in Public Finance', N'Accounting and Finance', N'https://www.tut.ac.za/media/tshwane-interim/site-content/documents/First-Year-Course_Information.pdf', N'User Oracle export report (6).csv; offering 106; earlier prospectus edition, 2028 unconfirmed'),
    (N'Tshwane University of Technology', N'Higher Certificate in Accounting', N'Accounting and Finance', N'https://www.tut.ac.za/media/tshwane-interim/site-content/documents/First-Year-Course_Information.pdf', N'User Oracle export report (6).csv; offering 107; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Cape Town', N'Bachelor of Arts', N'Humanities and Social Sciences', N'https://uct.ac.za/students/study-uct-degrees-diplomas-humanities/humanities-undergraduate', N'User Oracle export report (6).csv; offering 111; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Cape Town', N'Bachelor of Music in Composition', N'Arts and Design', N'https://uct.ac.za/students/study-uct-degrees-diplomas-humanities/humanities-undergraduate', N'User Oracle export report (6).csv; offering 115; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Cape Town', N'Bachelor of Music in Education', N'Education', N'https://uct.ac.za/students/study-uct-degrees-diplomas-humanities/humanities-undergraduate', N'User Oracle export report (6).csv; offering 116; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Cape Town', N'Bachelor of Music in Musicology', N'Arts and Design', N'https://uct.ac.za/students/study-uct-degrees-diplomas-humanities/humanities-undergraduate', N'User Oracle export report (6).csv; offering 117; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Cape Town', N'Bachelor of Science in Engineering in Chemical Engineering', N'Engineering and Technology', N'https://uct.ac.za/students/study-uct-degrees-diplomas-humanities/humanities-undergraduate', N'User Oracle export report (6).csv; offering 118; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Cape Town', N'Bachelor of Science in Engineering in Civil Engineering', N'Engineering and Technology', N'https://uct.ac.za/students/study-uct-degrees-diplomas-humanities/humanities-undergraduate', N'User Oracle export report (6).csv; offering 119; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Cape Town', N'Bachelor of Science in Engineering in Mechanical and Mechatronics Engineering', N'Engineering and Technology', N'https://uct.ac.za/students/study-uct-degrees-diplomas-humanities/humanities-undergraduate', N'User Oracle export report (6).csv; offering 120; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Cape Town', N'Bachelor of Social Science', N'Humanities and Social Sciences', N'https://uct.ac.za/students/study-uct-degrees-diplomas-humanities/humanities-undergraduate', N'User Oracle export report (6).csv; offering 112; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Cape Town', N'Bachelor of Social Science in Philosophy, Politics and Economics', N'Business and Economics', N'https://uct.ac.za/students/study-uct-degrees-diplomas-humanities/humanities-undergraduate', N'User Oracle export report (6).csv; offering 113; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Cape Town', N'Bachelor of Social Work', N'Humanities and Social Sciences', N'https://uct.ac.za/students/study-uct-degrees-diplomas-humanities/humanities-undergraduate', N'User Oracle export report (6).csv; offering 114; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Fort Hare', N'Bachelor of Arts', N'Humanities and Social Sciences', N'https://www.ufh.ac.za/study-guide-2027', N'User Oracle export report (6).csv; offering 127; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Fort Hare', N'Bachelor of Commerce', N'Business and Economics', N'https://www.ufh.ac.za/study-guide-2027', N'User Oracle export report (6).csv; offering 121; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Fort Hare', N'Bachelor of Commerce (Economics)', N'Business and Economics', N'https://www.ufh.ac.za/study-guide-2027', N'User Oracle export report (6).csv; offering 122; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Fort Hare', N'Bachelor of Commerce (Industrial Psychology)', N'Business and Economics', N'https://www.ufh.ac.za/study-guide-2027', N'User Oracle export report (6).csv; offering 123; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Fort Hare', N'Bachelor of Commerce in Accounting', N'Accounting and Finance', N'https://www.ufh.ac.za/study-guide-2027', N'User Oracle export report (6).csv; offering 125; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Fort Hare', N'Bachelor of Commerce in Information Systems', N'Information Technology and Computing', N'https://www.ufh.ac.za/study-guide-2027', N'User Oracle export report (6).csv; offering 124; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Fort Hare', N'Bachelor of Fine Art', N'Arts and Design', N'https://www.ufh.ac.za/study-guide-2027', N'User Oracle export report (6).csv; offering 128; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Fort Hare', N'Bachelor of Laws', N'Law and Justice', N'https://www.ufh.ac.za/study-guide-2027', N'User Oracle export report (6).csv; offering 126; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Fort Hare', N'Bachelor of Library and Information Science', N'Library and Information Science', N'https://www.ufh.ac.za/study-guide-2027', N'User Oracle export report (6).csv; offering 129; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Fort Hare', N'Bachelor of Social Work', N'Humanities and Social Sciences', N'https://www.ufh.ac.za/study-guide-2027', N'User Oracle export report (6).csv; offering 130; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Johannesburg', N'Diploma in Accountancy', N'Accounting and Finance', N'https://www.uj.ac.za/wp-content/uploads/2026/06/uj_undergrad_prospectus2027.pdf', N'User Oracle export report (6).csv; offering 141; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Johannesburg', N'Diploma in Business Information Technology', N'Information Technology and Computing', N'https://www.uj.ac.za/wp-content/uploads/2026/06/uj_undergrad_prospectus2027.pdf', N'User Oracle export report (6).csv; offering 142; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Johannesburg', N'Diploma in Financial Service Operations', N'Accounting and Finance', N'https://www.uj.ac.za/wp-content/uploads/2026/06/uj_undergrad_prospectus2027.pdf', N'User Oracle export report (6).csv; offering 143; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Johannesburg', N'Diploma in Food and Beverage Operations', N'Hospitality and Tourism', N'https://www.uj.ac.za/wp-content/uploads/2026/06/uj_undergrad_prospectus2027.pdf', N'User Oracle export report (6).csv; offering 144; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Johannesburg', N'Diploma in Logistics', N'Business and Economics', N'https://www.uj.ac.za/wp-content/uploads/2026/06/uj_undergrad_prospectus2027.pdf', N'User Oracle export report (6).csv; offering 145; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Johannesburg', N'Diploma in Marketing', N'Business and Economics', N'https://www.uj.ac.za/wp-content/uploads/2026/06/uj_undergrad_prospectus2027.pdf', N'User Oracle export report (6).csv; offering 146; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Johannesburg', N'Diploma in People Management', N'Business and Economics', N'https://www.uj.ac.za/wp-content/uploads/2026/06/uj_undergrad_prospectus2027.pdf', N'User Oracle export report (6).csv; offering 147; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Johannesburg', N'Diploma in Retail Business Management', N'Business and Economics', N'https://www.uj.ac.za/wp-content/uploads/2026/06/uj_undergrad_prospectus2027.pdf', N'User Oracle export report (6).csv; offering 148; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Johannesburg', N'Diploma in Small Business Management', N'Business and Economics', N'https://www.uj.ac.za/wp-content/uploads/2026/06/uj_undergrad_prospectus2027.pdf', N'User Oracle export report (6).csv; offering 149; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Johannesburg', N'Diploma in Tourism Management', N'Hospitality and Tourism', N'https://www.uj.ac.za/wp-content/uploads/2026/06/uj_undergrad_prospectus2027.pdf', N'User Oracle export report (6).csv; offering 150; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of KwaZulu-Natal', N'Bachelor of Business Science', N'Business and Economics', N'https://applications.ukzn.ac.za/wp-content/uploads/2026/05/2027-Undergrad.pdf', N'User Oracle export report (6).csv; offering 159; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of KwaZulu-Natal', N'Bachelor of Commerce (General)', N'Business and Economics', N'https://applications.ukzn.ac.za/wp-content/uploads/2026/05/2027-Undergrad.pdf', N'User Oracle export report (6).csv; offering 158; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of KwaZulu-Natal', N'Bachelor of Commerce in Accounting', N'Accounting and Finance', N'https://applications.ukzn.ac.za/wp-content/uploads/2026/05/2027-Undergrad.pdf', N'User Oracle export report (6).csv; offering 157; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of KwaZulu-Natal', N'Bachelor of Laws', N'Law and Justice', N'https://applications.ukzn.ac.za/wp-content/uploads/2026/05/2027-Undergrad.pdf', N'User Oracle export report (6).csv; offering 160; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of KwaZulu-Natal', N'Bachelor of Science in Engineering in Agricultural Engineering', N'Engineering and Technology', N'https://applications.ukzn.ac.za/wp-content/uploads/2026/05/2027-Undergrad.pdf', N'User Oracle export report (6).csv; offering 151; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of KwaZulu-Natal', N'Bachelor of Science in Engineering in Chemical Engineering', N'Engineering and Technology', N'https://applications.ukzn.ac.za/wp-content/uploads/2026/05/2027-Undergrad.pdf', N'User Oracle export report (6).csv; offering 152; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of KwaZulu-Natal', N'Bachelor of Science in Engineering in Computer Engineering', N'Information Technology and Computing', N'https://applications.ukzn.ac.za/wp-content/uploads/2026/05/2027-Undergrad.pdf', N'User Oracle export report (6).csv; offering 153; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of KwaZulu-Natal', N'Bachelor of Science in Engineering in Electrical Engineering', N'Engineering and Technology', N'https://applications.ukzn.ac.za/wp-content/uploads/2026/05/2027-Undergrad.pdf', N'User Oracle export report (6).csv; offering 154; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of KwaZulu-Natal', N'Bachelor of Science in Engineering in Electronic Engineering', N'Engineering and Technology', N'https://applications.ukzn.ac.za/wp-content/uploads/2026/05/2027-Undergrad.pdf', N'User Oracle export report (6).csv; offering 155; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of KwaZulu-Natal', N'Bachelor of Science in Engineering in Mechanical Engineering', N'Engineering and Technology', N'https://applications.ukzn.ac.za/wp-content/uploads/2026/05/2027-Undergrad.pdf', N'User Oracle export report (6).csv; offering 156; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Limpopo', N'Bachelor of Arts (Communication Studies)', N'Humanities and Social Sciences', N'https://www.ul.ac.za/wp-content/uploads/2025/03/Undergraduate-Prospectus-2027.pdf', N'User Oracle export report (6).csv; offering 170; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Limpopo', N'Bachelor of Arts (Criminology and Psychology)', N'Humanities and Social Sciences', N'https://www.ul.ac.za/wp-content/uploads/2025/03/Undergraduate-Prospectus-2027.pdf', N'User Oracle export report (6).csv; offering 162; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Limpopo', N'Bachelor of Arts (Cultural Studies)', N'Humanities and Social Sciences', N'https://www.ul.ac.za/wp-content/uploads/2025/03/Undergraduate-Prospectus-2027.pdf', N'User Oracle export report (6).csv; offering 166; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Limpopo', N'Bachelor of Arts (Languages)', N'Humanities and Social Sciences', N'https://www.ul.ac.za/wp-content/uploads/2025/03/Undergraduate-Prospectus-2027.pdf', N'User Oracle export report (6).csv; offering 161; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Limpopo', N'Bachelor of Arts (Performing Arts)', N'Arts and Design', N'https://www.ul.ac.za/wp-content/uploads/2025/03/Undergraduate-Prospectus-2027.pdf', N'User Oracle export report (6).csv; offering 169; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Limpopo', N'Bachelor of Arts (Political Studies)', N'Humanities and Social Sciences', N'https://www.ul.ac.za/wp-content/uploads/2025/03/Undergraduate-Prospectus-2027.pdf', N'User Oracle export report (6).csv; offering 164; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Limpopo', N'Bachelor of Arts (Sociology and Anthropology)', N'Humanities and Social Sciences', N'https://www.ul.ac.za/wp-content/uploads/2025/03/Undergraduate-Prospectus-2027.pdf', N'User Oracle export report (6).csv; offering 165; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Limpopo', N'Bachelor of Arts (Translation and Linguistics)', N'Humanities and Social Sciences', N'https://www.ul.ac.za/wp-content/uploads/2025/03/Undergraduate-Prospectus-2027.pdf', N'User Oracle export report (6).csv; offering 167; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Limpopo', N'Bachelor of Information Studies', N'Library and Information Science', N'https://www.ul.ac.za/wp-content/uploads/2025/03/Undergraduate-Prospectus-2027.pdf', N'User Oracle export report (6).csv; offering 168; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Limpopo', N'Bachelor of Psychology', N'Humanities and Social Sciences', N'https://www.ul.ac.za/wp-content/uploads/2025/03/Undergraduate-Prospectus-2027.pdf', N'User Oracle export report (6).csv; offering 163; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Pretoria', N'Bachelor of Engineering in Chemical Engineering', N'Engineering and Technology', N'https://www.up.ac.za/yearbooks/2026/EBIT-faculty/UD-programmes', N'User Oracle export report (6).csv; offering 181; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Pretoria', N'Bachelor of Engineering in Civil Engineering', N'Engineering and Technology', N'https://www.up.ac.za/yearbooks/2026/EBIT-faculty/UD-programmes', N'User Oracle export report (6).csv; offering 182; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Pretoria', N'Bachelor of Engineering in Computer Engineering', N'Information Technology and Computing', N'https://www.up.ac.za/yearbooks/2026/EBIT-faculty/UD-programmes', N'User Oracle export report (6).csv; offering 183; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Pretoria', N'Bachelor of Engineering in Electrical Engineering', N'Engineering and Technology', N'https://www.up.ac.za/yearbooks/2026/EBIT-faculty/UD-programmes', N'User Oracle export report (6).csv; offering 184; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Pretoria', N'Bachelor of Engineering in Electronic Engineering', N'Engineering and Technology', N'https://www.up.ac.za/yearbooks/2026/EBIT-faculty/UD-programmes', N'User Oracle export report (6).csv; offering 185; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Pretoria', N'Bachelor of Engineering in Industrial Engineering', N'Engineering and Technology', N'https://www.up.ac.za/yearbooks/2026/EBIT-faculty/UD-programmes', N'User Oracle export report (6).csv; offering 186; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Pretoria', N'Bachelor of Engineering in Mechanical Engineering', N'Engineering and Technology', N'https://www.up.ac.za/yearbooks/2026/EBIT-faculty/UD-programmes', N'User Oracle export report (6).csv; offering 187; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Pretoria', N'Bachelor of Engineering in Mining Engineering', N'Engineering and Technology', N'https://www.up.ac.za/yearbooks/2026/EBIT-faculty/UD-programmes', N'User Oracle export report (6).csv; offering 188; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Pretoria', N'Bachelor of Information Science', N'Library and Information Science', N'https://www.up.ac.za/yearbooks/2026/EBIT-faculty/UD-programmes', N'User Oracle export report (6).csv; offering 190; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Pretoria', N'Bachelor of Science in Computer Science', N'Information Technology and Computing', N'https://www.up.ac.za/yearbooks/2026/EBIT-faculty/UD-programmes', N'User Oracle export report (6).csv; offering 189; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of South Africa', N'Diploma in Accounting Sciences', N'Accounting and Finance', N'https://www.unisa.ac.za/sites/corporate/default/Register-to-study-through-Unisa/Undergraduate-%26-honours-qualifications/Find-your-qualification-%26-choose-your-modules/All-qualifications', N'User Oracle export report (6).csv; offering 191; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of South Africa', N'Diploma in Administrative Management', N'Public Administration and Management', N'https://www.unisa.ac.za/sites/corporate/default/Register-to-study-through-Unisa/Undergraduate-%26-honours-qualifications/Find-your-qualification-%26-choose-your-modules/All-qualifications', N'User Oracle export report (6).csv; offering 192; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of South Africa', N'Diploma in Agricultural Management', N'Agriculture and Environmental Studies', N'https://www.unisa.ac.za/sites/corporate/default/Register-to-study-through-Unisa/Undergraduate-%26-honours-qualifications/Find-your-qualification-%26-choose-your-modules/All-qualifications', N'User Oracle export report (6).csv; offering 193; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of South Africa', N'Diploma in Animal Health', N'Health Sciences', N'https://www.unisa.ac.za/sites/corporate/default/Register-to-study-through-Unisa/Undergraduate-%26-honours-qualifications/Find-your-qualification-%26-choose-your-modules/All-qualifications', N'User Oracle export report (6).csv; offering 194; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of South Africa', N'Diploma in Chemical Engineering', N'Engineering and Technology', N'https://www.unisa.ac.za/sites/corporate/default/Register-to-study-through-Unisa/Undergraduate-%26-honours-qualifications/Find-your-qualification-%26-choose-your-modules/All-qualifications', N'User Oracle export report (6).csv; offering 195; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of South Africa', N'Diploma in Civil Engineering', N'Engineering and Technology', N'https://www.unisa.ac.za/sites/corporate/default/Register-to-study-through-Unisa/Undergraduate-%26-honours-qualifications/Find-your-qualification-%26-choose-your-modules/All-qualifications', N'User Oracle export report (6).csv; offering 196; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of South Africa', N'Diploma in Corrections Management', N'Law and Justice', N'https://www.unisa.ac.za/sites/corporate/default/Register-to-study-through-Unisa/Undergraduate-%26-honours-qualifications/Find-your-qualification-%26-choose-your-modules/All-qualifications', N'User Oracle export report (6).csv; offering 197; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of South Africa', N'Diploma in Early Childhood Care and Education', N'Education', N'https://www.unisa.ac.za/sites/corporate/default/Register-to-study-through-Unisa/Undergraduate-%26-honours-qualifications/Find-your-qualification-%26-choose-your-modules/All-qualifications', N'User Oracle export report (6).csv; offering 198; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of South Africa', N'Diploma in Electrical Engineering', N'Engineering and Technology', N'https://www.unisa.ac.za/sites/corporate/default/Register-to-study-through-Unisa/Undergraduate-%26-honours-qualifications/Find-your-qualification-%26-choose-your-modules/All-qualifications', N'User Oracle export report (6).csv; offering 199; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of South Africa', N'Diploma in Human Resource Management', N'Business and Economics', N'https://www.unisa.ac.za/sites/corporate/default/Register-to-study-through-Unisa/Undergraduate-%26-honours-qualifications/Find-your-qualification-%26-choose-your-modules/All-qualifications', N'User Oracle export report (6).csv; offering 200; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Venda', N'Bachelor of Arts', N'Humanities and Social Sciences', N'https://www.univen.ac.za/wp-content/uploads/2026/03/2027-Univen-Undergraduate-Prospectus.pdf', N'User Oracle export report (6).csv; offering 202; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Venda', N'Bachelor of Arts in Development Studies', N'Humanities and Social Sciences', N'https://www.univen.ac.za/wp-content/uploads/2026/03/2027-Univen-Undergraduate-Prospectus.pdf', N'User Oracle export report (6).csv; offering 203; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Venda', N'Bachelor of Arts in English Language and Literature', N'Humanities and Social Sciences', N'https://www.univen.ac.za/wp-content/uploads/2026/03/2027-Univen-Undergraduate-Prospectus.pdf', N'User Oracle export report (6).csv; offering 206; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Venda', N'Bachelor of Arts in History', N'Humanities and Social Sciences', N'https://www.univen.ac.za/wp-content/uploads/2026/03/2027-Univen-Undergraduate-Prospectus.pdf', N'User Oracle export report (6).csv; offering 209; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Venda', N'Bachelor of Arts in International Relations', N'Humanities and Social Sciences', N'https://www.univen.ac.za/wp-content/uploads/2026/03/2027-Univen-Undergraduate-Prospectus.pdf', N'User Oracle export report (6).csv; offering 207; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Venda', N'Bachelor of Arts in Language Practice', N'Humanities and Social Sciences', N'https://www.univen.ac.za/wp-content/uploads/2026/03/2027-Univen-Undergraduate-Prospectus.pdf', N'User Oracle export report (6).csv; offering 205; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Venda', N'Bachelor of Arts in Media Studies', N'Humanities and Social Sciences', N'https://www.univen.ac.za/wp-content/uploads/2026/03/2027-Univen-Undergraduate-Prospectus.pdf', N'User Oracle export report (6).csv; offering 201; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Venda', N'Bachelor of Arts in Youth Development', N'Humanities and Social Sciences', N'https://www.univen.ac.za/wp-content/uploads/2026/03/2027-Univen-Undergraduate-Prospectus.pdf', N'User Oracle export report (6).csv; offering 208; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Venda', N'Bachelor of Indigenous Knowledge Systems', N'Humanities and Social Sciences', N'https://www.univen.ac.za/wp-content/uploads/2026/03/2027-Univen-Undergraduate-Prospectus.pdf', N'User Oracle export report (6).csv; offering 204; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Venda', N'Bachelor of Theology', N'Humanities and Social Sciences', N'https://www.univen.ac.za/wp-content/uploads/2026/03/2027-Univen-Undergraduate-Prospectus.pdf', N'User Oracle export report (6).csv; offering 210; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Zululand', N'Bachelor of Commerce', N'Business and Economics', N'https://www.fcal.unizulu.ac.za/study-with-us/', N'User Oracle export report (6).csv; offering 237; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Zululand', N'Bachelor of Commerce in Accounting', N'Accounting and Finance', N'https://www.fcal.unizulu.ac.za/study-with-us/', N'User Oracle export report (6).csv; offering 232; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Zululand', N'Bachelor of Commerce in Accounting Science', N'Accounting and Finance', N'https://www.fcal.unizulu.ac.za/study-with-us/', N'User Oracle export report (6).csv; offering 233; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Zululand', N'Diploma in Co-operative Management', N'Business and Economics', N'https://www.fcal.unizulu.ac.za/study-with-us/', N'User Oracle export report (6).csv; offering 234; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Zululand', N'Diploma in Hospitality Management', N'Hospitality and Tourism', N'https://www.fcal.unizulu.ac.za/study-with-us/', N'User Oracle export report (6).csv; offering 238; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Zululand', N'Diploma in Logistics Management', N'Business and Economics', N'https://www.fcal.unizulu.ac.za/study-with-us/', N'User Oracle export report (6).csv; offering 235; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Zululand', N'Diploma in Media Studies', N'Humanities and Social Sciences', N'https://www.fcal.unizulu.ac.za/study-with-us/', N'User Oracle export report (6).csv; offering 239; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Zululand', N'Diploma in Tourism Management', N'Hospitality and Tourism', N'https://www.fcal.unizulu.ac.za/study-with-us/', N'User Oracle export report (6).csv; offering 240; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Zululand', N'Diploma in Transport Management', N'Health Sciences', N'https://www.fcal.unizulu.ac.za/study-with-us/', N'User Oracle export report (6).csv; offering 236; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Zululand', N'Higher Certificate in Accountancy', N'Accounting and Finance', N'https://www.fcal.unizulu.ac.za/study-with-us/', N'User Oracle export report (6).csv; offering 231; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Free State', N'Bachelor of Administration', N'Public Administration and Management', N'https://www.ufs.ac.za/econ/faculty-of-economic-and-management-sciences-home/undergraduate', N'User Oracle export report (6).csv; offering 131; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Free State', N'Bachelor of Commerce', N'Business and Economics', N'https://www.ufs.ac.za/econ/faculty-of-economic-and-management-sciences-home/undergraduate', N'User Oracle export report (6).csv; offering 132; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Free State', N'Bachelor of Commerce in Accounting', N'Accounting and Finance', N'https://www.ufs.ac.za/econ/faculty-of-economic-and-management-sciences-home/undergraduate', N'User Oracle export report (6).csv; offering 140; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Free State', N'Bachelor of Commerce in Business Analytics', N'Information Technology and Computing', N'https://www.ufs.ac.za/econ/faculty-of-economic-and-management-sciences-home/undergraduate', N'User Oracle export report (6).csv; offering 133; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Free State', N'Bachelor of Commerce in Business Management', N'Business and Economics', N'https://www.ufs.ac.za/econ/faculty-of-economic-and-management-sciences-home/undergraduate', N'User Oracle export report (6).csv; offering 134; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Free State', N'Bachelor of Commerce in Economics', N'Business and Economics', N'https://www.ufs.ac.za/econ/faculty-of-economic-and-management-sciences-home/undergraduate', N'User Oracle export report (6).csv; offering 135; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Free State', N'Bachelor of Commerce in Finance', N'Accounting and Finance', N'https://www.ufs.ac.za/econ/faculty-of-economic-and-management-sciences-home/undergraduate', N'User Oracle export report (6).csv; offering 136; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Free State', N'Bachelor of Commerce in Human Resource Management', N'Business and Economics', N'https://www.ufs.ac.za/econ/faculty-of-economic-and-management-sciences-home/undergraduate', N'User Oracle export report (6).csv; offering 137; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Free State', N'Bachelor of Commerce in Law', N'Law and Justice', N'https://www.ufs.ac.za/econ/faculty-of-economic-and-management-sciences-home/undergraduate', N'User Oracle export report (6).csv; offering 139; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Free State', N'Bachelor of Commerce in Marketing', N'Business and Economics', N'https://www.ufs.ac.za/econ/faculty-of-economic-and-management-sciences-home/undergraduate', N'User Oracle export report (6).csv; offering 138; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Western Cape', N'Bachelor of Administration', N'Public Administration and Management', N'https://www.uwc.ac.za/study/faculties-and-programmes/faculty-of-arts-and-humanities/programmes', N'User Oracle export report (6).csv; offering 215; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Western Cape', N'Bachelor of Arts', N'Humanities and Social Sciences', N'https://www.uwc.ac.za/study/faculties-and-programmes/faculty-of-arts-and-humanities/programmes', N'User Oracle export report (6).csv; offering 212; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Western Cape', N'Bachelor of Arts in Sport, Recreation and Exercise Science', N'Health Sciences', N'https://www.uwc.ac.za/study/faculties-and-programmes/faculty-of-arts-and-humanities/programmes', N'User Oracle export report (6).csv; offering 219; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Western Cape', N'Bachelor of Commerce', N'Business and Economics', N'https://www.uwc.ac.za/study/faculties-and-programmes/faculty-of-arts-and-humanities/programmes', N'User Oracle export report (6).csv; offering 214; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Western Cape', N'Bachelor of Commerce in Accounting', N'Accounting and Finance', N'https://www.uwc.ac.za/study/faculties-and-programmes/faculty-of-arts-and-humanities/programmes', N'User Oracle export report (6).csv; offering 216; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Western Cape', N'Bachelor of Commerce in Information Systems', N'Information Technology and Computing', N'https://www.uwc.ac.za/study/faculties-and-programmes/faculty-of-arts-and-humanities/programmes', N'User Oracle export report (6).csv; offering 217; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Western Cape', N'Bachelor of Library and Information Studies', N'Library and Information Science', N'https://www.uwc.ac.za/study/faculties-and-programmes/faculty-of-arts-and-humanities/programmes', N'User Oracle export report (6).csv; offering 213; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Western Cape', N'Bachelor of Science in Complementary Health Sciences', N'Health Sciences', N'https://www.uwc.ac.za/study/faculties-and-programmes/faculty-of-arts-and-humanities/programmes', N'User Oracle export report (6).csv; offering 220; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Western Cape', N'Bachelor of Science in Sport and Exercise Science', N'Health Sciences', N'https://www.uwc.ac.za/study/faculties-and-programmes/faculty-of-arts-and-humanities/programmes', N'User Oracle export report (6).csv; offering 218; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Western Cape', N'Bachelor of Theology', N'Humanities and Social Sciences', N'https://www.uwc.ac.za/study/faculties-and-programmes/faculty-of-arts-and-humanities/programmes', N'User Oracle export report (6).csv; offering 211; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Witwatersrand', N'Bachelor of Architectural Studies', N'Built Environment', N'https://www.wits.ac.za/ebe/undergraduate-programmes/', N'User Oracle export report (6).csv; offering 222; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Witwatersrand', N'Bachelor of Arts', N'Humanities and Social Sciences', N'https://www.wits.ac.za/ebe/undergraduate-programmes/', N'User Oracle export report (6).csv; offering 227; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Witwatersrand', N'Bachelor of Arts in Digital Arts', N'Arts and Design', N'https://www.wits.ac.za/ebe/undergraduate-programmes/', N'User Oracle export report (6).csv; offering 228; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Witwatersrand', N'Bachelor of Audiology', N'Health Sciences', N'https://www.wits.ac.za/course-finder/undergraduate/humanities/audiology/', N'User Oracle export report (6).csv; offering 226; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Witwatersrand', N'Bachelor of Engineering Science in Biomedical Engineering', N'Engineering and Technology', N'https://www.wits.ac.za/ebe/undergraduate-programmes/', N'User Oracle export report (6).csv; offering 223; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Witwatersrand', N'Bachelor of Science in Construction Studies', N'Built Environment', N'https://www.wits.ac.za/ebe/undergraduate-programmes/', N'User Oracle export report (6).csv; offering 229; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Witwatersrand', N'Bachelor of Science in Engineering in Aeronautical Engineering', N'Engineering and Technology', N'https://www.wits.ac.za/ebe/undergraduate-programmes/', N'User Oracle export report (6).csv; offering 221; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Witwatersrand', N'Bachelor of Science in Engineering in Chemical Engineering', N'Engineering and Technology', N'https://www.wits.ac.za/ebe/undergraduate-programmes/', N'User Oracle export report (6).csv; offering 224; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Witwatersrand', N'Bachelor of Science in Engineering in Civil Engineering', N'Engineering and Technology', N'https://www.wits.ac.za/ebe/undergraduate-programmes/', N'User Oracle export report (6).csv; offering 225; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of the Witwatersrand', N'Bachelor of Science in Property Studies', N'Built Environment', N'https://www.wits.ac.za/ebe/undergraduate-programmes/', N'User Oracle export report (6).csv; offering 230; earlier prospectus edition, 2028 unconfirmed'),
    (N'Vaal University of Technology', N'Bachelor of Health Sciences in Medical Laboratory Science', N'Health Sciences', N'https://vut.ac.za/wp-content/uploads/2026/03/2027-Undergraduate-Minimum-Admission-Requirements.pdf', N'User Oracle export report (6).csv; offering 249; earlier prospectus edition, 2028 unconfirmed'),
    (N'Vaal University of Technology', N'Diploma in Agricultural Management', N'Agriculture and Environmental Studies', N'https://vut.ac.za/wp-content/uploads/2026/03/2027-Undergraduate-Minimum-Admission-Requirements.pdf', N'User Oracle export report (6).csv; offering 242; earlier prospectus edition, 2028 unconfirmed'),
    (N'Vaal University of Technology', N'Diploma in Analytical Chemistry', N'Natural and Mathematical Sciences', N'https://vut.ac.za/wp-content/uploads/2026/03/2027-Undergraduate-Minimum-Admission-Requirements.pdf', N'User Oracle export report (6).csv; offering 241; earlier prospectus edition, 2028 unconfirmed'),
    (N'Vaal University of Technology', N'Diploma in Biotechnology', N'Natural and Mathematical Sciences', N'https://vut.ac.za/wp-content/uploads/2026/03/2027-Undergraduate-Minimum-Admission-Requirements.pdf', N'User Oracle export report (6).csv; offering 243; earlier prospectus edition, 2028 unconfirmed'),
    (N'Vaal University of Technology', N'Diploma in Cost and Management Accounting', N'Accounting and Finance', N'https://vut.ac.za/wp-content/uploads/2026/03/2027-Undergraduate-Minimum-Admission-Requirements.pdf', N'User Oracle export report (6).csv; offering 247; earlier prospectus edition, 2028 unconfirmed'),
    (N'Vaal University of Technology', N'Diploma in Fashion', N'Arts and Design', N'https://vut.ac.za/wp-content/uploads/2026/03/2027-Undergraduate-Minimum-Admission-Requirements.pdf', N'User Oracle export report (6).csv; offering 250; earlier prospectus edition, 2028 unconfirmed'),
    (N'Vaal University of Technology', N'Diploma in Financial Information Systems', N'Information Technology and Computing', N'https://vut.ac.za/wp-content/uploads/2026/03/2027-Undergraduate-Minimum-Admission-Requirements.pdf', N'User Oracle export report (6).csv; offering 246; earlier prospectus edition, 2028 unconfirmed'),
    (N'Vaal University of Technology', N'Diploma in Information Technology', N'Information Technology and Computing', N'https://vut.ac.za/wp-content/uploads/2026/03/2027-Undergraduate-Minimum-Admission-Requirements.pdf', N'User Oracle export report (6).csv; offering 245; earlier prospectus edition, 2028 unconfirmed'),
    (N'Vaal University of Technology', N'Diploma in Internal Auditing', N'Accounting and Finance', N'https://vut.ac.za/wp-content/uploads/2026/03/2027-Undergraduate-Minimum-Admission-Requirements.pdf', N'User Oracle export report (6).csv; offering 248; earlier prospectus edition, 2028 unconfirmed'),
    (N'Vaal University of Technology', N'Diploma in Non-Destructive Testing', N'Engineering and Technology', N'https://vut.ac.za/wp-content/uploads/2026/03/2027-Undergraduate-Minimum-Admission-Requirements.pdf', N'User Oracle export report (6).csv; offering 244; earlier prospectus edition, 2028 unconfirmed'),
    (N'Walter Sisulu University', N'Bachelor of Accounting', N'Accounting and Finance', N'https://www.wsu.ac.za/media/attachments/2026/05/27/2027-information-brochure-admission-requirements.pdf', N'User Oracle export report (6).csv; offering 254; earlier prospectus edition, 2028 unconfirmed'),
    (N'Walter Sisulu University', N'Bachelor of Accounting Science', N'Accounting and Finance', N'https://www.wsu.ac.za/media/attachments/2026/05/27/2027-information-brochure-admission-requirements.pdf', N'User Oracle export report (6).csv; offering 255; earlier prospectus edition, 2028 unconfirmed'),
    (N'Walter Sisulu University', N'Bachelor of Commerce', N'Business and Economics', N'https://www.wsu.ac.za/media/attachments/2026/05/27/2027-information-brochure-admission-requirements.pdf', N'User Oracle export report (6).csv; offering 256; earlier prospectus edition, 2028 unconfirmed'),
    (N'Walter Sisulu University', N'Bachelor of Commerce in Business Management', N'Business and Economics', N'https://www.wsu.ac.za/media/attachments/2026/05/27/2027-information-brochure-admission-requirements.pdf', N'User Oracle export report (6).csv; offering 257; earlier prospectus edition, 2028 unconfirmed'),
    (N'Walter Sisulu University', N'Bachelor of Commerce in Economics', N'Business and Economics', N'https://www.wsu.ac.za/media/attachments/2026/05/27/2027-information-brochure-admission-requirements.pdf', N'User Oracle export report (6).csv; offering 258; earlier prospectus edition, 2028 unconfirmed'),
    (N'Walter Sisulu University', N'Diploma in Accountancy', N'Accounting and Finance', N'https://www.wsu.ac.za/media/attachments/2026/05/27/2027-information-brochure-admission-requirements.pdf', N'User Oracle export report (6).csv; offering 251; earlier prospectus edition, 2028 unconfirmed'),
    (N'Walter Sisulu University', N'Diploma in Financial Information Systems', N'Information Technology and Computing', N'https://www.wsu.ac.za/media/attachments/2026/05/27/2027-information-brochure-admission-requirements.pdf', N'User Oracle export report (6).csv; offering 252; earlier prospectus edition, 2028 unconfirmed'),
    (N'Walter Sisulu University', N'Diploma in Internal Auditing', N'Accounting and Finance', N'https://www.wsu.ac.za/media/attachments/2026/05/27/2027-information-brochure-admission-requirements.pdf', N'User Oracle export report (6).csv; offering 253; earlier prospectus edition, 2028 unconfirmed'),
    (N'Walter Sisulu University', N'Diploma in Marketing Management', N'Business and Economics', N'https://www.wsu.ac.za/media/attachments/2026/05/27/2027-information-brochure-admission-requirements.pdf', N'User Oracle export report (6).csv; offering 260; earlier prospectus edition, 2028 unconfirmed'),
    (N'Walter Sisulu University', N'Diploma in Public Management', N'Public Administration and Management', N'https://www.wsu.ac.za/media/attachments/2026/05/27/2027-information-brochure-admission-requirements.pdf', N'User Oracle export report (6).csv; offering 259; earlier prospectus edition, 2028 unconfirmed'),
    (N'University of Mpumalanga', N'Higher Certificate in Information Communication Technology in User Support', N'Information Technology and Computing', N'https://www.ump.ac.za/Study-with-us/Faculties-and-Schools/Faculty-of-Agriculture-and-Natural-Sciences/School-of-Computing-and-Mathematical-Sciences.aspx', N'UMP official catalogue checked 2026-10-28'),
    (N'University of Mpumalanga', N'Diploma in Information and Communication Technology in Applications Development', N'Information Technology and Computing', N'https://www.ump.ac.za/Study-with-us/Faculties-and-Schools/Faculty-of-Agriculture-and-Natural-Sciences/School-of-Computing-and-Mathematical-Sciences.aspx', N'UMP official catalogue checked 2026-10-28'),
    (N'University of Mpumalanga', N'Bachelor of Information and Communication Technology', N'Information Technology and Computing', N'https://www.ump.ac.za/Study-with-us/Faculties-and-Schools/Faculty-of-Agriculture-and-Natural-Sciences/School-of-Computing-and-Mathematical-Sciences.aspx', N'UMP official catalogue checked 2026-10-28'),
    (N'University of Mpumalanga', N'Diploma in Agriculture in Plant Production', N'Agriculture and Environmental Studies', N'https://www.ump.ac.za/Study-with-us/Faculties-and-Schools/Faculty-of-Agriculture-and-Natural-Sciences/School-of-Agricultural-Sciences', N'UMP official catalogue checked 2026-10-28'),
    (N'University of Mpumalanga', N'Diploma in Animal Production', N'Agriculture and Environmental Studies', N'https://www.ump.ac.za/Study-with-us/Faculties-and-Schools/Faculty-of-Agriculture-and-Natural-Sciences/School-of-Agricultural-Sciences', N'UMP official catalogue checked 2026-10-28'),
    (N'University of Mpumalanga', N'Bachelor of Science in Agriculture', N'Agriculture and Environmental Studies', N'https://www.ump.ac.za/Study-with-us/Faculties-and-Schools/Faculty-of-Agriculture-and-Natural-Sciences/School-of-Agricultural-Sciences', N'UMP official catalogue checked 2026-10-28'),
    (N'University of Mpumalanga', N'Bachelor of Commerce (General)', N'Business and Economics', N'https://www.ump.ac.za/Study-with-us/Faculties-and-Schools/Faculty-of-Economics,-Development-And-Business-Sci.aspx', N'UMP official catalogue checked 2026-10-28'),
    (N'University of Mpumalanga', N'Bachelor of Administration', N'Public Administration and Management', N'https://www.ump.ac.za/Study-with-us/Faculties-and-Schools/Faculty-of-Economics,-Development-And-Business-Sci.aspx', N'UMP official catalogue checked 2026-10-28'),
    (N'University of Mpumalanga', N'Bachelor of Development Studies', N'Humanities and Social Sciences', N'https://www.ump.ac.za/Study-with-us/Faculties-and-Schools/Faculty-of-Economics,-Development-And-Business-Sci.aspx', N'UMP official catalogue checked 2026-10-28'),
    (N'University of Mpumalanga', N'Diploma in Hospitality Management', N'Hospitality and Tourism', N'https://www.ump.ac.za/Study-with-us/Faculties-and-Schools/Faculty-of-Economics,-Development-And-Business-Sci.aspx', N'UMP official catalogue checked 2026-10-28');

IF (SELECT COUNT(*) FROM @Catalogue)<>260 OR (SELECT COUNT(*) FROM @University)<>26
 OR EXISTS (SELECT University FROM @Catalogue GROUP BY University HAVING COUNT(*)<>10)
 THROW 51108, 'Catalogue validation failed: expected 26 universities and 260 selected offerings.', 1;

DECLARE @Programme TABLE(Name varchar(100) PRIMARY KEY, ProgrammeId int NULL);
INSERT @Programme(Name) SELECT DISTINCT Programme FROM @Catalogue;
IF EXISTS (SELECT s.Name FROM @Programme s JOIN dbo.PROGRAMS p
 ON LOWER(LTRIM(RTRIM(p.PROGRAM_NAME)))=LOWER(s.Name) GROUP BY s.Name HAVING COUNT(*)>1)
 THROW 51109, 'Duplicate programme categories found. Resolve them before loading.', 1;
INSERT dbo.PROGRAMS(PROGRAM_NAME) SELECT Name FROM @Programme s WHERE NOT EXISTS
 (SELECT 1 FROM dbo.PROGRAMS p WHERE LOWER(LTRIM(RTRIM(p.PROGRAM_NAME)))=LOWER(s.Name));
INSERT @Added VALUES ('Programme categories',@@ROWCOUNT);
UPDATE s SET ProgrammeId=p.PROGRAM_ID FROM @Programme s JOIN dbo.PROGRAMS p
 ON LOWER(LTRIM(RTRIM(p.PROGRAM_NAME)))=LOWER(s.Name);

DECLARE @Qualification TABLE(Name varchar(150) PRIMARY KEY, Programme varchar(100), QualId int NULL);
INSERT @Qualification(Name,Programme) SELECT Qualification,MIN(Programme) FROM @Catalogue GROUP BY Qualification;
IF EXISTS (SELECT s.Name FROM @Qualification s JOIN dbo.QUALIFICATIONS q
 ON LOWER(LTRIM(RTRIM(q.QUAL_NAME)))=LOWER(s.Name) GROUP BY s.Name HAVING COUNT(*)>1)
 THROW 51110, 'Duplicate existing qualification titles found. Resolve them before loading.', 1;
INSERT dbo.QUALIFICATIONS(QUAL_NAME,PROGRAM_ID)
SELECT q.Name,p.ProgrammeId FROM @Qualification q JOIN @Programme p ON p.Name=q.Programme
WHERE NOT EXISTS (SELECT 1 FROM dbo.QUALIFICATIONS x WHERE LOWER(LTRIM(RTRIM(x.QUAL_NAME)))=LOWER(q.Name));
INSERT @Added VALUES ('Qualification titles',@@ROWCOUNT);
UPDATE s SET QualId=q.QUAL_ID FROM @Qualification s JOIN dbo.QUALIFICATIONS q
 ON LOWER(LTRIM(RTRIM(q.QUAL_NAME)))=LOWER(s.Name);

IF EXISTS (SELECT u.UniversityId,q.QualId FROM @Catalogue c JOIN @University u ON u.Name=c.University
 JOIN @Qualification q ON q.Name=c.Qualification JOIN dbo.UNI_QUALIFICATIONS o
 ON o.UNIVERSITY_ID=u.UniversityId AND o.QUAL_ID=q.QualId
 GROUP BY u.UniversityId,q.QualId HAVING COUNT(*)>1)
 THROW 51111, 'Duplicate existing university/qualification offerings found. Resolve them before loading.', 1;
DECLARE @NewOfferings TABLE(Id int PRIMARY KEY);
INSERT dbo.UNI_QUALIFICATIONS(UNIVERSITY_ID,QUAL_ID,APPLICATION_CLOSING_DATE)
OUTPUT inserted.UNI_QUAL_ID INTO @NewOfferings(Id)
SELECT u.UniversityId,q.QualId,NULL FROM @Catalogue c JOIN @University u ON u.Name=c.University
JOIN @Qualification q ON q.Name=c.Qualification WHERE NOT EXISTS
 (SELECT 1 FROM dbo.UNI_QUALIFICATIONS o WHERE o.UNIVERSITY_ID=u.UniversityId AND o.QUAL_ID=q.QualId);
INSERT @Added VALUES ('University qualification offerings',@@ROWCOUNT);

IF EXISTS (SELECT 1 FROM @NewOfferings n JOIN [VarsityVaultSecurity].dbo.Policies p ON p.UNI_QUAL_ID=n.Id)
 THROW 51114, 'A stale security policy already uses a newly allocated offering ID. Review orphan policies before retrying.', 1;

-- Never attach a policy to an existing offering or overwrite an existing policy.
-- No QUALIFICATION_REQUIREMENTS rows are fabricated: unknown MIN_APS_SCORE cannot be safely represented there.
INSERT [VarsityVaultSecurity].dbo.Policies(UNI_QUAL_ID,PAYLOAD)
SELECT o.UNI_QUAL_ID,
 (SELECT 2028 AS intake,'pending' AS status,c.Source AS source,
  CAST(NULL AS int) AS minScore,CAST(NULL AS int) AS finalMinScore,
  CAST(NULL AS decimal(5,2)) AS minEnglish,CAST(NULL AS decimal(5,2)) AS minMath,
  JSON_QUERY('[]') AS requiredCodes,JSON_QUERY('{}') AS subjectMinimums,
  JSON_QUERY('[]') AS subjectGroups,JSON_QUERY('[]') AS requiredDocumentIds,
  CAST(NULL AS nvarchar(max)) AS scoring,CAST(NULL AS date) AS openingDate,
  '23:59' AS closingTime,CAST(1 AS bit) AS active,
  'standard-aps-6' AS scoringMethod,
  'Catalogue title only. Confirm 2028 availability, admission scoring, subject requirements and dates from the university before verification.' AS notes,
  c.Origin AS catalogueOrigin,'2026-10-28' AS catalogueLoadedOn
  FOR JSON PATH,WITHOUT_ARRAY_WRAPPER,INCLUDE_NULL_VALUES)
FROM @NewOfferings n JOIN dbo.UNI_QUALIFICATIONS o ON o.UNI_QUAL_ID=n.Id
JOIN @University u ON u.UniversityId=o.UNIVERSITY_ID
JOIN @Qualification q ON q.QualId=o.QUAL_ID
JOIN @Catalogue c ON c.University=u.Name AND c.Qualification=q.Name
WHERE NOT EXISTS (SELECT 1 FROM [VarsityVaultSecurity].dbo.Policies p WHERE p.UNI_QUAL_ID=o.UNI_QUAL_ID);
INSERT @Added VALUES ('Pending policies for new offerings',@@ROWCOUNT);

INSERT dbo.STUDY_MODES(STUDY_MODE_NAME)
SELECT s.STUDY_MODE_NAME FROM (VALUES
    (N'Full-time'),
    (N'Part-time')) s(STUDY_MODE_NAME)
WHERE NOT EXISTS (SELECT 1 FROM dbo.STUDY_MODES x WHERE LOWER(LTRIM(RTRIM(x.STUDY_MODE_NAME)))=LOWER(s.STUDY_MODE_NAME));
INSERT @Added VALUES ('STUDY_MODES',@@ROWCOUNT);

INSERT dbo.ADDRESS_TYPES(ADDRESS_TYPE_NAME)
SELECT s.ADDRESS_TYPE_NAME FROM (VALUES
    (N'Campus'),
    (N'Main Campus'),
    (N'Home')) s(ADDRESS_TYPE_NAME)
WHERE NOT EXISTS (SELECT 1 FROM dbo.ADDRESS_TYPES x WHERE LOWER(LTRIM(RTRIM(x.ADDRESS_TYPE_NAME)))=LOWER(s.ADDRESS_TYPE_NAME));
INSERT @Added VALUES ('ADDRESS_TYPES',@@ROWCOUNT);

INSERT dbo.EXAM_TYPES(EXAM_TYPE_NAME)
SELECT s.EXAM_TYPE_NAME FROM (VALUES
    (N'Grade 11 Final'),
    (N'Grade 12 June/Trial'),
    (N'Grade 12 Final (NSC)')) s(EXAM_TYPE_NAME)
WHERE NOT EXISTS (SELECT 1 FROM dbo.EXAM_TYPES x WHERE LOWER(LTRIM(RTRIM(x.EXAM_TYPE_NAME)))=LOWER(s.EXAM_TYPE_NAME));
INSERT @Added VALUES ('EXAM_TYPES',@@ROWCOUNT);

INSERT dbo.VERIFICATION_STATUSES(VERIFICATION_STATUS_NAME)
SELECT s.VERIFICATION_STATUS_NAME FROM (VALUES
    (N'Pending'),
    (N'Verified'),
    (N'Rejected')) s(VERIFICATION_STATUS_NAME)
WHERE NOT EXISTS (SELECT 1 FROM dbo.VERIFICATION_STATUSES x WHERE LOWER(LTRIM(RTRIM(x.VERIFICATION_STATUS_NAME)))=LOWER(s.VERIFICATION_STATUS_NAME));
INSERT @Added VALUES ('VERIFICATION_STATUSES',@@ROWCOUNT);

INSERT dbo.DOCUMENT_TYPES(DOCUMENT_TYPE_NAME,IS_MANDATORY,IS_LOCKED_UNTIL_FINAL)
SELECT s.DOCUMENT_TYPE_NAME,s.IS_MANDATORY,s.IS_LOCKED_UNTIL_FINAL FROM (VALUES
    (N'Grade 11 Final Report', 1, 0),
    (N'Certified Copy of Identity Document', 1, 0),
    (N'Grade 12 June/Trial Report', 0, 0),
    (N'Final NSC Certificate', 0, 1)) s(DOCUMENT_TYPE_NAME,IS_MANDATORY,IS_LOCKED_UNTIL_FINAL)
WHERE NOT EXISTS (SELECT 1 FROM dbo.DOCUMENT_TYPES x WHERE LOWER(LTRIM(RTRIM(x.DOCUMENT_TYPE_NAME)))=LOWER(s.DOCUMENT_TYPE_NAME));
INSERT @Added VALUES ('DOCUMENT_TYPES',@@ROWCOUNT);

INSERT dbo.APPLICATION_STATUSES(STATUS_NAME,USES_FINAL_RESULTS)
SELECT s.STATUS_NAME,s.USES_FINAL_RESULTS FROM (VALUES
    (N'Submitted', 0),
    (N'Screened by Career Teacher', 0),
    (N'Provisionally Accepted', 0),
    (N'Final Matric Verified', 1),
    (N'Admitted', 1),
    (N'Offer Revoked', 1),
    (N'Rejected', 0)) s(STATUS_NAME,USES_FINAL_RESULTS)
WHERE NOT EXISTS (SELECT 1 FROM dbo.APPLICATION_STATUSES x WHERE LOWER(LTRIM(RTRIM(x.STATUS_NAME)))=LOWER(s.STATUS_NAME));
INSERT @Added VALUES ('APPLICATION_STATUSES',@@ROWCOUNT);

INSERT dbo.ACTIONS(ACTION_NAME)
SELECT s.ACTION_NAME FROM (VALUES
    (N'Submitted'),
    (N'Screened by Career Teacher'),
    (N'Provisionally Accepted'),
    (N'Final Matric Verified'),
    (N'Admitted'),
    (N'Offer Revoked'),
    (N'Rejected')) s(ACTION_NAME)
WHERE NOT EXISTS (SELECT 1 FROM dbo.ACTIONS x WHERE LOWER(LTRIM(RTRIM(x.ACTION_NAME)))=LOWER(s.ACTION_NAME));
INSERT @Added VALUES ('ACTIONS',@@ROWCOUNT);

-- Add a subject only if its code is absent everywhere: do not duplicate existing school-specific subjects.
INSERT dbo.SUBJECTS(SUBJECT_NAME,SUBJECT_CODE,SCHOOL_ID,SUBJECT_CATEGORY)
SELECT s.Name,s.Code,NULL,s.Category FROM (VALUES
    (N'English Home Language', N'ENGHL', N'HOME_LANGUAGE'),
    (N'Afrikaans Home Language', N'AFRHL', N'HOME_LANGUAGE'),
    (N'isiXhosa Home Language', N'XHOHL', N'HOME_LANGUAGE'),
    (N'isiZulu Home Language', N'ZULHL', N'HOME_LANGUAGE'),
    (N'Sesotho Home Language', N'SOTHL', N'HOME_LANGUAGE'),
    (N'English First Additional Language', N'ENGFAL', N'FIRST_ADDITIONAL_LANGUAGE'),
    (N'Afrikaans First Additional Language', N'AFRFAL', N'FIRST_ADDITIONAL_LANGUAGE'),
    (N'isiXhosa First Additional Language', N'XHOFAL', N'FIRST_ADDITIONAL_LANGUAGE'),
    (N'isiZulu First Additional Language', N'ZULFAL', N'FIRST_ADDITIONAL_LANGUAGE'),
    (N'Mathematics', N'MATH', N'MATHEMATICS'),
    (N'Mathematical Literacy', N'MLIT', N'MATHEMATICAL_LITERACY'),
    (N'Life Orientation', N'LO', N'LIFE_ORIENTATION'),
    (N'Physical Sciences', N'PHSC', N'ELECTIVE'),
    (N'Life Sciences', N'LFSC', N'ELECTIVE'),
    (N'Accounting', N'ACCN', N'ELECTIVE'),
    (N'Business Studies', N'BUSS', N'ELECTIVE'),
    (N'Economics', N'ECON', N'ELECTIVE'),
    (N'Geography', N'GEOG', N'ELECTIVE'),
    (N'History', N'HIST', N'ELECTIVE'),
    (N'Information Technology', N'INFT', N'ELECTIVE')) s(Name,Code,Category)
WHERE NOT EXISTS (SELECT 1 FROM dbo.SUBJECTS x WHERE UPPER(LTRIM(RTRIM(x.SUBJECT_CODE)))=s.Code);
INSERT @Added VALUES ('School subjects',@@ROWCOUNT);

-- Preserve any existing achievement thresholds, including institution-specific choices.
INSERT dbo.ACHIEVEMENT_LEVELS(LEVEL_NO,LEVEL_DESCRIPTION,MIN_PERCENT,APS_POINTS)
SELECT s.LevelNo,s.Description,s.MinPercent,s.Points FROM (VALUES
 (1,'Not achieved',0,1),(2,'Elementary achievement',30,2),(3,'Moderate achievement',40,3),
 (4,'Adequate achievement',50,4),(5,'Substantial achievement',60,5),
 (6,'Meritorious achievement',70,6),(7,'Outstanding achievement',80,7)
) s(LevelNo,Description,MinPercent,Points)
WHERE NOT EXISTS (SELECT 1 FROM dbo.ACHIEVEMENT_LEVELS x WHERE x.LEVEL_NO=s.LevelNo OR x.MIN_PERCENT=s.MinPercent);
INSERT @Added VALUES ('Achievement levels',@@ROWCOUNT);

IF EXISTS (SELECT 1 FROM @NewOfferings n LEFT JOIN [VarsityVaultSecurity].dbo.Policies p ON p.UNI_QUAL_ID=n.Id
 WHERE p.UNI_QUAL_ID IS NULL OR ISJSON(p.PAYLOAD)<>1 OR JSON_VALUE(p.PAYLOAD,'$.status')<>'pending')
 THROW 51112, 'New offering policies failed validation.', 1;
IF (SELECT COUNT(*) FROM @Catalogue c JOIN @University u ON u.Name=c.University
 JOIN @Qualification q ON q.Name=c.Qualification JOIN dbo.UNI_QUALIFICATIONS o
 ON o.UNIVERSITY_ID=u.UniversityId AND o.QUAL_ID=q.QualId)<>260
 THROW 51113, 'Final catalogue coverage does not match 260 target offerings.', 1;

COMMIT TRANSACTION;
PRINT 'Catalogue loaded successfully. Existing users, applications and policies preserved.';
PRINT 'New catalogue entries are pending verification; historical requirements were not copied as 2028 requirements.';
SELECT Entity,RowsAdded FROM @Added;
SELECT u.Name AS CatalogueUniversity,u.UniversityId AS DatabaseUniversityId,
 COUNT(*) AS SelectedOfferingsMatched,
 SUM(CASE WHEN n.Id IS NOT NULL THEN 1 ELSE 0 END) AS NewlyAddedThisRun
FROM @Catalogue c JOIN @University u ON u.Name=c.University
JOIN @Qualification q ON q.Name=c.Qualification
JOIN dbo.UNI_QUALIFICATIONS o ON o.UNIVERSITY_ID=u.UniversityId AND o.QUAL_ID=q.QualId
LEFT JOIN @NewOfferings n ON n.Id=o.UNI_QUAL_ID
GROUP BY u.Name,u.UniversityId ORDER BY u.Name;

-- Report existing geography differences without changing cities, schools or users.
SELECT c.CITY_ID,c.CITY_NAME,p.PROVINCE_NAME AS ExistingProvince,
 'Existing geography needs review; no existing record was changed.' AS ReviewNote
FROM dbo.CITIES c JOIN dbo.PROVINCES p ON p.PROVINCE_ID=c.PROVINCE_ID
WHERE LOWER(LTRIM(RTRIM(c.CITY_NAME))) IN ('mahikeng','mafikeng')
 AND REPLACE(REPLACE(LOWER(p.PROVINCE_NAME),'-',''),' ','')<>'northwest';
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
 THROW;
END CATCH;
GO
