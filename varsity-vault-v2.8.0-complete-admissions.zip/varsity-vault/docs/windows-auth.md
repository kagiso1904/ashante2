# Connect from native Windows VS Code using your Windows account

Keep SQL Server's `IsIntegratedSecurityOnly` at **1**. No SQL login or Windows password is needed in `.env`. The Node.js process uses the Windows account that launches it. This does not automatically sign users into the VarsityVault website; application accounts remain separate.

## First connection check

1. Stop the previous app. Back up the project, then extract the update over its source while keeping `.env` and `.data`.
2. Install Microsoft ODBC Driver 18 for SQL Server for Windows (x64): https://learn.microsoft.com/en-us/sql/connect/odbc/download-odbc-driver-for-sql-server . Use native Windows Node.js 24.15+ (x64) and the VS Code PowerShell terminal, not WSL.
3. Run `npm ci`. The optional `msnodesqlv8` package supplies the native Windows connector. Do not use `--ignore-scripts` on Windows: its install script installs the native binary.
4. Merge the connection settings from `.env.windows.example` into `.env`. Keep any existing administrator values private. The supplied `localhost` plus `SQLEXPRESS` targets the local instance seen as `KAGISO\SQLEXPRESS` in SSMS. Leave DB_PORT empty. No DB_USER or DB_PASSWORD is needed.
5. Run `npm run db:check`. It only reads connection identity and metadata. It prints the Windows login, selected database and WindowsAuthOnly value, followed by the submitted schema check. Missing security database is reported separately. Send any error text for troubleshooting, without secrets.

No change to mixed authentication, SQL Browser, firewall or TCP/IP is required before trying the local connection. The installed ODBC client chooses an available local transport; shared memory was working in SSMS but still needs testing from Node.

## After the first check passes

Open `database/security.sql` in SSMS, connected to the same SQLEXPRESS instance, and execute it with an account authorised to create the separate `VarsityVaultSecurity` database. The script does not alter VARSITYVAULT2. The Windows account running Node needs access to both databases and the application's data operations; an administrator must grant that access if it is not already available. The security script does not grant new Windows logins automatically.

Set ADMIN_EMAIL and a private ADMIN_PASSWORD of 12–128 characters in `.env`. For a fresh 2.6.0 database, also set ADMIN_SCHOOL_ID to an existing school ID. Run `npm run setup`, then `npm start`. Open http://127.0.0.1:3000/login.html . Remove ADMIN_PASSWORD from `.env` after successful setup. Existing local SQLite accounts are not copied to SQL Server automatically; setup establishes the SQL-backed administrator. Existing SQL people can be linked under Accounts.

## Troubleshooting

- **Windows SQL driver could not load:** check native Windows Node with `node -p "process.platform + ' ' + process.arch"` (expected win32 x64). Run `npm ls msnodesqlv8`. If absent, run `npm install --include=optional` and inspect install errors. Install the ODBC x64 driver and reopen VS Code. Native compilation fallback may require C++ build tools; share the installer error before changing more settings.
- **Data source name not found / IM002:** inspect `Get-OdbcDriver | Where-Object Name -Like '*SQL Server*'` in PowerShell. The name in DB_ODBC_DRIVER must match an installed driver. Supported names are ODBC Driver 17 for SQL Server and ODBC Driver 18 for SQL Server.
- **Login failed / cannot open database:** run `whoami` in the same VS Code terminal and compare with the account used in SSMS. Database permissions belong to that Windows account. Do not switch to a SQL password.
- **Server not found / timeout:** confirm SQLEXPRESS is running and localhost\SQLEXPRESS works in SSMS on that computer. We can then inspect client protocol/TCP settings if necessary.
- **Certificate error:** the example opts into TrustServerCertificate only for this local development instance while keeping encryption enabled. Hosted use needs a properly trusted certificate.
- **Missing schema objects:** inspect the names reported by db:check; do not recreate or overwrite the submitted database.
- **Security database contract check failed:** run database/security.sql on the correct instance and check the Windows account's access to it.

Windows integrated authentication cannot be exercised in the Linux build environment. Configuration and local workflow tests validate the code; your db:check result is the live connection proof.

References: https://tediousjs.github.io/node-mssql/ and https://learn.microsoft.com/en-us/sql/connect/node-js/step-3-proof-of-concept-connecting-to-sql-using-node-js .
