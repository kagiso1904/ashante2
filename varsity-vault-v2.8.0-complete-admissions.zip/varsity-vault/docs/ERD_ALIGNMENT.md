# Varsity Vault 2.7.0: exact person/subtype keys

The supplied one-page ERD uses inherited PERSON_ID keys. The four role tables now match it without extra identity columns.

| Physical table | Exact columns | Primary key | Parent foreign keys |
|---|---|---|---|
| ITADMINS | PERSON_ID, SCHOOL_ID | PERSON_ID | PERSONS.PERSON_ID; SCHOOLS.SCHOOL_ID |
| LEARNERS | PERSON_ID, SCHOOL_ID | PERSON_ID | PERSONS.PERSON_ID; SCHOOLS.SCHOOL_ID |
| TEACHERS | PERSON_ID, SCHOOL_ID, DEPARTMENT, DESIGNATION | PERSON_ID | PERSONS.PERSON_ID; SCHOOLS.SCHOOL_ID |
| UNIVERSITY_REPS | PERSON_ID, UNIVERSITY_ID | PERSON_ID | PERSONS.PERSON_ID; UNIVERSITIES.UNIVERSITY_ID |

ITADMIN_IID, LEARNER_ID, TEACHER_ID and REP_ID are removed from those four tables. Foreign-key attributes on dependent tables keep their ERD names: APPLICATIONS.LEARNER_ID now references LEARNERS.PERSON_ID; APPLICATIONS.TEACHER_ID and DOCUMENTS/LEARNER_RESULTS.VERIFIED_BY_TEACHER_ID reference TEACHERS.PERSON_ID; APPLICATIONS.REVIEWED_BY_REP_ID references UNIVERSITY_REPS.PERSON_ID. A foreign-key column does not have to have the same name as its parent key.

The application, all 22 SQL modules, metadata contract and role selectors use the new keys. There are 30 academic tables, 126 columns and 43 foreign keys. Singular diagram names map to the existing plural SQL table names.

## Installing on the database that already completed 2.6.0

1. Stop the app. Back up VARSITYVAULT2 and VarsityVaultSecurity in SSMS.
2. Open database/04_use_person_id_for_subtypes.sql with VARSITYVAULT2 selected. Execute the entire file.
3. Install the 2.7.0 app code, preserving .env, .data and node_modules.
4. Run database/03_verify_erd_alignment.sql. Require PASS and ISSUE_COUNT=0. The last result lists the exact four role-table column sets.
5. Run npm run db:check and npm start. Refresh with Ctrl+Shift+R and sign in again.

Do not rerun script 02 after 2.6.0 completed. Script 04 is the next migration. Fresh databases can use the supplied strict source schema directly; do not run CREATE DATABASE scripts against an existing database.

The migration uses one transaction across the two databases on the same SQL Server instance. It captures one-to-one old-ID/person-ID maps, checks every affected reference, stages identifiers through a disjoint negative range to avoid unique-key collisions, recreates the foreign keys against PERSON_ID, updates dependent SQL modules, and only then removes the obsolete columns/indexes. Any error rolls the operation back. Existing person IDs, applications, results, marks, files, decisions, account passwords and timestamps are retained. Active sessions are cleared so users sign in with the new role context.

Original audit records remain unchanged. A migration event stores the explicit ID maps and an exact list of legacy audit IDs. The app translates historical result lookup keys when reading them. This prevents one learner's old ID from colliding with another learner's new person ID and preserves history/version numbering. This mapping is an audit event, not another academic table.

PERSON_TYPE is required (L/T/A/R). Atomic person creation creates the corresponding subtype immediately, and enabled guards enforce disjoint, total membership. Reviewers and verification fields remain optional until their workflow actions. Shared national subjects retain optional SCHOOL_ID.

## Normalisation

1NF: person attributes, reference values and subject/result records are stored as separate atomic attributes and rows.
2NF: a learner result is identified by (LEARNER_ID, SUBJECT_ID, EXAM_TYPE_ID); its mark and verification describe that result. Enrolment is a separate learner/subject association.
3NF improvements: shared personal details exist in PERSON; subtype tables store only their person key and role-specific attributes. Removing the extra role identities removes unnecessary identifiers and aligns specialisation with the ERD. Universities, qualifications, subjects and reference descriptions remain in their own entities. UNI_QUALIFICATION represents university offerings and APPLICATION_PROCESS stores repeated history events separately.

Do not claim the entire database is strictly in 3NF: SCHOOL stores both CITY_ID and PROVINCE_ID as the submitted model requires. CITY determines province, so this is retained controlled redundancy, guarded against disagreement. A strictly normalised alternative would derive school province through CITY. Policy JSON/current requirement overlap and login identity duplication were not redesigned here. Historic audit snapshots are intentional past records.

## Complete physical relationships

For subtypes, total means one subtype across all four, not membership in every subtype.

| Relationship | Foreign key | Parents per child | Children per parent |
|---|---|---|---|
| PROVINCE → CITY | `CITIES.PROVINCE_ID` → `PROVINCES.PROVINCE_ID` | Exactly one | Zero or many |
| CITY → SCHOOL | `SCHOOLS.CITY_ID` → `CITIES.CITY_ID` | Exactly one | Zero or many |
| PROVINCE → SCHOOL | `SCHOOLS.PROVINCE_ID` → `PROVINCES.PROVINCE_ID` | Exactly one | Zero or many |
| PROVINCE → UNIVERSITY | `UNIVERSITIES.PROVINCE_ID` → `PROVINCES.PROVINCE_ID` | Exactly one | Zero or many |
| PROGRAM → QUALIFICATION | `QUALIFICATIONS.PROGRAM_ID` → `PROGRAMS.PROGRAM_ID` | Exactly one | Zero or many |
| SCHOOL → SUBJECT | `SUBJECTS.SCHOOL_ID` → `SCHOOLS.SCHOOL_ID` | Zero or one | Zero or many |
| PERSON → TEACHER | `TEACHERS.PERSON_ID` → `PERSONS.PERSON_ID` | Exactly one | Zero or one |
| SCHOOL → TEACHER | `TEACHERS.SCHOOL_ID` → `SCHOOLS.SCHOOL_ID` | Exactly one | Zero or many |
| PERSON → LEARNER | `LEARNERS.PERSON_ID` → `PERSONS.PERSON_ID` | Exactly one | Zero or one |
| SCHOOL → LEARNER | `LEARNERS.SCHOOL_ID` → `SCHOOLS.SCHOOL_ID` | Exactly one | Zero or many |
| PERSON → ITADMIN | `ITADMINS.PERSON_ID` → `PERSONS.PERSON_ID` | Exactly one | Zero or one |
| SCHOOL → ITADMIN | `ITADMINS.SCHOOL_ID` → `SCHOOLS.SCHOOL_ID` | Exactly one | Zero or many |
| CITY → PERSON_ADDRESS | `PERSON_ADDRESSES.CITY_ID` → `CITIES.CITY_ID` | Exactly one | Zero or many |
| PERSON → PERSON_ADDRESS | `PERSON_ADDRESSES.PERSON_ID` → `PERSONS.PERSON_ID` | Exactly one | Zero or many |
| ADDRESS_TYPE → PERSON_ADDRESS | `PERSON_ADDRESSES.ADDRESS_TYPE_ID` → `ADDRESS_TYPES.ADDRESS_TYPE_ID` | Exactly one | Zero or many |
| CITY → UNIVERSITY_ADDRESS | `UNIVERSITY_ADDRESSES.CITY_ID` → `CITIES.CITY_ID` | Exactly one | Zero or many |
| ADDRESS_TYPE → UNIVERSITY_ADDRESS | `UNIVERSITY_ADDRESSES.ADDRESS_TYPE_ID` → `ADDRESS_TYPES.ADDRESS_TYPE_ID` | Exactly one | Zero or many |
| UNIVERSITY → UNIVERSITY_ADDRESS | `UNIVERSITY_ADDRESSES.UNIVERSITY_ID` → `UNIVERSITIES.UNIVERSITY_ID` | Exactly one | Zero or many |
| PERSON → UNIVERSITY_REP | `UNIVERSITY_REPS.PERSON_ID` → `PERSONS.PERSON_ID` | Exactly one | Zero or one |
| UNIVERSITY → UNIVERSITY_REP | `UNIVERSITY_REPS.UNIVERSITY_ID` → `UNIVERSITIES.UNIVERSITY_ID` | Exactly one | Zero or many |
| UNIVERSITY → PROSPECTUS | `PROSPECTUSES.UNIVERSITY_ID` → `UNIVERSITIES.UNIVERSITY_ID` | Exactly one | Zero or many |
| QUALIFICATION → UNI_QUALIFICATION | `UNI_QUALIFICATIONS.QUAL_ID` → `QUALIFICATIONS.QUAL_ID` | Exactly one | Zero or many |
| UNIVERSITY → UNI_QUALIFICATION | `UNI_QUALIFICATIONS.UNIVERSITY_ID` → `UNIVERSITIES.UNIVERSITY_ID` | Exactly one | Zero or many |
| UNI_QUALIFICATION → QUALIFICATION_REQUIREMENT | `QUALIFICATION_REQUIREMENTS.UNI_QUAL_ID` → `UNI_QUALIFICATIONS.UNI_QUAL_ID` | Exactly one | Zero or one |
| LEARNER → APPLICATION | `APPLICATIONS.LEARNER_ID` → `LEARNERS.PERSON_ID` | Exactly one | Zero or many |
| STUDY_MODE → APPLICATION | `APPLICATIONS.STUDY_MODE_ID` → `STUDY_MODES.STUDY_MODE_ID` | Exactly one | Zero or many |
| TEACHER → APPLICATION | `APPLICATIONS.TEACHER_ID` → `TEACHERS.PERSON_ID` | Zero or one | Zero or many |
| UNI_QUALIFICATION → APPLICATION | `APPLICATIONS.UNI_QUAL_ID` → `UNI_QUALIFICATIONS.UNI_QUAL_ID` | Exactly one | Zero or many |
| APPLICATION_STATUS → APPLICATION | `APPLICATIONS.STATUS_ID` → `APPLICATION_STATUSES.STATUS_ID` | Exactly one | Zero or many |
| UNIVERSITY_REP → APPLICATION | `APPLICATIONS.REVIEWED_BY_REP_ID` → `UNIVERSITY_REPS.PERSON_ID` | Zero or one | Zero or many |
| ACTION → APPLICATION_PROCESS | `APPLICATION_PROCESSES.ACTION_ID` → `ACTIONS.ACTION_ID` | Exactly one | Zero or many |
| APPLICATION → APPLICATION_PROCESS | `APPLICATION_PROCESSES.APPLICATION_ID` → `APPLICATIONS.APPLICATION_ID` | Exactly one | Zero or many |
| VERIFICATION_STATUS → DOCUMENT | `DOCUMENTS.VERIFICATION_STATUS_ID` → `VERIFICATION_STATUSES.VERIFICATION_STATUS_ID` | Exactly one | Zero or many |
| TEACHER → DOCUMENT | `DOCUMENTS.VERIFIED_BY_TEACHER_ID` → `TEACHERS.PERSON_ID` | Zero or one | Zero or many |
| PERSON → DOCUMENT | `DOCUMENTS.PERSON_ID` → `PERSONS.PERSON_ID` | Exactly one | Zero or many |
| DOCUMENT_TYPE → DOCUMENT | `DOCUMENTS.DOCUMENT_TYPE_ID` → `DOCUMENT_TYPES.DOCUMENT_TYPE_ID` | Exactly one | Zero or many |
| EXAM_TYPE → LEARNER_RESULT | `LEARNER_RESULTS.EXAM_TYPE_ID` → `EXAM_TYPES.EXAM_TYPE_ID` | Exactly one | Zero or many |
| LEARNER → LEARNER_RESULT | `LEARNER_RESULTS.LEARNER_ID` → `LEARNERS.PERSON_ID` | Exactly one | Zero or many |
| SUBJECT → LEARNER_RESULT | `LEARNER_RESULTS.SUBJECT_ID` → `SUBJECTS.SUBJECT_ID` | Exactly one | Zero or many |
| VERIFICATION_STATUS → LEARNER_RESULT | `LEARNER_RESULTS.VERIFICATION_STATUS_ID` → `VERIFICATION_STATUSES.VERIFICATION_STATUS_ID` | Exactly one | Zero or many |
| TEACHER → LEARNER_RESULT | `LEARNER_RESULTS.VERIFIED_BY_TEACHER_ID` → `TEACHERS.PERSON_ID` | Zero or one | Zero or many |
| LEARNER → LEARNER_SUBJECT | `LEARNER_SUBJECTS.LEARNER_ID` → `LEARNERS.PERSON_ID` | Exactly one | Zero or many |
| SUBJECT → LEARNER_SUBJECT | `LEARNER_SUBJECTS.SUBJECT_ID` → `SUBJECTS.SUBJECT_ID` | Exactly one | Zero or many |

## Validation limit

Local tests cover exact subtype shapes, four-role HTTP workflows, verification, admission decisions, CRUD, legacy history collisions, schema contracts and reusable app logic. DOM module smoke checks exercise portal pages using the real local HTTP APIs. These checks do not execute the SQL Server migration on your Windows instance. The supplied live audit is the final schema/data check after script 04 runs.

Validation completed for this release: 52 local automated checks passed, including a four-role HTTP lifecycle, and all 31 portal pages rendered through their actual local HTTP APIs in DOM module smoke checks. SQL Server migration execution still requires verification on the user instance.
