# Presentation script: user interface, database integration, accounts, validation and CRUD

Estimated recording time: 6-8 minutes, depending on typing and switching screens. These sections cover video points 5 and 6. Keep your earlier problem statement, requirements, ERD and implementation sections before this sequence.

## Before recording

- Install this release and run `npm run admissions:load`, then `npm start`. Confirm the terminal says **sqlserver**. Do not use a local SQLite run as evidence of changes in SSMS.
- Have an unused email address you control and a school available for registration. Check that your configured email delivery works and PUBLIC_APP_URL points to the running app. Use a password of at least 12 characters. The password field stays masked.
- Have a prepared learner account with a complete saved Grade 11 subject combination: one Home Language, one First Additional Language, Mathematics or Mathematical Literacy, Life Orientation and at least three additional academic subjects. Use an unlocked result set for the mark update.
- Keep the IT administrator account available for CRUD. Use **Academic Records > PROGRAMS** and a new unused record called **Digital Innovation**. This demonstrates database operations without deleting a real university or application.
- Open `database/09_presentation_evidence.sql` in SSMS. Set the email variables to the accounts you use. All queries in that file are read-only.

## Point 5: User Interface

| Action / screen | Exact words to read aloud |
|---|---|
| Open the login page and choose **Create account**. Point to the names, email, school and password fields. | “Learners can create their own accounts through the registration form. The form captures their name, email address, school and password. The school selection links the learner to an existing school.” |
| Enter an incorrectly formatted email and try to submit. Then correct it. Briefly show that a short password does not satisfy the password rule. | “The interface validates the information before accepting it. For example, an invalid email address or a password shorter than twelve characters must be corrected. The backend also validates submitted information before writing it to the database.” |
| Enter valid details, submit, and show the account-created message. Complete the email-verification step using the delivered link, then sign in. | “After valid information is submitted, the system creates the account and sends an email-verification link. The password is stored as a salted hash rather than readable text. After verifying the email address, the learner can sign in.” |
| Switch to the prepared learner account, if needed, and show its dashboard. | “I will now use a learner with a saved academic record to demonstrate the university and qualification features. The navigation gives access to profile details, results, documents, university information and applications.” |
| Open **Universities**. Search for Walter Sisulu University and open **University details**. | “Learners can search by university, qualification, city or province. The university profile shows its recorded campus locations, website, available prospectuses and qualifications.” |
| Open **View requirements** for WSU's existing ICT Applications Development qualification. Show the score, common subjects, alternative routes, documents and application dates. | “This page shows the entry score and subject requirements for the selected qualification. The Mathematics and Mathematical Literacy routes can have different subject percentages and score thresholds. The system also shows how the score is calculated, the supporting documents and the configured application window.” |
| Scroll to the learner's score and eligibility result. | “The application compares the learner's saved marks with the selected qualification's rules. It checks the score and subject requirements together. Meeting these academic minimums does not itself guarantee an admission offer.” |

## Point 6A: Capture, retrieve and validate results

| Action / screen | Exact words to read aloud |
|---|---|
| Open **Results**, select **Grade 11 Final**, and choose an unlocked subject mark. Enter **150** and try to save. | “A subject percentage must be between zero and one hundred. An out-of-range value is rejected, which prevents invalid academic information from being stored.” |
| Replace the invalid value with **75**, save, and show the success message. | “When I save a valid percentage, the browser sends a request to the Node.js and Express backend. The backend checks the learner's access, validates the value and writes the record to SQL Server.” |
| Switch to SSMS and run evidence query B for the active learner. Point to the same learner, subject, examination type and mark. | “The saved percentage is now visible in LEARNER_RESULTS. Its learner, subject and examination identifiers link it to the related records. The joins retrieve readable names from those tables.” |
| Refresh the app's Results page and select the same milestone. | “After refreshing, the same percentage is retrieved from the database and displayed again. This demonstrates persistent storage, rather than a value that exists only on the current page.” |

## Point 6B: Demonstrate complete CRUD

Sign in as the IT administrator. Open **Academic Records** and select **PROGRAMS**. Programme categories are suitable because you can create an unused category without assigning it to a university qualification.

| Operation | Action / screen | Exact words to read aloud |
|---|---|---|
| Create | Leave the programme name blank and attempt to save. Then enter **Digital Innovation** and choose **Save record**. Run evidence query C in SSMS. | “An empty programme name is not accepted. After entering a valid name, I save the record. The database generates its primary key, and the new programme appears in both the interface and SQL Server.” |
| Read | Use **Filter records** to find **Digital Innovation**. Point to its programme ID and name. | “This is the read operation. The system retrieves the saved programme record and displays its identifier and name in the table.” |
| Validation | Attempt to create another programme with the exact same name. Show the rejection message. | “The backend also checks for duplicate programme names. The second record is rejected, so the database does not receive an unnecessary duplicate.” |
| Update | Select **Edit** for the original record. Change its name to **Digital Innovation and Business** and save. Run evidence query C again. | “For the update operation, I change the existing record's name. Its primary key remains the same, while the updated name is saved and displayed.” |
| Delete | Delete this unused programme and confirm. Refresh the list, then run evidence query C once more. | “For the delete operation, I remove the unused record. It no longer appears in the interface or the database query. The system prevents deletion when a record is referenced by other records.” |

Optional extra relationship validation: create a temporary qualification referencing the programme, try deleting the programme and show the refusal. Delete the temporary qualification first, then delete the programme. Do this only with the new unused records you created, not existing admissions data.

## Account database evidence and closing

Run evidence query A immediately after creating the account if you want to show that step in SQL Server. It joins PERSONS to LEARNERS using PERSON_ID and checks the separate sign-in account without revealing its password hash.

Read aloud:

“The user interface, backend and database work together throughout the system. The interface captures the user's input and displays the response. The backend applies validation and access rules. SQL Server stores the records and their relationships, allowing the system to retrieve, update and protect the information consistently.”

## Recording order at a glance

Create account -> invalid entry -> correct details -> email verification -> sign in -> universities -> qualification score and subject routes -> invalid mark -> valid saved mark -> SSMS proof -> refresh -> administrator PROGRAMS create -> read -> duplicate validation -> update -> delete -> SSMS proof.

Do not say that all university sources have confirmed the 2028 entry requirements. The import combines your 2027 source set, UMP programme pages and existing configured minimums. The operational application calendar belongs to the app's 2028 intake configuration.
