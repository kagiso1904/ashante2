const reject = (message) => {
  throw Object.assign(new Error(message), { status: 400 });
};
export function httpsUrl(value, label = 'Website') {
  if (typeof value !== 'string' || value.length > 255)
    reject(`${label} must be a valid HTTPS URL, at most 255 characters.`);
  try {
    const url = new URL(value);
    if (
      url.protocol !== 'https:' ||
      !url.hostname.includes('.') ||
      url.username ||
      url.password ||
      /\s/.test(value)
    )
      throw Error();
  } catch {
    reject(`${label} must be a complete HTTPS URL such as https://www.university.ac.za.`);
  }
  return value.trim();
}
export const directoryLimits = {
  SCHOOL_NAME: 150,
  EMIS_NUMBER: 30,
  UNIVERSITY_NAME: 150,
  WEBSITE: 255,
  STREET_NAME: 150,
  CITY_NAME: 100,
  PROVINCE_NAME: 50,
  SUBJECT_NAME: 100,
  SUBJECT_CODE: 20,
  SUBJECT_CATEGORY: 30,
  EXAM_TYPE_NAME: 50,
  STUDY_MODE_NAME: 50,
};
export function validateDirectoryFields(data) {
  for (const [key, value] of Object.entries(data)) {
    if (key.endsWith('_ID')) continue;
    if (
      typeof value !== 'string' ||
      !value.trim() ||
      value.length > directoryLimits[key] ||
      /[\u0000-\u001f\u007f]/.test(value)
    )
      reject(
        `${key.replaceAll('_', ' ')} is required and must be at most ${directoryLimits[key]} characters without control characters.`,
      );
    if (
      [
        'CITY_NAME',
        'PROVINCE_NAME',
        'SCHOOL_NAME',
        'UNIVERSITY_NAME',
        'SUBJECT_NAME',
        'EXAM_TYPE_NAME',
        'STUDY_MODE_NAME',
      ].includes(key) &&
      !/\p{L}/u.test(value)
    )
      reject(`${key.replaceAll('_', ' ')} must contain a meaningful name with letters.`);
  }
  if (data.WEBSITE !== undefined) httpsUrl(data.WEBSITE);
  if (data.SUBJECT_CODE !== undefined && !/^[A-Z][A-Z0-9_-]{0,19}$/.test(data.SUBJECT_CODE))
    reject(
      'Subject code must begin with a letter and use uppercase letters, digits, underscores or hyphens.',
    );
  if (data.EMIS_NUMBER !== undefined && !/^[A-Za-z0-9][A-Za-z0-9-]{0,29}$/.test(data.EMIS_NUMBER))
    reject('EMIS number must use letters, digits or hyphens, up to 30 characters.');
}
export function safeFilename(value) {
  let name;
  try {
    name = decodeURIComponent(value || 'upload');
  } catch {
    reject('The uploaded filename is invalid. Rename the file and try again.');
  }
  if (!name.trim() || name.length > 200 || /[\u0000-\u001f\u007f/\\]/.test(name))
    reject('Use a filename of 1–200 characters without path separators or control characters.');
  return name.replace(/[^a-zA-Z0-9._ -]/g, '_');
}
