import { randomUUID } from 'node:crypto';
import { passwordHash } from './security.js';
import {
  findPersonSaIdMatches,
  isValidPersonName,
  isValidSouthAfricanIdNumber,
  isValidSouthAfricanPhone,
  normalizeIdentity,
  sameId,
} from './identity.js';

export const SAMPLE_PASSWORD = 'Workflow@2028!Change';
export const SAMPLE_UNIVERSITY_NAME = 'Mhlabeni Metropolitan University';
export const SAMPLE_SCHOOL_NAME = 'Siyakhula Secondary School';
export const SAMPLE_OFFERING_NAME = 'Diploma in Application Development - 2028 Intake';

const TODAY = () =>
  new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Africa/Johannesburg',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date());
const norm = (value) => normalizeIdentity(value);

export const SAMPLE_USERS = [
  {
    key: 'ready',
    email: 'thabo.mokoena@varsityvault.test',
    firstName: 'Thabo',
    lastName: 'Mokoena',
    phone: '0765543218',
    saIdNumber: '0807166000081',
    role: 'learner',
    applicationStage: null,
    resultStage: 'pending',
    documentStage: 'pending',
  },
  {
    key: 'submitted',
    email: 'lerato.nkosi@varsityvault.test',
    firstName: 'Lerato',
    lastName: 'Nkosi',
    phone: '0736284915',
    saIdNumber: '0802242137080',
    role: 'learner',
    applicationStage: 'Submitted',
    resultStage: 'pending',
    documentStage: 'pending',
  },
  {
    key: 'screened',
    email: 'naledi.molefe@varsityvault.test',
    firstName: 'Naledi',
    lastName: 'Molefe',
    phone: '0784126930',
    saIdNumber: '0711122274089',
    role: 'learner',
    applicationStage: 'Screened by Career Teacher',
    resultStage: 'verified',
    documentStage: 'verified',
  },
  {
    key: 'provisional',
    email: 'sipho.dlamini@varsityvault.test',
    firstName: 'Sipho',
    lastName: 'Dlamini',
    phone: '0729361845',
    saIdNumber: '0804056411080',
    role: 'learner',
    applicationStage: 'Provisionally Accepted',
    resultStage: 'verified',
    documentStage: 'verified',
    includeFinalResults: true,
  },
  {
    key: 'admitted',
    email: 'zanele.khumalo@varsityvault.test',
    firstName: 'Zanele',
    lastName: 'Khumalo',
    phone: '0795612384',
    saIdNumber: '0809152548081',
    role: 'learner',
    applicationStage: 'Admitted',
    resultStage: 'verified',
    documentStage: 'verified',
    includeFinalResults: true,
  },
  {
    key: 'teacher',
    email: 'nomsa.mthembu@varsityvault.test',
    firstName: 'Nomsa',
    lastName: 'Mthembu',
    phone: '0834276195',
    saIdNumber: '8509182685083',
    role: 'teacher',
  },
  {
    key: 'representative',
    email: 'pieter.vandermerwe@varsityvault.test',
    firstName: 'Pieter',
    lastName: 'van der Merwe',
    phone: '0713958264',
    saIdNumber: '7905026822083',
    role: 'representative',
  },
  {
    key: 'admin',
    email: 'sizwe.molapo@varsityvault.test',
    firstName: 'Sizwe',
    lastName: 'Molapo',
    phone: '0826481357',
    saIdNumber: '8806236959088',
    role: 'admin',
  },
];

const GRADE11 = [
  ['ENGHL', 75],
  ['ZULFAL', 86],
  ['MATH', 54],
  ['LFSC', 69],
  ['GEOG', 71],
  ['PHSC', 65],
  ['LO', 77],
];
const GRADE12 = [
  ['ENGHL', 82],
  ['ZULFAL', 78],
  ['MATH', 73],
  ['LFSC', 80],
  ['GEOG', 75],
  ['PHSC', 72],
  ['LO', 84],
];

function escapePdf(value) {
  return String(value)
    .replace(/[^\x20-\x7e]/g, '?')
    .replace(/[\\()]/g, '\\$&');
}

/** Minimal real PDF, clearly marked as synthetic test evidence (never official student evidence). */
export function makeSamplePdf(title, lines = []) {
  const rows = [
    title,
    'SAMPLE RECORD - NOT OFFICIAL EVIDENCE',
    'NOT AN OFFICIAL STUDENT DOCUMENT',
    ...lines,
  ].slice(0, 12);
  let content = 'BT\n/F1 16 Tf\n50 740 Td\n';
  rows.forEach((line, index) => {
    if (index > 0) content += '0 -30 Td\n/F1 11 Tf\n';
    content += `(${escapePdf(line)}) Tj\n`;
  });
  content += 'ET\n';
  const stream = Buffer.from(content, 'ascii');
  const objects = [
    '<< /Type /Catalog /Pages 2 0 R >>',
    '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>',
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
    `<< /Length ${stream.length} >>\nstream\n${content}endstream`,
  ];
  let body = '%PDF-1.4\n% Varsity Vault synthetic sample fixture\n';
  const offsets = [0];
  objects.forEach((object, index) => {
    offsets.push(Buffer.byteLength(body, 'ascii'));
    body += `${index + 1} 0 obj\n${object}\nendobj\n`;
  });
  const xrefOffset = Buffer.byteLength(body, 'ascii');
  body += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  for (let i = 1; i < offsets.length; i++)
    body += `${String(offsets[i]).padStart(10, '0')} 00000 n \n`;
  body += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF\n`;
  return Buffer.from(body, 'ascii');
}

async function oneOrCreate(db, table, column, value, fields = {}) {
  const matches = (await db.list(table)).filter((row) => norm(row[column]) === norm(value));
  if (matches.length > 1)
    throw new Error(
      `More than one ${table}.${column} matches "${value}". Resolve duplicates before seeding sample data.`,
    );
  return matches[0] || db.insert(table, { [column]: value, ...fields });
}

async function ensureLookup(db, table, column, value, fields = {}) {
  return oneOrCreate(db, table, column, value, fields);
}

async function ensurePerson(db, spec, schoolId, universityId) {
  if (!isValidPersonName(spec.firstName) || !isValidPersonName(spec.lastName))
    throw new Error(`The configured person name for ${spec.email} is invalid.`);
  if (!isValidSouthAfricanPhone(spec.phone || ''))
    throw new Error(`The configured phone number for ${spec.email} is invalid.`);
  if (spec.role === 'learner' && !isValidSouthAfricanIdNumber(spec.saIdNumber))
    throw new Error(`The configured South African ID value for ${spec.email} is invalid.`);

  const people = await db.list('PERSONS');
  const matches = people.filter((person) =>
    [person.EMAIL, person.USERNAME].some((value) => norm(value) === norm(spec.email)),
  );
  if (matches.length > 1)
    throw new Error(`Multiple PERSONS rows match ${spec.email}; no sample identity was changed.`);
  const candidatePersonId = matches.length === 1 ? matches[0].PERSON_ID : null;
  if (spec.saIdNumber) {
    const collisions = findPersonSaIdMatches(people, spec.saIdNumber, candidatePersonId);
    if (collisions.length)
      throw new Error(
        `The configured ID value for ${spec.email} already exists on another person record. No records were merged or changed.`,
      );
  }
  if (matches.length === 1) {
    const person = matches[0];
    if (
      !norm(person.EMAIL).endsWith('@varsityvault.test') ||
      norm(person.EMAIL) !== norm(spec.email) ||
      norm(person.USERNAME) !== norm(spec.email)
    )
      throw new Error(
        `The reserved workflow identity ${spec.email} already maps to a mismatched PERSONS row. Review it manually; no data was merged.`,
      );
    const patch = {};
    if (!person.PHONE_NUMBER && spec.phone) patch.PHONE_NUMBER = spec.phone;
    if (!person.SA_ID_NUMBER && spec.saIdNumber) patch.SA_ID_NUMBER = spec.saIdNumber;
    if (Object.keys(patch).length)
      await db.update('PERSONS', { PERSON_ID: person.PERSON_ID }, patch);
    return { ...person, ...patch };
  }
  return db.createPerson({
    FIRST_NAME: spec.firstName,
    LAST_NAME: spec.lastName,
    EMAIL: spec.email,
    USERNAME: spec.email,
    PHONE_NUMBER: spec.phone || null,
    SA_ID_NUMBER: spec.saIdNumber || null,
  }, {type: {learner:'L',teacher:'T',admin:'A',representative:'R'}[spec.role],schoolId,universityId});
}

async function ensureSingleRole(db, person, target, fields) {
  const roleTables = [
    ['LEARNERS', 'learner'],
    ['TEACHERS', 'teacher'],
    ['UNIVERSITY_REPS', 'representative'],
    ['ITADMINS', 'admin'],
  ];
  for (const [table, role] of roleTables) {
    const rows = (await db.list(table)).filter((row) => sameId(row.PERSON_ID, person.PERSON_ID));
    if (role === target) {
      if (rows.length > 1)
        throw new Error(`sample person ${person.PERSON_ID} has multiple ${role} rows.`);
      if (rows.length === 1) {
        for (const [key, expected] of Object.entries(fields)) {
          if (rows[0][key] != null && expected != null && !sameId(rows[0][key], expected))
            throw new Error(
              `sample ${role} has an unexpected ${key}; refusing to change its scope.`,
            );
        }
        return rows[0];
      }
    } else if (rows.length) {
      throw new Error(`sample person ${person.PERSON_ID} already has a different role (${role}).`);
    }
  }
  return db.insert(
    {
      learner: 'LEARNERS',
      teacher: 'TEACHERS',
      representative: 'UNIVERSITY_REPS',
      admin: 'ITADMINS',
    }[target],
    { PERSON_ID: person.PERSON_ID, ...fields },
  );
}

async function ensureAccount(db, person, email, hash) {
  const accounts = await db.list('security.Accounts');
  const byEmail = accounts.filter((a) => norm(a.USERNAME) === norm(email));
  const byPerson = accounts.filter((a) => sameId(a.PERSON_ID, person.PERSON_ID));
  if (
    byEmail.some((a) => !sameId(a.PERSON_ID, person.PERSON_ID)) ||
    byPerson.some((a) => norm(a.USERNAME) !== norm(email))
  )
    throw new Error(`The sample login ${email} conflicts with an existing security account.`);
  if (byPerson.length > 1 || byEmail.length > 1)
    throw new Error(`Multiple security account rows match ${email}.`);
  if (byPerson.length === 1) {
    // sample-only reserved identities may be reset to the documented training password on rerun.
    await db.update(
      'security.Accounts',
      { ACCOUNT_ID: byPerson[0].ACCOUNT_ID },
      { PASSWORD_HASH: hash, DISABLED: 0 },
    );
  } else {
    await db.insert('security.Accounts', {
      ACCOUNT_ID: randomUUID(),
      PERSON_ID: person.PERSON_ID,
      USERNAME: email,
      PASSWORD_HASH: hash,
      DISABLED: 0,
    });
  }
  const verification = (
    await db.list('security.EmailVerifications', { PERSON_ID: person.PERSON_ID })
  )[0];
  if (verification) {
    if (!verification.VERIFIED_AT)
      await db.update(
        'security.EmailVerifications',
        { PERSON_ID: person.PERSON_ID },
        { VERIFIED_AT: new Date().toISOString() },
      );
  } else
    await db.insert('security.EmailVerifications', {
      PERSON_ID: person.PERSON_ID,
      VERIFIED_AT: new Date().toISOString(),
    });
}

async function ensureSubject(db, code, percentageCategory) {
  const matches = (await db.list('SUBJECTS')).filter(
    (row) => norm(row.SUBJECT_CODE) === norm(code) && row.SCHOOL_ID == null,
  );
  if (matches.length > 1)
    throw new Error(
      `Multiple global subject rows use code ${code}. Resolve duplicate subject codes first.`,
    );
  if (matches.length === 1) {
    if (matches[0].SUBJECT_CATEGORY !== percentageCategory)
      throw new Error(
        `Subject ${code} has category ${matches[0].SUBJECT_CATEGORY}; expected ${percentageCategory}.`,
      );
    return matches[0];
  }
  const subjectDefs = {
    ENGHL: ['English Home Language', 'HOME_LANGUAGE'],
    ZULFAL: ['isiZulu First Additional Language', 'FIRST_ADDITIONAL_LANGUAGE'],
    MATH: ['Mathematics', 'MATHEMATICS'],
    LFSC: ['Life Sciences', 'ELECTIVE'],
    GEOG: ['Geography', 'ELECTIVE'],
    PHSC: ['Physical Sciences', 'ELECTIVE'],
    LO: ['Life Orientation', 'LIFE_ORIENTATION'],
  };
  const [SUBJECT_NAME, SUBJECT_CATEGORY] = subjectDefs[code] || [];
  if (!SUBJECT_NAME || SUBJECT_CATEGORY !== percentageCategory)
    throw new Error(`Missing known sample subject definition for ${code}.`);
  return db.insert('SUBJECTS', {
    SUBJECT_NAME,
    SUBJECT_CODE: code,
    SCHOOL_ID: null,
    SUBJECT_CATEGORY,
  });
}

async function ensureResult(
  db,
  learnerId,
  subject,
  examId,
  percentage,
  state,
  teacherId,
  verifiedId,
  pendingId,
) {
  const key = { LEARNER_ID: learnerId, SUBJECT_ID: subject.SUBJECT_ID, EXAM_TYPE_ID: examId };
  const existing = (await db.list('LEARNER_RESULTS', key))[0];
  if (existing) return existing; // preserve any workflow edits made after the initial seed
  const verified = state === 'verified';
  return db.insert('LEARNER_RESULTS', {
    ...key,
    PERCENTAGE: percentage,
    VERIFICATION_STATUS_ID: verified ? verifiedId : pendingId,
    VERIFIED_BY_TEACHER_ID: verified ? teacherId : null,
    VERIFIED_DATE: verified ? TODAY() : null,
  });
}

async function ensureEnrollment(db, learnerId, subjectId) {
  const matches = await db.list('LEARNER_SUBJECTS', {
    LEARNER_ID: learnerId,
    SUBJECT_ID: subjectId,
  });
  if (!matches.length)
    await db.insert('LEARNER_SUBJECTS', {
      LEARNER_ID: learnerId,
      SUBJECT_ID: subjectId,
      ENROLLMENT_DATE: TODAY(),
    });
  if (matches.length > 1)
    throw new Error(
      `Duplicate sample learner-subject enrolment for learner ${learnerId}, subject ${subjectId}.`,
    );
}

async function ensureDocument(
  db,
  personId,
  type,
  state,
  teacherId,
  verifiedId,
  pendingId,
  filename,
) {
  const matches = (
    await db.list('DOCUMENTS', { PERSON_ID: personId, DOCUMENT_TYPE_ID: type.DOCUMENT_TYPE_ID })
  ).filter((d) => String(d.FILE_NAME || '').startsWith('sample-'));
  if (matches.length > 1)
    throw new Error(
      `Duplicate synthetic sample documents for person ${personId}, type ${type.DOCUMENT_TYPE_ID}.`,
    );
  if (matches.length === 1) return matches[0];
  const verified = state === 'verified';
  const title = type.DOCUMENT_TYPE_NAME;
  const blob = makeSamplePdf(title, [
    `sample learner PERSON_ID: ${personId}`,
    `Document type ID: ${type.DOCUMENT_TYPE_ID}`,
    'Replace with genuine evidence only in a real admissions workflow.',
  ]);
  return db.insert('DOCUMENTS', {
    DOCUMENT_NAME: title,
    DOCUMENT_TYPE_ID: type.DOCUMENT_TYPE_ID,
    UPLOAD_DATE: TODAY(),
    PERSON_ID: personId,
    FILE_NAME: filename,
    MIME_TYPE: 'application/pdf',
    DOCUMENT_BLOB: blob,
    VERIFICATION_STATUS_ID: verified ? verifiedId : pendingId,
    VERIFIED_BY_TEACHER_ID: verified ? teacherId : null,
    VERIFIED_DATE: verified ? TODAY() : null,
  });
}

async function ensureApplication(
  db,
  learnerId,
  offeringId,
  studyModeId,
  initialStatus,
  teacherId,
  repId,
  allStatuses,
  allActions,
) {
  const existing = await db.list('APPLICATIONS', {
    LEARNER_ID: learnerId,
    UNI_QUAL_ID: offeringId,
    ACADEMIC_YEAR: 2028,
  });
  if (existing.length > 1)
    throw new Error(`Multiple 2028 sample applications found for learner ${learnerId}.`);
  let app = existing[0];
  if (!app) {
    app = await db.insert('APPLICATIONS', {
      APPLICATION_DATE: TODAY(),
      ACADEMIC_YEAR: 2028,
      STUDY_MODE_ID: studyModeId,
      UNI_QUAL_ID: offeringId,
      LEARNER_ID: learnerId,
      TEACHER_ID: [
        'Screened by Career Teacher',
        'Provisionally Accepted',
        'Final Matric Verified',
        'Admitted',
      ].includes(initialStatus)
        ? teacherId
        : null,
      STATUS_ID: allStatuses.find((s) => s.STATUS_NAME === initialStatus).STATUS_ID,
      REVIEWED_BY_REP_ID: ['Provisionally Accepted', 'Final Matric Verified', 'Admitted'].includes(
        initialStatus,
      )
        ? repId
        : null,
      REVIEW_DATE: ['Provisionally Accepted', 'Final Matric Verified', 'Admitted'].includes(
        initialStatus,
      )
        ? TODAY()
        : null,
      REVIEW_NOTES:
        initialStatus === 'Submitted'
          ? null
          : 'Workflow record for application-stage review; not a real admissions decision.',
    });
  }
  const currentStatus =
    allStatuses.find((s) => sameId(s.STATUS_ID, app.STATUS_ID))?.STATUS_NAME || initialStatus;
  const stages = {
    Submitted: ['Submitted'],
    'Screened by Career Teacher': ['Submitted', 'Screened by Career Teacher'],
    'Provisionally Accepted': ['Submitted', 'Screened by Career Teacher', 'Provisionally Accepted'],
    'Final Matric Verified': [
      'Submitted',
      'Screened by Career Teacher',
      'Provisionally Accepted',
      'Final Matric Verified',
    ],
    Admitted: [
      'Submitted',
      'Screened by Career Teacher',
      'Provisionally Accepted',
      'Final Matric Verified',
      'Admitted',
    ],
  };
  // Keep an existing workflow's current status intact; seed history only up through its existing state.
  const historyStages = stages[currentStatus] || stages[initialStatus];
  for (const actionName of historyStages) {
    const action = allActions.find((a) => a.ACTION_NAME === actionName);
    if (!action) throw new Error(`Required action lookup "${actionName}" is missing.`);
    const has = (
      await db.list('APPLICATION_PROCESSES', { APPLICATION_ID: app.APPLICATION_ID })
    ).some((r) => sameId(r.ACTION_ID, action.ACTION_ID));
    if (!has)
      await db.insert('APPLICATION_PROCESSES', {
        APPLICATION_ID: app.APPLICATION_ID,
        ACTION_ID: action.ACTION_ID,
        ACTION_DATE: TODAY(),
      });
  }
  return app;
}

/**
 * Idempotently adds synthetic sample identities and application rows; it never deletes or merges records.
 * Caller must explicitly authorize the operation and use a non-production SQL Server database.
 */
export async function seedSampleData(store, { password = SAMPLE_PASSWORD } = {}) {
  if (store.mode !== 'sqlserver' && store.mode !== 'local')
    throw new Error('Unsupported data store.');
  const hash = await passwordHash(password);
  return store.tx(async (db) => {
    const province = await ensureLookup(db, 'PROVINCES', 'PROVINCE_NAME', 'Gauteng');
    const city = await ensureLookup(db, 'CITIES', 'CITY_NAME', 'Johannesburg', {PROVINCE_ID:province.PROVINCE_ID});
    const school = await oneOrCreate(db, 'SCHOOLS', 'EMIS_NUMBER', 'VV-WF-2028-001', {
      SCHOOL_NAME: SAMPLE_SCHOOL_NAME,
      CITY_ID: city.CITY_ID,
      PROVINCE_ID: province.PROVINCE_ID,
    });
    if (school.SCHOOL_NAME !== SAMPLE_SCHOOL_NAME)
      throw new Error('EMIS VV-WF-2028-001 is already used by a different school.');
    const university = await oneOrCreate(
      db,
      'UNIVERSITIES',
      'UNIVERSITY_NAME',
      SAMPLE_UNIVERSITY_NAME,
      {
        WEBSITE: 'https://mhlabeni-university.example',
        PROVINCE_ID: province.PROVINCE_ID,
      },
    );
    const program = await oneOrCreate(db, 'PROGRAMS', 'PROGRAM_NAME', 'Information Technology');
    const qualification = await oneOrCreate(
      db,
      'QUALIFICATIONS',
      'QUAL_NAME',
      SAMPLE_OFFERING_NAME,
      { PROGRAM_ID: program.PROGRAM_ID },
    );
    if (!sameId(qualification.PROGRAM_ID, program.PROGRAM_ID))
      throw new Error('The sample qualification is linked to an unexpected programme.');
    let offeringRows = (await db.list('UNI_QUALIFICATIONS')).filter(
      (r) =>
        sameId(r.UNIVERSITY_ID, university.UNIVERSITY_ID) &&
        sameId(r.QUAL_ID, qualification.QUAL_ID),
    );
    if (offeringRows.length > 1) throw new Error('Duplicate sample university offerings found.');
    let offering = offeringRows[0];
    if (!offering)
      offering = await db.insert('UNI_QUALIFICATIONS', {
        UNIVERSITY_ID: university.UNIVERSITY_ID,
        QUAL_ID: qualification.QUAL_ID,
        APPLICATION_CLOSING_DATE:
          store.mode === 'sqlserver' ? new Date('2028-10-31T00:00:00.000Z') : '2028-10-31',
      });
    const mainCampus = await ensureLookup(db, 'ADDRESS_TYPES', 'ADDRESS_TYPE_NAME', 'Main Campus');
    const universityAddress = (await db.list('UNIVERSITY_ADDRESSES')).find(
      (a) =>
        sameId(a.UNIVERSITY_ID, university.UNIVERSITY_ID) &&
        String(a.STREET_NAME || '') === '1 University Way',
    );
    if (!universityAddress)
      await db.insert('UNIVERSITY_ADDRESSES', {
        UNIVERSITY_ID: university.UNIVERSITY_ID,
        ADDRESS_TYPE_ID: mainCampus.ADDRESS_TYPE_ID,
        STREET_NAME: '1 University Way',
        CITY_ID: city.CITY_ID,
      });

    const statusesToAdd = [
      ['Submitted', 0],
      ['Screened by Career Teacher', 0],
      ['Provisionally Accepted', 0],
      ['Final Matric Verified', 1],
      ['Admitted', 1],
      ['Offer Revoked', 1],
      ['Rejected', 0],
    ];
    for (const [name, finalResults] of statusesToAdd)
      await ensureLookup(db, 'APPLICATION_STATUSES', 'STATUS_NAME', name, {
        USES_FINAL_RESULTS: finalResults,
      });
    for (const name of [
      'Submitted',
      'Screened by Career Teacher',
      'Provisionally Accepted',
      'Final Matric Verified',
      'Admitted',
      'Offer Revoked',
      'Rejected',
    ])
      await ensureLookup(db, 'ACTIONS', 'ACTION_NAME', name);
    for (const name of ['Pending', 'Verified', 'Rejected'])
      await ensureLookup(db, 'VERIFICATION_STATUSES', 'VERIFICATION_STATUS_NAME', name);
    const grade11 = await ensureLookup(db, 'EXAM_TYPES', 'EXAM_TYPE_NAME', 'Grade 11 Final');
    const grade12 = await ensureLookup(db, 'EXAM_TYPES', 'EXAM_TYPE_NAME', 'Grade 12 Final (NSC)');
    const fullTime = await ensureLookup(db, 'STUDY_MODES', 'STUDY_MODE_NAME', 'Full-time');
    const ensureDocumentType = async (name, fields) => {
      const type = await ensureLookup(db, 'DOCUMENT_TYPES', 'DOCUMENT_TYPE_NAME', name, fields);
      for (const [key, expected] of Object.entries(fields)) {
        if (Number(type[key]) !== Number(expected))
          throw new Error(
            `Existing DOCUMENT_TYPES row for "${name}" has ${key}=${type[key]}, expected ${expected}. Review the existing document policy before seeding; no existing row was changed.`,
          );
      }
      return type;
    };
    const baseRequiredTypes = [
      await ensureDocumentType('Grade 11 Final Report', {
        IS_MANDATORY: 1,
        IS_LOCKED_UNTIL_FINAL: 0,
      }),
      await ensureDocumentType('Certified Copy of Identity Document', {
        IS_MANDATORY: 1,
        IS_LOCKED_UNTIL_FINAL: 0,
      }),
    ];
    // Include any additional mandatory documents in this installation, except final-stage types locked until provisional acceptance.
    const allDocumentTypes = await db.list('DOCUMENT_TYPES');
    const requiredTypeById = new Map(
      baseRequiredTypes.map((type) => [String(type.DOCUMENT_TYPE_ID), type]),
    );
    for (const type of allDocumentTypes) {
      if (Boolean(type.IS_MANDATORY) && !Boolean(type.IS_LOCKED_UNTIL_FINAL))
        requiredTypeById.set(String(type.DOCUMENT_TYPE_ID), type);
    }
    const requiredTypes = [...requiredTypeById.values()];
    const finalCertificate = await ensureDocumentType('Final NSC Certificate', {
      IS_MANDATORY: 0,
      IS_LOCKED_UNTIL_FINAL: 1,
    });
    const pending = (
      await db.list('VERIFICATION_STATUSES', { VERIFICATION_STATUS_NAME: 'Pending' })
    )[0];
    const verified = (
      await db.list('VERIFICATION_STATUSES', { VERIFICATION_STATUS_NAME: 'Verified' })
    )[0];
    const rejected = (
      await db.list('VERIFICATION_STATUSES', { VERIFICATION_STATUS_NAME: 'Rejected' })
    )[0];
    if (!pending || !verified || !rejected)
      throw new Error('Verification status reference data is incomplete.');
    const subjects = new Map();
    const categoryByCode = {
      ENGHL: 'HOME_LANGUAGE',
      ZULFAL: 'FIRST_ADDITIONAL_LANGUAGE',
      MATH: 'MATHEMATICS',
      LFSC: 'ELECTIVE',
      GEOG: 'ELECTIVE',
      PHSC: 'ELECTIVE',
      LO: 'LIFE_ORIENTATION',
    };
    for (const [code, category] of Object.entries(categoryByCode))
      subjects.set(code, await ensureSubject(db, code, category));

    const policy = {
      intake: 2028,
      status: 'verified',
      source: 'https://mhlabeni-university.example/programmes/application-development',
      minScore: 18,
      finalMinScore: 18,
      minEnglish: 50,
      minMath: 16,
      requiredCodes: [],
      subjectMinimums: {},
      scoring: null,
      subjectGroups: [],
      requiredDocumentIds: requiredTypes.map((t) => Number(t.DOCUMENT_TYPE_ID)),
      openingDate: '2026-10-26',
      closingTime: '23:59',
      active: true,
      scoringMethod: 'standard-aps-6',
      notes:
        'Sample eligibility profile for workflow testing. Confirm current entry requirements with the institution before relying on this information.',
    };
    const existingPolicyRows = await db.list('security.Policies', {
      UNI_QUAL_ID: offering.UNI_QUAL_ID,
    });
    if (existingPolicyRows.length > 1)
      throw new Error(
        'Duplicate policy rows exist for the sample offering. Resolve them before seeding.',
      );
    if (!existingPolicyRows.length) {
      await db.insert('security.Policies', {
        UNI_QUAL_ID: offering.UNI_QUAL_ID,
        PAYLOAD: JSON.stringify(policy),
      });
    } else {
      let existingPayload;
      try {
        existingPayload = JSON.parse(existingPolicyRows[0].PAYLOAD);
      } catch {
        throw new Error(
          'The existing policy for the sample offering is not valid JSON; refusing to replace it.',
        );
      }
      if (
        !String(existingPayload.notes || '').includes(
          'Sample eligibility profile for workflow testing.',
        ) ||
        !String(existingPayload.source || '').includes('.example/')
      )
        throw new Error(
          'A non-sample policy exists for the sample offering. Refusing to overwrite existing programme requirements.',
        );
      // Preserve any edits made to the sample policy after the initial seed.
    }
    const legacyReqRows = await db.list('QUALIFICATION_REQUIREMENTS', {
      UNI_QUAL_ID: offering.UNI_QUAL_ID,
    });
    if (legacyReqRows.length > 1)
      throw new Error(
        'Duplicate legacy requirements exist for the sample offering. Resolve them before seeding.',
      );
    const legacyFields = {
      MIN_APS_SCORE: 18,
      MIN_MATH_SCORE: 16,
      MIN_ENG_SCORE: 50,
      NOTES: policy.notes,
    };
    if (!legacyReqRows.length) {
      await db.insert('QUALIFICATION_REQUIREMENTS', {
        UNI_QUAL_ID: offering.UNI_QUAL_ID,
        ...legacyFields,
      });
    } else if (
      !String(legacyReqRows[0].NOTES || '').includes(
        'Sample eligibility profile for workflow testing.',
      )
    ) {
      throw new Error(
        'Non-sample legacy requirements exist for the sample offering. Refusing to overwrite them.',
      );
    }

    const people = new Map();
    for (const spec of SAMPLE_USERS) {
      const person = await ensurePerson(db, spec, school.SCHOOL_ID, university.UNIVERSITY_ID);
      people.set(spec.key, person);
      await ensureAccount(db, person, spec.email, hash);
      const existingSeedAudit = (
        await db.list('security.Audit', { PERSON_ID: person.PERSON_ID, EVENT: 'sample.seed' })
      )[0];
      if (!existingSeedAudit)
        await db.insert('security.Audit', {
          AUDIT_ID: randomUUID(),
          PERSON_ID: person.PERSON_ID,
          EVENT: 'sample.seed',
          DETAIL: JSON.stringify({
            purpose: 'Workflow record initialization',
            email: spec.email,
            role: spec.role,
          }),
          CREATED_AT: new Date().toISOString(),
        });
    }
    const roles = new Map();
    roles.set(
      'teacher',
      await ensureSingleRole(db, people.get('teacher'), 'teacher', {
        SCHOOL_ID: school.SCHOOL_ID,
        DEPARTMENT: 'Career Guidance',
        DESIGNATION: 'Career Guidance Teacher',
      }),
    );
    roles.set(
      'representative',
      await ensureSingleRole(db, people.get('representative'), 'representative', {
        UNIVERSITY_ID: university.UNIVERSITY_ID,
      }),
    );
    roles.set(
      'admin',
      await ensureSingleRole(db, people.get('admin'), 'admin', { SCHOOL_ID: null }),
    );
    for (const spec of SAMPLE_USERS.filter((u) => u.role === 'learner'))
      roles.set(
        spec.key,
        await ensureSingleRole(db, people.get(spec.key), 'learner', {
          SCHOOL_ID: school.SCHOOL_ID,
        }),
      );
    const teacherId = roles.get('teacher').PERSON_ID;
    const repId = roles.get('representative').PERSON_ID;
    const statusRows = await db.list('APPLICATION_STATUSES');
    const actionRows = await db.list('ACTIONS');

    // Add grade 11 data for all synthetic learners. Existing result edits are preserved.
    for (const spec of SAMPLE_USERS.filter((u) => u.role === 'learner')) {
      const learner = roles.get(spec.key);
      for (const [code, mark] of GRADE11) {
        const subject = subjects.get(code);
        await ensureResult(
          db,
          learner.PERSON_ID,
          subject,
          grade11.EXAM_TYPE_ID,
          mark,
          spec.resultStage,
          teacherId,
          verified.VERIFICATION_STATUS_ID,
          pending.VERIFICATION_STATUS_ID,
        );
        await ensureEnrollment(db, learner.PERSON_ID, subject.SUBJECT_ID);
      }
      if (spec.includeFinalResults)
        for (const [code, mark] of GRADE12) {
          const subject = subjects.get(code);
          await ensureResult(
            db,
            learner.PERSON_ID,
            subject,
            grade12.EXAM_TYPE_ID,
            mark,
            'verified',
            teacherId,
            verified.VERIFICATION_STATUS_ID,
            pending.VERIFICATION_STATUS_ID,
          );
        }
    }

    // Seed application states before final certificates so the database's final-document lock trigger sees the correct stage.
    const initialApplications = [];
    for (const spec of SAMPLE_USERS.filter((u) => u.role === 'learner' && u.applicationStage)) {
      const learner = roles.get(spec.key);
      initialApplications.push({
        spec,
        app: await ensureApplication(
          db,
          learner.PERSON_ID,
          offering.UNI_QUAL_ID,
          fullTime.STUDY_MODE_ID,
          spec.applicationStage,
          teacherId,
          repId,
          statusRows,
          actionRows,
        ),
      });
    }

    for (const spec of SAMPLE_USERS.filter((u) => u.role === 'learner')) {
      const person = people.get(spec.key);
      const expectedDocuments = requiredTypes;
      for (let i = 0; i < expectedDocuments.length; i++) {
        await ensureDocument(
          db,
          person.PERSON_ID,
          expectedDocuments[i],
          spec.documentStage || 'pending',
          teacherId,
          verified.VERIFICATION_STATUS_ID,
          pending.VERIFICATION_STATUS_ID,
          `sample-${String(expectedDocuments[i].DOCUMENT_TYPE_NAME)
            .replace(/[^a-zA-Z0-9]+/g, '-')
            .replace(/^-|-$/g, '')
            .slice(0, 160)}.pdf`,
        );
      }
      if (spec.includeFinalResults)
        await ensureDocument(
          db,
          person.PERSON_ID,
          finalCertificate,
          'verified',
          teacherId,
          verified.VERIFICATION_STATUS_ID,
          pending.VERIFICATION_STATUS_ID,
          'sample-Final-NSC-Certificate.pdf',
        );
    }

    // Add a synthetic prospectus file for the representative portal.
    const prospectus = (await db.list('PROSPECTUSES')).find(
      (p) =>
        sameId(p.UNIVERSITY_ID, university.UNIVERSITY_ID) &&
        p.PROSPECTUS_FILENAME === 'sample-Training-Prospectus.pdf',
    );
    if (!prospectus)
      await db.insert('PROSPECTUSES', {
        UNIVERSITY_ID: university.UNIVERSITY_ID,
        PROSPECTUS_FILE: makeSamplePdf('Training Prospectus', [
          'Diploma in Application Development - 2028 intake. Sample copy; verify details with the institution.',
        ]),
        PROSPECTUS_FILENAME: 'sample-Training-Prospectus.pdf',
        PROSPECTUS_MIMETYPE: 'application/pdf',
        PROSPECTUS_DATE: TODAY(),
      });

    return {
      mode: store.mode,
      schoolId: school.SCHOOL_ID,
      universityId: university.UNIVERSITY_ID,
      offeringId: offering.UNI_QUAL_ID,
      accounts: SAMPLE_USERS.map(({ key, email, role }) => ({
        key,
        email,
        role,
        personId: people.get(key).PERSON_ID,
        recordId:
          roles.get(key)?.PERSON_ID ||
          null,
      })),
      seededApplications: initialApplications.map(({ spec, app }) => ({
        learner: spec.key,
        applicationId: app.APPLICATION_ID,
        initialState: spec.applicationStage,
      })),
      readyLearner: 'thabo.mokoena@varsityvault.test',
      password,
      disclaimer:
        'Fictional workflow records and documents are provided for local testing. Do not use them to make real admissions decisions.',
    };
  });
}
