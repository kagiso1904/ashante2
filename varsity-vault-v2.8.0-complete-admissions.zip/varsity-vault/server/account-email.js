import { digest, token } from './security.js';
import { accountLink } from './mailer.js';

const timestamp = () => new Date().toISOString();

export async function markEmailPending(db, personId) {
  const row = (await db.list('security.EmailVerifications', { PERSON_ID: personId }))[0];
  if (row)
    await db.update('security.EmailVerifications', { PERSON_ID: personId }, { VERIFIED_AT: null });
  else await db.insert('security.EmailVerifications', { PERSON_ID: personId, VERIFIED_AT: null });
}

export async function issueAccountToken(db, personId, purpose, minutes) {
  for (const old of await db.list('security.AccountTokens', {
    PERSON_ID: personId,
    PURPOSE: purpose,
  }))
    await db.remove('security.AccountTokens', { TOKEN_HASH: old.TOKEN_HASH });
  const raw = token();
  await db.insert('security.AccountTokens', {
    TOKEN_HASH: digest(raw),
    PERSON_ID: personId,
    PURPOSE: purpose,
    EXPIRES: new Date(Date.now() + minutes * 60000).toISOString(),
    CREATED_AT: timestamp(),
  });
  return raw;
}

export async function emailVerificationMessage(db, personId, email) {
  await markEmailPending(db, personId);
  const raw = await issueAccountToken(db, personId, 'email-verification', 60);
  return {
    to: email,
    subject: 'Verify your Varsity Vault email',
    text: `Verify this email address within 60 minutes by opening this link:\n\n${accountLink('/verify-email.html', raw)}\n\nIf you did not expect this message, contact your institution administrator.`,
  };
}

export async function accountInvitationMessage(db, personId, email) {
  await markEmailPending(db, personId);
  const raw = await issueAccountToken(db, personId, 'account-invitation', 1440);
  return {
    to: email,
    subject: 'Set up your Varsity Vault account',
    text: `An account has been created for you. Set your password and verify this email within 24 hours:\n\n${accountLink('/reset-password.html', raw)}\n\nIf you were not expecting this, contact your institution administrator.`,
  };
}
