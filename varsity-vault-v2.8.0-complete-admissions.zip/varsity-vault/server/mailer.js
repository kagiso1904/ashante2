import nodemailer from 'nodemailer';

let transporter;

export function emailDeliveryReady() {
  const mode = String(process.env.EMAIL_MODE || '').toLowerCase();
  if (!String(process.env.PUBLIC_APP_URL || '').trim()) return false;
  try {
    const base = new URL(process.env.PUBLIC_APP_URL);
    if (process.env.NODE_ENV === 'production' && base.protocol !== 'https:') return false;
  } catch {
    return false;
  }
  if (mode === 'console') return process.env.NODE_ENV !== 'production';
  if (mode !== 'smtp') return false;
  const port = Number(process.env.SMTP_PORT || 587);
  const user = String(process.env.SMTP_USER || '').trim(),
    password = String(process.env.SMTP_PASSWORD || '');
  const authenticationComplete = Boolean(user) === Boolean(password);
  return Boolean(
    String(process.env.SMTP_HOST || '').trim() &&
    String(process.env.SMTP_FROM || '').trim() &&
    Number.isInteger(port) &&
    port > 0 &&
    port <= 65535 &&
    authenticationComplete,
  );
}

export function applicationUrl(path) {
  const configured = String(process.env.PUBLIC_APP_URL || '').trim();
  if (!configured) throw new Error('PUBLIC_APP_URL is required for account email links.');
  const url = new URL(configured);
  if (process.env.NODE_ENV === 'production' && url.protocol !== 'https:') {
    throw new Error('PUBLIC_APP_URL must use HTTPS in production.');
  }
  url.pathname = path.startsWith('/') ? path : `/${path}`;
  url.search = '';
  url.hash = '';
  return url.toString();
}

export function accountLink(path, token) {
  const url = new URL(applicationUrl(path));
  url.searchParams.set('token', token);
  return url.toString();
}

function smtpTransport() {
  if (transporter) return transporter;
  const host = String(process.env.SMTP_HOST || '').trim();
  const from = String(process.env.SMTP_FROM || '').trim();
  const port = Number(process.env.SMTP_PORT || 587);
  if (!host || !from || !Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error('Configure SMTP_HOST, SMTP_PORT and SMTP_FROM before sending account email.');
  }
  const secure = String(process.env.SMTP_SECURE || '').toLowerCase() === 'true';
  const user = String(process.env.SMTP_USER || '');
  const pass = String(process.env.SMTP_PASSWORD || '');
  transporter = nodemailer.createTransport(
    {
      host,
      port,
      secure,
      requireTLS: !secure,
      ...(user ? { auth: { user, pass } } : {}),
      connectionTimeout: 10000,
      greetingTimeout: 10000,
      socketTimeout: 15000,
    },
    { from },
  );
  return transporter;
}

export async function sendAccountEmail({ to, subject, text }) {
  const mode = String(process.env.EMAIL_MODE || '').toLowerCase();
  if (mode === 'console') {
    if (process.env.NODE_ENV === 'production') {
      throw new Error('Console email delivery is restricted to local development.');
    }
    console.info(`Local account email for ${to}:\n${subject}\n${text}`);
    return;
  }
  if (mode !== 'smtp') throw new Error('Set EMAIL_MODE=smtp to enable account email delivery.');
  await smtpTransport().sendMail({ to, subject, text });
}
