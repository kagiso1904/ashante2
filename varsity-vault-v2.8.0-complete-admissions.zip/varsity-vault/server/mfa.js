import {
  createCipheriv,
  createDecipheriv,
  createHmac,
  randomBytes,
  timingSafeEqual,
} from 'node:crypto';
import { digest, token } from './security.js';

const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

function base32Encode(bytes) {
  let bits = 0,
    value = 0,
    output = '';
  for (const byte of bytes) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      output += alphabet[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits) output += alphabet[(value << (5 - bits)) & 31];
  return output;
}

function base32Decode(input) {
  let bits = 0,
    value = 0;
  const out = [];
  for (const char of input.toUpperCase().replace(/=+$/, '')) {
    const index = alphabet.indexOf(char);
    if (index < 0) throw new Error('Invalid TOTP secret.');
    value = (value << 5) | index;
    bits += 5;
    if (bits >= 8) {
      out.push((value >>> (bits - 8)) & 255);
      bits -= 8;
    }
  }
  return Buffer.from(out);
}

export function encryptionKey(value = process.env.SECURITY_ENCRYPTION_KEY) {
  if (!/^[a-f0-9]{64}$/i.test(String(value || ''))) {
    throw new Error(
      'Set SECURITY_ENCRYPTION_KEY to 64 hexadecimal characters before enabling administrator MFA.',
    );
  }
  return Buffer.from(value, 'hex');
}

export function encryptSecret(secret, key) {
  const iv = randomBytes(12),
    cipher = createCipheriv('aes-256-gcm', encryptionKey(key), iv);
  const encrypted = Buffer.concat([cipher.update(secret, 'utf8'), cipher.final()]);
  return [iv.toString('hex'), cipher.getAuthTag().toString('hex'), encrypted.toString('hex')].join(
    ':',
  );
}

export function decryptSecret(payload, key) {
  const [ivText, tagText, dataText] = String(payload || '').split(':');
  if (!ivText || !tagText || !dataText) throw new Error('Administrator MFA secret is invalid.');
  const decipher = createDecipheriv('aes-256-gcm', encryptionKey(key), Buffer.from(ivText, 'hex'));
  decipher.setAuthTag(Buffer.from(tagText, 'hex'));
  return Buffer.concat([decipher.update(Buffer.from(dataText, 'hex')), decipher.final()]).toString(
    'utf8',
  );
}

export const newTotpSecret = () => base32Encode(randomBytes(20));

export function provisioningUri(secret, account) {
  const label = encodeURIComponent(`Varsity Vault:${account}`);
  return `otpauth://totp/${label}?secret=${secret}&issuer=Varsity%20Vault&algorithm=SHA1&digits=6&period=30`;
}

function codeAt(secret, step) {
  const counter = Buffer.alloc(8);
  counter.writeBigUInt64BE(BigInt(step));
  const hmac = createHmac('sha1', base32Decode(secret)).update(counter).digest();
  const offset = hmac[hmac.length - 1] & 15;
  const binary =
    ((hmac[offset] & 127) << 24) |
    ((hmac[offset + 1] & 255) << 16) |
    ((hmac[offset + 2] & 255) << 8) |
    (hmac[offset + 3] & 255);
  return String(binary % 1000000).padStart(6, '0');
}

export function verifyTotp(secret, supplied, lastStep = -1, timestamp = Date.now()) {
  if (!/^\d{6}$/.test(String(supplied || ''))) return null;
  const current = Math.floor(timestamp / 30000);
  for (const step of [current - 1, current, current + 1]) {
    if (step <= Number(lastStep ?? -1)) continue;
    const expected = Buffer.from(codeAt(secret, step));
    const actual = Buffer.from(String(supplied));
    if (expected.length === actual.length && timingSafeEqual(expected, actual)) return step;
  }
  return null;
}

export function currentTotp(secret, timestamp = Date.now()) {
  return codeAt(secret, Math.floor(timestamp / 30000));
}

export function makeRecoveryCodes(count = 10) {
  const codes = Array.from({ length: count }, () =>
    token()
      .slice(0, 20)
      .toUpperCase()
      .match(/.{1,5}/g)
      .join('-'),
  );
  return { codes, hashes: codes.map((code) => digest(code.replaceAll('-', '').toLowerCase())) };
}
