import { SAMPLE_USERS, makeSamplePdf } from './sample-fixture.js';
import { audit } from './security.js';
import { isValidSouthAfricanIdNumber, normalizeIdentity as norm, sameId } from './identity.js';
const oldEmails = [
  'demo.learner@example.invalid',
  'demo.submitted@example.invalid',
  'demo.screened@example.invalid',
  'demo.provisional@example.invalid',
  'demo.admitted@example.invalid',
  'demo.teacher@example.invalid',
  'demo.representative@example.invalid',
  'demo.admin@example.invalid',
];
const oldNames = [
  ['Anele', 'Mabaso'],
  ['Ayanda', 'Maseko'],
  ['Buhle', 'Mahlangu'],
  ['Lwazi', 'Mthethwa'],
  ['Nokuthula', 'Dube'],
  ['Nolwazi', 'Mkhize'],
  ['Themba', 'Mokoena'],
  ['Vuyani', 'Mafuna'],
];
const phones = [
  '0765543218',
  '0736284915',
  '0784126930',
  '0729361845',
  '0795612384',
  '0834276195',
  '0713958264',
  '0826481357',
];
const legacyIds = new Set([
  '9902159998085',
  '0207084998088',
  '0105234997085',
  '9808109997087',
  '0301044996082',
]);
const idFor = (index, offset) => {
  const prefix =
    ['080716', '080224', '071112', '080405', '080915', '850918', '790502', '880623'][index] +
    String(([0, 3, 6, 7].includes(index) ? 6000 : 2000) + offset + index * 137).padStart(4, '0') +
    '08';
  let sum = 0;
  for (let n = 0; n < 12; n++) {
    let digit = Number(prefix[11 - n]);
    if (n % 2 === 0) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    sum += digit;
  }
  return prefix + String((10 - (sum % 10)) % 10);
};
export async function personaliseRecords(store) {
  return store.tx(async (db) => {
    const people = await db.list('PERSONS'),
      accounts = await db.list('security.Accounts'),
      events = await db.list('security.Audit');
    const owned = (id) =>
      events.some(
        (e) =>
          sameId(e.PERSON_ID, id) &&
          ['demo.seed', 'sample.seed', 'records.personalised'].includes(e.EVENT),
      );
    const summary = [];
    for (const person of people) {
      if (!owned(person.PERSON_ID)) continue;
      const oldIndex = oldEmails.indexOf(norm(person.EMAIL));
      const sampleIndex = SAMPLE_USERS.findIndex((s) => norm(s.email) === norm(person.EMAIL));
      if (oldIndex < 0 && sampleIndex < 0) continue;
      const index = oldIndex >= 0 ? oldIndex : sampleIndex,
        spec = SAMPLE_USERS[index];
      const [firstName, lastName] =
        oldIndex >= 0 ? oldNames[index] : [person.FIRST_NAME, person.LAST_NAME];
      const email =
        oldIndex >= 0 ? (firstName + lastName).toLowerCase() + '@varsityvault.test' : spec.email;
      if (
        people.some(
          (p) =>
            !sameId(p.PERSON_ID, person.PERSON_ID) &&
            [p.EMAIL, p.USERNAME].some((v) => norm(v) === email),
        ) ||
        accounts.some((a) => !sameId(a.PERSON_ID, person.PERSON_ID) && norm(a.USERNAME) === email)
      )
        throw Error(
          'A proposed simulated email already belongs to another person. No records were merged.',
        );
      const patch = {
        FIRST_NAME: firstName,
        LAST_NAME: lastName,
        EMAIL: email,
        USERNAME: email,
        PHONE_NUMBER:
          !person.PHONE_NUMBER || /^08299999/.test(person.PHONE_NUMBER)
            ? oldIndex >= 0
              ? phones[index].slice(0, 7) +
                String((Number(phones[index].slice(7)) + 400) % 1000).padStart(3, '0')
              : phones[index]
            : person.PHONE_NUMBER,
      };
      if (!person.SA_ID_NUMBER || legacyIds.has(person.SA_ID_NUMBER)) {
        const proposed = idFor(index, oldIndex >= 0 ? 800 : 0);
        if (!isValidSouthAfricanIdNumber(proposed))
          throw Error('Generated identity validation failed.');
        if (
          people.some((p) => !sameId(p.PERSON_ID, person.PERSON_ID) && p.SA_ID_NUMBER === proposed)
        )
          throw Error('A proposed simulated ID is already in use.');
        patch.SA_ID_NUMBER = proposed;
      }
      const changed = Object.entries(patch).some(([k, v]) => person[k] !== v);
      if (changed) {
        await db.update('PERSONS', { PERSON_ID: person.PERSON_ID }, patch);
        for (const a of accounts.filter((a) => sameId(a.PERSON_ID, person.PERSON_ID)))
          await db.update('security.Accounts', { ACCOUNT_ID: a.ACCOUNT_ID }, { USERNAME: email });
        for (const session of await db.list('security.Sessions', { PERSON_ID: person.PERSON_ID }))
          await db.remove('security.Sessions', { TOKEN_HASH: session.TOKEN_HASH });
        await audit(db, person.PERSON_ID, 'records.personalised', {
          personId: person.PERSON_ID,
          oldLogin: person.EMAIL,
          newLogin: email,
        });
      }
      for (const doc of await db.list('DOCUMENTS', { PERSON_ID: person.PERSON_ID })) {
        if (
          /^DEMO-/i.test(doc.FILE_NAME || '') &&
          Buffer.from(doc.DOCUMENT_BLOB || []).includes(
            Buffer.from('NOT AN OFFICIAL STUDENT DOCUMENT'),
          )
        ) {
          await db.update(
            'DOCUMENTS',
            { DOCUMENT_ID: doc.DOCUMENT_ID },
            {
              FILE_NAME:
                (firstName + '-' + lastName + '-' + doc.DOCUMENT_NAME).replace(
                  /[^a-zA-Z0-9-]/g,
                  '-',
                ) + '.pdf',
              DOCUMENT_BLOB: makeSamplePdf(doc.DOCUMENT_NAME, [
                firstName + ' ' + lastName,
                'Simulated academic record',
              ]),
            },
          );
        }
      }
      if (!(await db.list('PERSON_ADDRESSES', { PERSON_ID: person.PERSON_ID })).length) {
        const type =
          (await db.list('ADDRESS_TYPES')).find((r) => r.ADDRESS_TYPE_NAME === 'Home') ||
          (await db.insert('ADDRESS_TYPES', { ADDRESS_TYPE_NAME: 'Home' }));
        const role =
          (await db.list('LEARNERS', { PERSON_ID: person.PERSON_ID }))[0] ||
          (await db.list('TEACHERS', { PERSON_ID: person.PERSON_ID }))[0];
        const school = role ? (await db.list('SCHOOLS', { SCHOOL_ID: role.SCHOOL_ID }))[0] : null;
        const city = school?.CITY_ID || (await db.list('CITIES'))[0]?.CITY_ID;
        if (city)
          await db.insert('PERSON_ADDRESSES', {
            PERSON_ID: person.PERSON_ID,
            ADDRESS_TYPE_ID: type.ADDRESS_TYPE_ID,
            STREET_NAME:
              12 +
              index * 7 +
              (oldIndex >= 0 ? 60 : 0) +
              ' ' +
              [
                'Oxford Street',
                'Main Road',
                'Park Avenue',
                'Church Street',
                'Victoria Road',
                'Station Road',
                'Hill Street',
                'King Street',
              ][index],
            CITY_ID: city,
          });
      }
      summary.push({ name: firstName + ' ' + lastName, email, updated: changed });
    }
    // Rename only the reserved institutions created by the earlier workflow loader.
    if (events.some((e) => e.EVENT === 'demo.seed')) {
      for (const school of await db.list('SCHOOLS'))
        if (school.SCHOOL_NAME === 'DEMO - Varsity Vault Secondary School')
          await db.update(
            'SCHOOLS',
            { SCHOOL_ID: school.SCHOOL_ID },
            { SCHOOL_NAME: 'Khanyisa Secondary School' },
          );
      for (const university of await db.list('UNIVERSITIES'))
        if (university.UNIVERSITY_NAME === 'DEMO - Varsity Vault Training University') {
          await db.update(
            'UNIVERSITIES',
            { UNIVERSITY_ID: university.UNIVERSITY_ID },
            {
              UNIVERSITY_NAME: 'Ndlovu Metropolitan University',
              WEBSITE: 'https://ndlovu.example',
            },
          );
          for (const addr of await db.list('UNIVERSITY_ADDRESSES', {
            UNIVERSITY_ID: university.UNIVERSITY_ID,
          }))
            if (addr.STREET_NAME === 'DEMO - Training Campus')
              await db.update(
                'UNIVERSITY_ADDRESSES',
                { ADDRESS_ID: addr.ADDRESS_ID },
                { STREET_NAME: '1 University Way' },
              );
          for (const o of await db.list('UNI_QUALIFICATIONS', {
            UNIVERSITY_ID: university.UNIVERSITY_ID,
          })) {
            const q = (await db.list('QUALIFICATIONS', { QUAL_ID: o.QUAL_ID }))[0];
            if (q?.QUAL_NAME === 'DEMO - Diploma in Applications Development')
              await db.update(
                'QUALIFICATIONS',
                { QUAL_ID: q.QUAL_ID },
                { QUAL_NAME: 'Diploma in Applications Development' },
              );
            for (const row of await db.list('security.Policies', { UNI_QUAL_ID: o.UNI_QUAL_ID })) {
              const cfg = JSON.parse(row.PAYLOAD);
              if (String(cfg.notes).includes('DEMO ONLY')) {
                cfg.notes =
                  'Simulated academic profile. Requirements are not official university admissions criteria.';
                cfg.source = String(cfg.source).replaceAll('demo', 'workflow');
                await db.update(
                  'security.Policies',
                  { UNI_QUAL_ID: o.UNI_QUAL_ID },
                  { PAYLOAD: JSON.stringify(cfg) },
                );
              }
            }
            for (const r of await db.list('QUALIFICATION_REQUIREMENTS', {
              UNI_QUAL_ID: o.UNI_QUAL_ID,
            }))
              if (String(r.NOTES).includes('DEMO ONLY'))
                await db.update(
                  'QUALIFICATION_REQUIREMENTS',
                  { REQUIREMENT_ID: r.REQUIREMENT_ID },
                  { NOTES: 'Simulated academic profile. Check institutional requirements.' },
                );
          }
          for (const p of await db.list('PROSPECTUSES', {
            UNIVERSITY_ID: university.UNIVERSITY_ID,
          }))
            if (/DEMO/i.test(p.PROSPECTUS_FILENAME || ''))
              await db.update(
                'PROSPECTUSES',
                { PROSPECTUS_ID: p.PROSPECTUS_ID },
                {
                  PROSPECTUS_FILENAME: 'University-Prospectus.pdf',
                  PROSPECTUS_FILE: makeSamplePdf('University Prospectus', [
                    'Simulated academic information',
                  ]),
                },
              );
        }
    }
    return { accounts: summary, updated: summary.filter((p) => p.updated).length };
  });
}
