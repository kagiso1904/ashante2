import { readFileSync } from 'node:fs';

export const universityLocationDirectory = JSON.parse(
  readFileSync(new URL('../config/university-locations.json', import.meta.url)),
);
const normalize = (value) =>
  String(value ?? '')
    .trim()
    .toLowerCase();
const provinceKey = (value) => normalize(value).replace(/[\s-]/g, '');
const cityAliases = {
  'east london': ['east london', 'kugompo', 'ku gompo'],
  gqeberha: ['gqeberha', 'port elizabeth'],
  makhanda: ['makhanda', 'grahamstown'],
  mbombela: ['mbombela', 'nelspruit'],
  komani: ['komani', 'queenstown'],
  mahikeng: ['mahikeng', 'mafikeng'],
};
function hostname(value) {
  try {
    return new URL(value).hostname.toLowerCase().replace(/^www\./, '');
  } catch {
    return '';
  }
}

// Add real city links for recognised existing universities, never personal data.
// The caller owns the transaction. Existing addresses and identifiers are retained.
export async function ensureUniversityLocations(db) {
  const universities = await db.list('UNIVERSITIES');
  const provinces = await db.list('PROVINCES');
  const cities = await db.list('CITIES');
  const addresses = await db.list('UNIVERSITY_ADDRESSES');
  const types = await db.list('ADDRESS_TYPES');
  const report = { universitiesMatched: 0, citiesAdded: 0, linksAdded: 0 };
  let campusType = types.find(
    (t) => normalize(t.ADDRESS_TYPE_NAME) === 'campus',
  );
  const matchedIds = new Set();
  for (const entry of universityLocationDirectory) {
    const names = [entry.name, ...entry.aliases].map(normalize);
    const matches = universities.filter(
      (u) =>
        names.includes(normalize(u.UNIVERSITY_NAME)) ||
        hostname(u.WEBSITE) === entry.host,
    );
    if (matches.length > 1)
      throw new Error('Duplicate university location matches: ' + entry.name);
    const university = matches[0];
    if (!university) continue;
    if (matchedIds.has(String(university.UNIVERSITY_ID)))
      throw new Error(
        'One university matches multiple location directory entries. Review its name and website.',
      );
    matchedIds.add(String(university.UNIVERSITY_ID));
    report.universitiesMatched++;
    for (const location of entry.locations) {
      const provinceMatches = provinces.filter(
        (p) => provinceKey(p.PROVINCE_NAME) === provinceKey(location.province),
      );
      if (provinceMatches.length > 1)
        throw new Error('Duplicate province aliases: ' + location.province);
      let province = provinceMatches[0];
      if (!province) {
        province = await db.insert('PROVINCES', {
          PROVINCE_NAME: location.province,
        });
        provinces.push(province);
      }
      const aliases = cityAliases[normalize(location.city)] || [
        normalize(location.city),
      ];
      const candidates = cities.filter(
        (c) =>
          String(c.PROVINCE_ID) === String(province.PROVINCE_ID) &&
          aliases.includes(normalize(c.CITY_NAME)),
      );
      // Prefer a city already linked to this university when historical names coexist.
      let city =
        candidates.find((c) =>
          addresses.some(
            (a) =>
              String(a.UNIVERSITY_ID) === String(university.UNIVERSITY_ID) &&
              String(a.CITY_ID) === String(c.CITY_ID),
          ),
        ) || candidates[0];
      if (!city) {
        city = await db.insert('CITIES', {
          CITY_NAME: location.city,
          PROVINCE_ID: province.PROVINCE_ID,
        });
        cities.push(city);
        report.citiesAdded++;
      }
      if (
        addresses.some(
          (a) =>
            String(a.UNIVERSITY_ID) === String(university.UNIVERSITY_ID) &&
            String(a.CITY_ID) === String(city.CITY_ID),
        )
      )
        continue;
      if (!campusType)
        campusType = await db.insert('ADDRESS_TYPES', {
          ADDRESS_TYPE_NAME: 'Campus',
        });
      addresses.push(
        await db.insert('UNIVERSITY_ADDRESSES', {
          UNIVERSITY_ID: university.UNIVERSITY_ID,
          ADDRESS_TYPE_ID: campusType.ADDRESS_TYPE_ID,
          CITY_ID: city.CITY_ID,
          STREET_NAME: null, // City-level link; no street address is invented.
        }),
      );
      report.linksAdded++;
    }
  }
  return report;
}

// Preserve the existing first-address fields while exposing every campus city.
export function universityLocations(university, addresses, cities, provinces) {
  return addresses
    .filter((a) => String(a.UNIVERSITY_ID) === String(university.UNIVERSITY_ID))
    .sort((a, b) => Number(a.ADDRESS_ID) - Number(b.ADDRESS_ID))
    .map((a) => {
      const city = cities.find((c) => String(c.CITY_ID) === String(a.CITY_ID));
      return {
        ...a,
        CITY_NAME: city?.CITY_NAME ?? null,
        PROVINCE_ID: city?.PROVINCE_ID ?? null,
        PROVINCE_NAME:
          provinces.find(
            (p) => String(p.PROVINCE_ID) === String(city?.PROVINCE_ID),
          )?.PROVINCE_NAME ?? null,
      };
    });
}
