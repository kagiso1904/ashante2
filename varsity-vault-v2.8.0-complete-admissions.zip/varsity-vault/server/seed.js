import { readFileSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import { passwordHash } from './security.js';
import { sameId } from './identity.js';
export async function seedLocal(db) {
  if ((await db.list('PROVINCES')).length) return;
  const provinces = [
    'Eastern Cape',
    'Free State',
    'Gauteng',
    'KwaZulu-Natal',
    'Limpopo',
    'Mpumalanga',
    'North West',
    'Northern Cape',
    'Western Cape',
  ];
  for (const name of provinces) await db.insert('PROVINCES', { PROVINCE_NAME: name });
  const city = await db.insert('CITIES', { CITY_NAME: 'Development City', PROVINCE_ID: 1 });
  await db.insert('SCHOOLS', {
    SCHOOL_NAME: 'Development Secondary School',
    EMIS_NUMBER: 'LOCAL-ONLY',
    CITY_ID: city.CITY_ID,
    PROVINCE_ID: 1,
  });
  const policies = JSON.parse(
    readFileSync(new URL('../config/universities/2027/register.json', import.meta.url)),
  );
  for (const p of policies)
    await db.insert('UNIVERSITIES', {
      UNIVERSITY_NAME: p.name,
      WEBSITE: p.url,
      PROVINCE_ID: Math.max(1, provinces.indexOf(p.provinces[0]) + 1),
    });
  for (const name of [
    'Submitted',
    'Screened by Career Teacher',
    'Provisionally Accepted',
    'Final Matric Verified',
    'Admitted',
    'Offer Revoked',
    'Rejected',
  ])
    await db.insert('APPLICATION_STATUSES', {
      STATUS_NAME: name,
      USES_FINAL_RESULTS: ['Final Matric Verified', 'Admitted', 'Offer Revoked'].includes(name)
        ? 1
        : 0,
    });
  for (const name of [
    'Submitted',
    'Screened by Career Teacher',
    'Provisionally Accepted',
    'Final Matric Verified',
    'Admitted',
    'Offer Revoked',
    'Rejected',
  ])
    await db.insert('ACTIONS', { ACTION_NAME: name });
  for (const name of ['Pending', 'Verified', 'Rejected'])
    await db.insert('VERIFICATION_STATUSES', { VERIFICATION_STATUS_NAME: name });
  for (const name of ['Grade 11 Final', 'Grade 12 June/Trial', 'Grade 12 Final (NSC)'])
    await db.insert('EXAM_TYPES', { EXAM_TYPE_NAME: name });
  for (const [name, mandatory, locked] of [
    ['Grade 11 Final Report', 1, 0],
    ['Certified Copy of Identity Document', 1, 0],
    ['Grade 12 June/Trial Report', 0, 0],
    ['Final NSC Certificate', 0, 1],
  ])
    await db.insert('DOCUMENT_TYPES', {
      DOCUMENT_TYPE_NAME: name,
      IS_MANDATORY: mandatory,
      IS_LOCKED_UNTIL_FINAL: locked,
    });
  for (const name of ['Full-time', 'Part-time'])
    await db.insert('STUDY_MODES', { STUDY_MODE_NAME: name });
  for (const [level, min] of [
    [7, 80],
    [6, 70],
    [5, 60],
    [4, 50],
    [3, 40],
    [2, 30],
    [1, 0],
  ])
    await db.insert('ACHIEVEMENT_LEVELS', {
      LEVEL_NO: level,
      LEVEL_DESCRIPTION: 'NSC level ' + level,
      MIN_PERCENT: min,
      APS_POINTS: level,
    });
  const original = readFileSync(new URL('../docs/submitted-subjects.json', import.meta.url));
  for (const subject of JSON.parse(original)) await db.insert('SUBJECTS', subject);
}
export async function bootstrapAdmin(
  db,
  { username, password, firstName = 'System', lastName = 'Administrator' },
) {
  const admins = await db.list('ITADMINS'),
    accounts = await db.list('security.Accounts');
  if (accounts.some((a) => admins.some((ad) => sameId(ad.PERSON_ID, a.PERSON_ID))))
    throw new Error('An administrator login already exists; use that administrator account.');
  if (typeof username !== 'string' || username.length > 100 || !/^\S+@\S+\.\S+$/.test(username))
    throw new Error('Set a valid ADMIN_EMAIL of at most 100 characters.');
  if (accounts.some((a) => a.USERNAME === username.toLowerCase()))
    throw new Error('That email already has an account.');
  const existing = (await db.list('PERSONS')).filter(
    (p) =>
      p.EMAIL?.toLowerCase() === username.toLowerCase() ||
      p.USERNAME?.toLowerCase() === username.toLowerCase(),
  );
  if (
    existing.length > 1 ||
    (existing.length === 1 && !admins.some((a) => sameId(a.PERSON_ID, existing[0].PERSON_ID)))
  )
    throw new Error('The existing person must already be an IT administrator.');
  if (!existing.length && db.mode === 'sqlserver' && !Number(process.env.ADMIN_SCHOOL_ID))
    throw new Error('Set ADMIN_SCHOOL_ID to the existing school assigned to this administrator.');
  const hash = await passwordHash(password);
  return db.tx(async (tx) => {
    const person =
      existing[0] ||
      (await tx.createPerson({
        FIRST_NAME: firstName,
        LAST_NAME: lastName,
        EMAIL: username,
        USERNAME: username,
        PHONE_NUMBER: null,
        SA_ID_NUMBER: null,
      }, {type:'A', schoolId: Number(process.env.ADMIN_SCHOOL_ID) || (db.mode === 'local' ? (await tx.list('SCHOOLS'))[0]?.SCHOOL_ID : null)}));
    await tx.insert('security.Accounts', {
      ACCOUNT_ID: randomUUID(),
      PERSON_ID: person.PERSON_ID,
      USERNAME: username.toLowerCase(),
      PASSWORD_HASH: hash,
      DISABLED: 0,
    });
    await tx.insert('security.EmailVerifications', {
      PERSON_ID: person.PERSON_ID,
      VERIFIED_AT: null,
    });
    return person;
  });
}
