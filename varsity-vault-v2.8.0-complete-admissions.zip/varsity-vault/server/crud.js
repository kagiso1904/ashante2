import { readFileSync } from 'node:fs';
import { metadata } from './storage.js';
import { audit } from './security.js';
import { sameId } from './identity.js';
const ddl = readFileSync(
  new URL('../database/source/unilink_script_improved.sql', import.meta.url),
  'utf8',
);
const foreignKeys = [
  ...ddl.matchAll(
    /ALTER TABLE\s+(\w+)\s+ADD CONSTRAINT\s+\w+\s+FOREIGN KEY\s*\((\w+)\)\s+REFERENCES\s+(\w+)\s*\((\w+)\)/gi,
  ),
].map((m) => ({ child: m[1], column: m[2], parent: m[3], key: m[4] }));
const reject = (message, status = 409) => {
  throw Object.assign(new Error(message), { status });
};
async function requireUnused(db, table, row, ignore = []) {
  for (const fk of foreignKeys.filter((f) => f.parent === table && !ignore.includes(f.child)))
    if ((await db.list(fk.child, { [fk.column]: row[fk.key] })).length)
      reject(
        'Cannot delete: this record is used by ' +
          fk.child.replaceAll('_', ' ') +
          '. Keep it or remove its dependent records through their normal workflow first.',
      );
}
export function installCrud(router, { wrap, role, id }) {
  router.delete(
    '/admin/people/:id',
    wrap(async (db, u, req) => {
      role(u, 'admin');
      const personId = id(req.params.id);
      if (sameId(personId, u.personId)) reject('You cannot delete your own account.');
      const person = (await db.list('PERSONS', { PERSON_ID: personId }))[0];
      if (!person) reject('Person not found.', 404);
      const roles = ['LEARNERS', 'TEACHERS', 'UNIVERSITY_REPS', 'ITADMINS'];
      await requireUnused(db, 'PERSONS', person, [...roles, 'PERSON_ADDRESSES']);
      for (const table of roles)
        for (const row of await db.list(table, { PERSON_ID: personId }))
          await requireUnused(db, table, row);
      for (const table of [
        'security.Sessions',
        'security.AccountTokens',
        'security.EmailVerifications',
        'security.Mfa',
        'security.MfaChallenges',
        'security.Accounts',
      ])
        await db.remove(table, { PERSON_ID: personId });
      await db.remove('PERSON_ADDRESSES', { PERSON_ID: personId });
      await db.remove('PERSONS', { PERSON_ID: personId });
      if (db.mode === 'local') for (const table of roles) await db.remove(table, { PERSON_ID: personId });
      await audit(db, u.personId, 'person.delete', { personId });
      return { message: 'Person and sign-in account permanently deleted. Audit history retained.' };
    }),
  );
  const tables = [
    'ADDRESS_TYPES',
    'DOCUMENT_TYPES',
    'PROGRAMS',
    'QUALIFICATIONS',
    'PERSON_ADDRESSES',
    'UNIVERSITY_ADDRESSES',
    'CITIES',
    'PROVINCES',
    'SCHOOLS',
    'UNIVERSITIES',
    'SUBJECTS',
    'STUDY_MODES',
  ];
  router.delete(
    '/admin/records/:table/:id',
    wrap(async (db, u, req) => {
      role(u, 'admin');
      const table = req.params.table;
      if (!tables.includes(table))
        reject('This record is managed by its workflow and cannot be deleted here.', 403);
      const key = metadata[table].primary[0],
        where = { [key]: id(req.params.id) },
        row = (await db.list(table, where))[0];
      if (!row) reject('Record not found.', 404);
      await requireUnused(db, table, row);
      await db.remove(table, where);
      await audit(db, u.personId, 'record.delete', { table, target: where[key] });
      return { message: 'Unused record permanently deleted.' };
    }),
  );
  for (const path of ['/admin/offerings/:id', '/representative/offerings/:id'])
    router.delete(
      path,
      wrap(async (db, u, req) => {
        role(u, 'admin', 'representative');
        const key = { UNI_QUAL_ID: id(req.params.id) },
          row = (await db.list('UNI_QUALIFICATIONS', key))[0];
        if (!row) reject('Offering not found.', 404);
        if (u.role === 'representative' && !sameId(row.UNIVERSITY_ID, u.universityId))
          reject('Offering outside your university.', 403);
        await requireUnused(db, 'UNI_QUALIFICATIONS', row, ['QUALIFICATION_REQUIREMENTS']);
        await db.remove('QUALIFICATION_REQUIREMENTS', key);
        await db.remove('security.Policies', key);
        await db.remove('UNI_QUALIFICATIONS', key);
        await audit(db, u.personId, 'offering.delete', { target: key.UNI_QUAL_ID });
        return { message: 'Unused offering deleted.' };
      }),
    );
}
