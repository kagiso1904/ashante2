import { metadata } from './storage.js';
import { audit } from './security.js';
const fail = (message, status = 400) => {
  throw Object.assign(new Error(message), { status });
};
const editable = {
  ADDRESS_TYPES: ['ADDRESS_TYPE_NAME'],
  DOCUMENT_TYPES: ['DOCUMENT_TYPE_NAME', 'IS_MANDATORY', 'IS_LOCKED_UNTIL_FINAL'],
  PROGRAMS: ['PROGRAM_NAME'],
  QUALIFICATIONS: ['QUAL_NAME', 'PROGRAM_ID'],
  ACHIEVEMENT_LEVELS: ['LEVEL_NO', 'LEVEL_DESCRIPTION', 'MIN_PERCENT', 'APS_POINTS'],
  PERSON_ADDRESSES: ['PERSON_ID', 'ADDRESS_TYPE_ID', 'STREET_NAME', 'CITY_ID'],
  UNIVERSITY_ADDRESSES: ['UNIVERSITY_ID', 'ADDRESS_TYPE_ID', 'STREET_NAME', 'CITY_ID'],
  TEACHERS: ['DEPARTMENT'],
  ITADMINS: ['SCHOOL_ID'],
};
const managed = ['ACTIONS', 'APPLICATION_STATUSES', 'VERIFICATION_STATUSES', 'EXAM_TYPES'];
const refs = {
  PERSON_ID: ['PERSONS', 'PERSON_ID'],
  ADDRESS_TYPE_ID: ['ADDRESS_TYPES', 'ADDRESS_TYPE_ID'],
  CITY_ID: ['CITIES', 'CITY_ID'],
  UNIVERSITY_ID: ['UNIVERSITIES', 'UNIVERSITY_ID'],
  PROGRAM_ID: ['PROGRAMS', 'PROGRAM_ID'],
  SCHOOL_ID: ['SCHOOLS', 'SCHOOL_ID'],
};
const routeFor = {
  PERSONS: 'My Profile / Accounts',
  SCHOOLS: 'Directories',
  UNIVERSITIES: 'Directories',
  CITIES: 'Directories',
  PROVINCES: 'Directories',
  SUBJECTS: 'Directories',
  LEARNERS: 'Accounts: learner role',
  UNIVERSITY_REPS: 'Accounts: university representative role',
  STUDY_MODES: 'Directories',
  PROSPECTUSES: 'Prospectuses upload',
  UNI_QUALIFICATIONS: 'Programme Requirements',
  QUALIFICATION_REQUIREMENTS: 'Programme Requirements',
  APPLICATIONS: 'Requirements → Apply; application review',
  APPLICATION_PROCESSES: 'Application transitions and timeline (automatic)',
  DOCUMENTS: 'Documents upload and teacher verification',
  LEARNER_RESULTS: 'Results and teacher verification',
  LEARNER_SUBJECTS: 'Results save (automatic)',
};
export function installRecordEntry(router, { wrap, role, id }) {
  const tableName = (req) => {
    const t = req.params.table;
    if (!Object.hasOwn(editable, t) && !managed.includes(t))
      fail('Use the dedicated portal workflow for this table.');
    return t;
  };
  router.get(
    '/admin/column-coverage',
    wrap(async (db, u) => {
      role(u, 'admin');
      return {
        tables: Object.entries(metadata)
          .filter(([t]) => !t.startsWith('security.'))
          .map(([table, info]) => ({
            table,
            entry:
              routeFor[table] ||
              (managed.includes(table)
                ? 'Workflow reference values (managed automatically)'
                : 'Academic data entry'),
            columns: Object.keys(info.columns).map((column) => ({
              column,
              mode:
                column === info.identity
                  ? 'Generated identity'
                  : column.endsWith('_DATE') || column === 'APPLICATION_DATE'
                    ? 'Form or workflow timestamp'
                    : (editable[table] || []).includes(column)
                      ? 'Academic data entry'
                      : 'Dedicated form or workflow',
            })),
          })),
      };
    }),
  );
  router.get(
    '/admin/records',
    wrap(async (db, u) => {
      role(u, 'admin');
      return { tables: [...Object.keys(editable), ...managed] };
    }),
  );
  router.get(
    '/admin/records/:table',
    wrap(async (db, u, req) => {
      role(u, 'admin');
      const t = tableName(req),
        info = metadata[t],
        choices = {};
      for (const column of Object.keys(info.columns))
        if (refs[column]) {
          const [target, key] = refs[column];
          choices[column] = (await db.list(target)).map((r) => ({
            value: r[key],
            label:
              target === 'PERSONS'
                ? [r.FIRST_NAME, r.LAST_NAME, r.EMAIL].filter(Boolean).join(' · ')
                : r[Object.keys(r).find((k) => k.endsWith('_NAME'))] || String(r[key]),
          }));
        }
      return {
        table: t,
        primary: info.primary[0],
        identity: info.identity,
        updateOnly: ['TEACHERS', 'ITADMINS'].includes(t),
        managed: managed.includes(t),
        columns: Object.entries(info.columns).map(([name, c]) => ({
          name,
          ...c,
          editable: (editable[t] || []).includes(name),
        })),
        choices,
        rows: await db.list(t),
      };
    }),
  );
  const save = wrap(async (db, u, req) => {
    role(u, 'admin');
    const t = tableName(req),
      info = metadata[t],
      key = info.primary[0],
      allowed = editable[t];
    if (!allowed) fail('These reference values are maintained by the workflow.', 403);
    if (!req.params.id && ['TEACHERS', 'ITADMINS'].includes(t))
      fail('Create the person and assigned role from Accounts first.');
    const columns = allowed.filter((k) => !req.params.id || k !== key);
    if (Object.keys(req.body).some((k) => !columns.includes(k)))
      fail('The request contains a read-only or unknown column.');
    const data = {};
    for (const k of columns) {
      const v = req.body[k],
        c = info.columns[k];
      if (c.type === 'BIT') {
        if (typeof v !== 'boolean') fail(k + ' must be true or false.');
        data[k] = v ? 1 : 0;
      } else if (refs[k]) {
        data[k] = id(v);
        const [target, pk] = refs[k];
        if (!(await db.list(target, { [pk]: data[k] })).length)
          fail('Choose an existing ' + k.replaceAll('_', ' ') + '.');
      } else if (['INT', 'TINYINT', 'SMALLINT', 'DECIMAL'].includes(c.type)) {
        if (
          typeof v !== 'number' ||
          !Number.isFinite(v) ||
          v < 0 ||
          (c.type !== 'DECIMAL' && !Number.isInteger(v))
        )
          fail(k + ' must be a valid non-negative number.');
        data[k] = v;
      } else {
        if (
          typeof v !== 'string' ||
          !v.trim() ||
          v.length > Number(c.size || 150) ||
          /[\u0000-\u001f\u007f]/.test(v)
        )
          fail('Enter ' + k.replaceAll('_', ' ') + ' within ' + (c.size || 150) + ' characters.');
        data[k] = v.trim();
      }
    }
    if (
      t === 'ACHIEVEMENT_LEVELS' &&
      ((data.LEVEL_NO !== undefined && (data.LEVEL_NO < 1 || data.LEVEL_NO > 7)) ||
        data.MIN_PERCENT > 100 ||
        data.APS_POINTS > 7)
    )
      fail('Use NSC level 1–7, minimum percentage 0–100 and APS points 0–7.');
    const all = await db.list(t);
    let where;
    if (!req.params.id && data[key] !== undefined && all.some((r) => Number(r[key]) === data[key]))
      fail('That primary key is already in use.', 409);
    if (
      t === 'ACHIEVEMENT_LEVELS' &&
      all.some(
        (r) =>
          (!req.params.id || Number(r[key]) !== Number(req.params.id)) &&
          Number(r.MIN_PERCENT) === data.MIN_PERCENT,
      )
    )
      fail('That percentage boundary already exists.', 409);
    if (req.params.id) {
      where = { [key]: id(req.params.id) };
      if (!all.some((r) => Number(r[key]) === where[key])) fail('Record not found.', 404);
    }
    const name = columns.find((k) => k.endsWith('_NAME') || k === 'QUAL_NAME');
    if (
      name &&
      all.some(
        (r) =>
          (!where || r[key] !== where[key]) &&
          String(r[name]).trim().toLowerCase() === data[name].toLowerCase(),
      )
    )
      fail('A record with that name already exists.', 409);
    if (t === 'DOCUMENT_TYPES' && where) {
      const old = all.find((r) => r[key] === where[key]);
      if (old.DOCUMENT_TYPE_NAME !== data.DOCUMENT_TYPE_NAME)
        fail(
          'Existing document type names are read-only because application rules refer to them. Create a new type instead.',
        );
    }
    let row;
    if (where) {
      await db.update(t, where, data);
      row = { ...where, ...data };
    } else row = await db.insert(t, data);
    await audit(db, u.personId, 'academic.record.save', { table: t, target: row[key] });
    return { row, message: 'Record saved to the database.' };
  });
  router.post('/admin/records/:table', save);
  router.patch('/admin/records/:table/:id', save);
}
