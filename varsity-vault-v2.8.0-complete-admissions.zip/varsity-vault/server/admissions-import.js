import { readFileSync } from 'node:fs';
import { universityLocationDirectory } from './university-locations.js';

export const admissionProfiles = JSON.parse(
  readFileSync(new URL('../data/admissions-complete.json', import.meta.url)),
);
const subjects = JSON.parse(
  readFileSync(new URL('../data/admission-subjects.json', import.meta.url)),
);
const name = (x) =>
  String(x || '')
    .trim()
    .toLowerCase();
const host = (x) => {
  try {
    return new URL(x).hostname.replace(/^www\./, '').toLowerCase();
  } catch {
    return '';
  }
};

// Explicit operator command; normal startup never changes admission profiles.
// No schema changes and no writes to personal, account or application tables.
export async function importAdmissionProfiles(store) {
  return store.tx(async (db) => {
    const universities = await db.list('UNIVERSITIES');
    const qualifications = await db.list('QUALIFICATIONS');
    const offerings = await db.list('UNI_QUALIFICATIONS');
    const policies = await db.list('security.Policies');
    const matches = [];
    for (const row of admissionProfiles) {
      const entry = universityLocationDirectory.find(
        (u) => u.name === row.university,
      );
      const aliases = [row.university, ...(entry?.aliases || [])].map(name);
      const universityIds = universities
        .filter(
          (u) =>
            aliases.includes(name(u.UNIVERSITY_NAME)) ||
            (entry && host(u.WEBSITE) === entry.host),
        )
        .map((u) => String(u.UNIVERSITY_ID));
      const qualificationIds = qualifications
        .filter((q) => name(q.QUAL_NAME) === name(row.qualification))
        .map((q) => String(q.QUAL_ID));
      const targets = offerings.filter(
        (o) =>
          universityIds.includes(String(o.UNIVERSITY_ID)) &&
          qualificationIds.includes(String(o.QUAL_ID)),
      );
      if (targets.length > 1 || universityIds.length > 1)
        throw new Error(
          'Ambiguous qualification: ' +
            row.university +
            ' / ' +
            row.qualification,
        );
      if (!targets.length) {
        if (row.optional) continue;
        throw new Error(
          'Missing catalogue offering: ' +
            row.university +
            ' / ' +
            row.qualification +
            '. Load database/06_load_reference_data_no_users.sql first.',
        );
      }
      matches.push({ row, offering: targets[0] });
    }
    if (matches.filter((m) => !m.row.optional).length !== 260)
      throw new Error(
        'Expected all 260 catalogue offerings before applying changes.',
      );
    const existingSubjects = await db.list('SUBJECTS');
    for (const [code, definition] of Object.entries(subjects)) {
      // Keep existing school-specific IDs and results intact; add a national
      // option so a newly registered learner at another school can capture it.
      if (
        !existingSubjects.some(
          (s) => name(s.SUBJECT_CODE) === name(code) && s.SCHOOL_ID == null,
        )
      )
        await db.insert('SUBJECTS', {
          SUBJECT_CODE: code,
          SUBJECT_NAME: definition.name,
          SUBJECT_CATEGORY: definition.category,
          SCHOOL_ID: null,
        });
    }
    const types = await db.list('DOCUMENT_TYPES');
    const documentNames = new Set(
      matches.flatMap((m) => m.row.config.requiredDocumentNames),
    );
    for (const label of documentNames) {
      const found = types.filter(
        (t) => name(t.DOCUMENT_TYPE_NAME) === name(label),
      );
      if (found.length > 1)
        throw new Error('Duplicate document type: ' + label);
      if (!found.length)
        types.push(
          await db.insert('DOCUMENT_TYPES', {
            DOCUMENT_TYPE_NAME: label,
            IS_MANDATORY: false,
            IS_LOCKED_UNTIL_FINAL: false,
          }),
        );
    }
    const requirements = await db.list('QUALIFICATION_REQUIREMENTS');
    for (const { row, offering } of matches) {
      const key = { UNI_QUAL_ID: offering.UNI_QUAL_ID };
      const old = policies.find(
        (p) => String(p.UNI_QUAL_ID) === String(offering.UNI_QUAL_ID),
      );
      const previous = old ? JSON.parse(old.PAYLOAD) : {};
      const config = {
        ...previous,
        ...row.config,
        requiredDocumentIds: row.config.requiredDocumentNames.map(
          (label) =>
            types.find((t) => name(t.DOCUMENT_TYPE_NAME) === name(label))
              .DOCUMENT_TYPE_ID,
        ),
      };
      const data = { PAYLOAD: JSON.stringify(config) };
      if (old) await db.update('security.Policies', key, data);
      else await db.insert('security.Policies', { ...key, ...data });
      await db.update('UNI_QUALIFICATIONS', key, {
        APPLICATION_CLOSING_DATE: config.closingDate,
      });
      const legacy = {
        MIN_APS_SCORE: config.minScore,
        MIN_ENG_SCORE: config.minEnglish,
        MIN_MATH_SCORE: config.minMath,
        NOTES: config.notes.slice(0, 400),
      };
      const reqs = requirements.filter(
        (r) => String(r.UNI_QUAL_ID) === String(offering.UNI_QUAL_ID),
      );
      if (reqs.length > 1)
        throw new Error('Duplicate requirement rows for ' + row.qualification);
      if (reqs.length)
        await db.update('QUALIFICATION_REQUIREMENTS', key, legacy);
      else await db.insert('QUALIFICATION_REQUIREMENTS', { ...key, ...legacy });
    }
    return {
      catalogueProfiles: 260,
      existingAdditionalProfiles: matches.filter((m) => m.row.optional).length,
      totalUpdated: matches.length,
    };
  });
}
