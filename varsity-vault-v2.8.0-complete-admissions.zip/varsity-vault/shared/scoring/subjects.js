import { configuredAssessment } from './programme.js';
const english = (row) => /^ENG(HL|FAL)$/.test(row.SUBJECT_CODE || '');

export function curriculum(records) {
  const categories = new Set(records.map((row) => row.SUBJECT_CATEGORY));
  return (
    records.length >= 7 &&
    new Set(records.map((row) => row.SUBJECT_CODE)).size === records.length &&
    records.filter((row) => row.SUBJECT_CATEGORY !== 'LIFE_ORIENTATION').length >= 6 &&
    records.every(
      (row) =>
        typeof row.PERCENTAGE === 'number' &&
        Number.isFinite(row.PERCENTAGE) &&
        row.PERCENTAGE >= 0 &&
        row.PERCENTAGE <= 100,
    ) &&
    categories.has('HOME_LANGUAGE') &&
    categories.has('FIRST_ADDITIONAL_LANGUAGE') &&
    (categories.has('MATHEMATICS') || categories.has('MATHEMATICAL_LITERACY')) &&
    categories.has('LIFE_ORIENTATION')
  );
}

export function apsPoints(percentage) {
  if (
    typeof percentage !== 'number' ||
    !Number.isFinite(percentage) ||
    percentage < 0 ||
    percentage > 100
  )
    return null;
  if (percentage >= 80) return 7;
  if (percentage >= 70) return 6;
  if (percentage >= 60) return 5;
  if (percentage >= 50) return 4;
  if (percentage >= 40) return 3;
  if (percentage >= 30) return 2;
  return 1;
}

export function assessSubjects(records, _policy, config = {}) {
  const result = {
    total: null,
    contributions: [],
    eligible: false,
    status: 'Results incomplete',
    issues: [],
    metric: 'APS (1–7; maximum 42)',
  };
  if (!curriculum(records)) {
    result.issues.push(
      'Capture at least seven valid subjects including Home Language, First Additional Language, Mathematics or Mathematical Literacy and Life Orientation.',
    );
    return result;
  }

  if (config.scoring) return configuredAssessment(records, config);

  const academic = records.filter((row) => row.SUBJECT_CATEGORY !== 'LIFE_ORIENTATION');
  const englishSubject = academic.filter(english).sort((a, b) => b.PERCENTAGE - a.PERCENTAGE)[0];
  const math =
    academic.find((row) => row.SUBJECT_CATEGORY === 'MATHEMATICS') ||
    academic.find((row) => row.SUBJECT_CATEGORY === 'MATHEMATICAL_LITERACY');
  const requiredCodes = new Set(config.requiredCodes || []);
  if (englishSubject) requiredCodes.add(englishSubject.SUBJECT_CODE);
  if (math) requiredCodes.add(math.SUBJECT_CODE);
  const required = academic.filter((row) => requiredCodes.has(row.SUBJECT_CODE));
  if (required.length > 6) {
    result.issues.push(
      'The selected qualification has more than six compulsory academic subjects.',
    );
    return result;
  }

  const selected = [...required];
  const rest = academic
    .filter((row) => !requiredCodes.has(row.SUBJECT_CODE))
    .sort(
      (a, b) => apsPoints(b.PERCENTAGE) - apsPoints(a.PERCENTAGE) || b.PERCENTAGE - a.PERCENTAGE,
    );
  selected.push(...rest.slice(0, 6 - selected.length));
  result.contributions = selected.map((row) => ({ ...row, points: apsPoints(row.PERCENTAGE) }));
  result.total = result.contributions.reduce((sum, row) => sum + row.points, 0);

  const verified =
    config.status === 'verified' &&
    config.intake === 2028 &&
    typeof config.minScore === 'number' &&
    typeof config.source === 'string' &&
    config.source.startsWith('https://');
  if (!verified) {
    result.status = 'Programme requirements pending verification';
    return result;
  }
  if (result.total < config.minScore)
    result.issues.push('Below minimum APS of ' + config.minScore + '.');
  if (
    config.minEnglish != null &&
    (!englishSubject || englishSubject.PERCENTAGE < config.minEnglish)
  )
    result.issues.push('English requirement not met.');
  if (config.minMath != null && (!math || math.PERCENTAGE < config.minMath))
    result.issues.push('Mathematics or Mathematical Literacy requirement not met.');
  for (const [code, minimum] of Object.entries(config.subjectMinimums || {})) {
    if (!records.some((row) => row.SUBJECT_CODE === code && row.PERCENTAGE >= minimum))
      result.issues.push(code + ' minimum of ' + minimum + '% not met.');
  }
  for (const group of new Set((config.subjectGroups || []).map((r) => r.group))) {
    if (
      !(config.subjectGroups || []).some(
        (r) =>
          r.group === group &&
          records.some((m) => m.SUBJECT_CODE === r.code && m.PERCENTAGE >= r.minimum),
      )
    )
      result.issues.push('Subject requirement group ' + group + ' not met.');
  }
  result.eligible = result.issues.length === 0;
  result.status = result.eligible ? 'Listed minimum requirements met' : 'Below listed requirements';
  return result;
}
