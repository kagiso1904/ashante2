// Foundation fixture only: isiXhosa HL, English FAL, Maths, LO, Accounting,
// Business Studies, Economics. Not a general subject-selection engine.
export const subjects = [
  { code: 'XHOHL', name: 'isiXhosa Home Language' },
  { code: 'ENGFAL', name: 'English First Additional Language' },
  { code: 'MATH', name: 'Mathematics' },
  { code: 'LO', name: 'Life Orientation' },
  { code: 'ACCN', name: 'Accounting' },
  { code: 'BUSS', name: 'Business Studies' },
  { code: 'ECON', name: 'Economics' },
];
export const sampleMarks = [75, 72, 65, 80, 78, 74, 68];
export function contribution(raw, index, engine, method) {
  if (typeof raw !== 'number' || !Number.isFinite(raw) || raw < 0 || raw > 100) return null;
  const n = raw,
    base = n >= 80 ? 7 : n >= 70 ? 6 : n >= 60 ? 5 : n >= 50 ? 4 : n >= 40 ? 3 : n >= 30 ? 2 : 1,
    extended = n >= 90 ? 8 : base;
  if (engine === 'smu') return base;
  if (engine === 'uwc')
    return index === 3
      ? n >= 80
        ? 3
        : n >= 50
          ? 2
          : n >= 20
            ? 1
            : 0
      : index === 1 || index === 2
        ? n >= 90
          ? 15
          : n >= 80
            ? 13
            : n >= 70
              ? 11
              : n >= 60
                ? 9
                : n >= 50
                  ? 7
                  : n >= 40
                    ? 5
                    : n >= 30
                      ? 3
                      : n >= 20
                        ? 1
                        : 0
        : n >= 90
          ? 8
          : n >= 80
            ? 7
            : n >= 70
              ? 6
              : n >= 60
                ? 5
                : n >= 50
                  ? 4
                  : n >= 40
                    ? 3
                    : n >= 30
                      ? 2
                      : n >= 20
                        ? 1
                        : 0;
  if (engine === 'wits')
    return index === 3
      ? n >= 90
        ? 4
        : n >= 80
          ? 3
          : n >= 70
            ? 2
            : n >= 60
              ? 1
              : 0
      : (n < 40 ? 0 : extended) + ((index === 1 || index === 2) && n >= 60 ? 2 : 0);
  if (engine === 'spu')
    return index === 3
      ? n >= 90
        ? 4
        : n >= 80
          ? 3
          : n >= 70
            ? 2
            : n >= 60
              ? 1
              : 0
      : extended + (index === 0 || index === 2 ? (n >= 60 ? 2 : n >= 40 ? 1 : 0) : 0);
  if (engine === 'ufh') return index === 3 ? Math.min(base, 4) : base;
  if (engine === 'ump') return index === 3 ? base / 2 : base;
  if (engine === 'ufs') return index === 3 ? (n >= 60 ? 1 : 0) : n < 30 ? 0 : extended;
  if (engine === 'cut') return index === 3 ? (n >= 50 ? 1 : null) : n < 30 ? null : extended;
  if (index === 3) return 0;
  if (engine === 'cput')
    return method === 'method2'
      ? null
      : (n / 10) * (method === 'method3' && (index === 2 || index === 4) ? 2 : 1);
  if (engine === 'uct') return n < 40 ? 0 : n;
  if (engine === 'vut') return n < 40 || n === 100 ? null : extended;
  if (engine === 'raw') return n;
  if (engine === 'average') return n / 6;
  if (engine === 'decimal') return n < 40 ? 0 : n / 10;
  if (engine === 'tut') return n < 30 ? 0 : base;
  if (engine === 'ul' || engine === 'ukzn') return n >= 90 ? null : base;
  if (engine === 'extended') return extended;
  return engine === 'nsc' ? base : null;
}
export function scoreReview(marks, policy, method = 'method1') {
  const units = policy?.engine === 'average' ? '%' : 'points';
  const metric =
    policy?.id === 'nmu'
      ? 'Applicant Score'
      : policy?.engine === 'average'
        ? 'Average'
        : policy?.id === 'uct'
          ? 'Base APS'
          : 'APS / AP';
  const valid =
    Array.isArray(marks) &&
    marks.length === 7 &&
    policy &&
    typeof policy.engine === 'string' &&
    (policy.engine !== 'cput' || ['method1', 'method2', 'method3'].includes(method));
  const points = valid
    ? marks.map((m, i) => contribution(m, i, policy.engine, method))
    : Array(7).fill(null);
  const total = points.some((p) => p === null)
    ? null
    : Math.round(points.reduce((a, b) => a + b, 0) * 100) / 100;
  const missingScience = policy?.engine === 'cput' && method === 'method2';
  return {
    total,
    points,
    units,
    metric,
    scope: 'fixed-seven-subject-review',
    eligibility: 'not_assessed',
    submissionEnabled: false,
    reason:
      total !== null
        ? 'Programme eligibility remains unassessed.'
        : missingScience
          ? 'Physical Sciences is missing from this sample curriculum.'
          : 'Valid marks and a resolved scoring band are required.',
  };
}
