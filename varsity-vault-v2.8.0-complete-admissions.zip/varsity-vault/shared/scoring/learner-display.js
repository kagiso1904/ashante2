// Qualification review is staff workflow. Learners see actionable availability
// and missing information without internal policy-verification terminology.
export function learnerAvailability(value) {
  return (
    {
      Open: 'Applications open',
      Closed: 'Applications closed',
      'Not yet open': 'Applications open later',
      Inactive: 'Applications unavailable',
    }[value] || 'Application dates and requirements are not available yet'
  );
}
export function learnerAssessmentStatus(value) {
  return /programme requirements pending verification|requirements pending verification/i.test(
    String(value),
  )
    ? 'Admission requirements are not available yet. Check the university information below.'
    : value;
}
