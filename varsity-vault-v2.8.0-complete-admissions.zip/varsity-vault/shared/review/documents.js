/**
 * Determine whether a document is required before provisional acceptance.
 * Final-stage documents must not block the initial learner application because
 * the SQL Server trigger intentionally locks them until an offer is issued.
 */
export function isRequiredBeforeProvisional(documentType, offeringConfig = {}) {
  if (!documentType || Boolean(documentType.IS_LOCKED_UNTIL_FINAL)) return false;
  const id = Number(documentType.DOCUMENT_TYPE_ID);
  const configured = Array.isArray(offeringConfig.requiredDocumentIds)
    ? offeringConfig.requiredDocumentIds.some((value) => Number(value) === id)
    : false;
  return Boolean(documentType.IS_MANDATORY) || configured;
}
