// Demonstration data only. These IDs never map to SQL Server records.
export function createReviewState() {
  return {
    version: 1,
    learners: [
      {
        id: 'sample-l1',
        name: 'Sample Learner One',
        school: 'sample-school',
        resultsVerified: false,
        marks: [75, 72, 65, 80, 78, 74, 68],
        report: [75, 72, 65, 80, 78, 74, 68],
        documents: [
          { id: 'sample-d1', type: 'Grade 11 Final Report', date: '2026-09-14', status: 'Pending' },
          { id: 'sample-d2', type: 'Certified ID Copy', date: '2026-09-16', status: 'Pending' },
        ],
      },
      {
        id: 'sample-l2',
        name: 'Sample Learner Two',
        school: 'sample-school',
        resultsVerified: false,
        marks: [70, 68, 61, 75, 65, 72, 66],
        report: [70, 68, 56, 75, 65, 72, 66],
        documents: [
          { id: 'sample-d3', type: 'Grade 11 Final Report', date: '2026-09-18', status: 'Pending' },
          { id: 'sample-d4', type: 'Certified ID Copy', date: '2026-09-18', status: 'Pending' },
        ],
      },
      {
        id: 'sample-l3',
        name: 'Sample Learner Three',
        school: 'other-school',
        resultsVerified: true,
        marks: [80, 75, 70, 80, 76, 70, 72],
        report: [80, 75, 70, 80, 76, 70, 72],
        documents: [],
      },
    ],
    applications: [
      {
        id: 'sample-a1',
        learnerId: 'sample-l1',
        university: 'wsu',
        qualification: 'Commerce · sample offering',
        status: 'Submitted',
        intake: 2028,
        history: [{ status: 'Submitted', at: '2026-09-20T08:00:00.000Z', actor: 'Sample learner' }],
      },
      {
        id: 'sample-a2',
        learnerId: 'sample-l2',
        university: 'uj',
        qualification: 'Teaching · sample offering',
        status: 'Submitted',
        intake: 2028,
        history: [{ status: 'Submitted', at: '2026-09-21T08:00:00.000Z', actor: 'Sample learner' }],
      },
      {
        id: 'sample-a3',
        learnerId: 'sample-l3',
        university: 'wsu',
        qualification: 'Science · sample offering',
        status: 'Screened by Career Teacher',
        intake: 2028,
        history: [
          { status: 'Submitted', at: '2026-09-20T08:00:00.000Z', actor: 'Sample learner' },
          {
            status: 'Screened by Career Teacher',
            at: '2026-09-22T09:00:00.000Z',
            actor: 'Sample teacher',
          },
        ],
      },
    ],
  };
}
export function schoolLearners(state, school = 'sample-school') {
  return state.learners.filter((l) => l.school === school);
}
export function institutionApplications(state, university = 'wsu') {
  return state.applications.filter((a) => a.university === university);
}
export function verifyReviewResults(state, learnerId, school = 'sample-school') {
  const learner = state.learners.find((l) => l.id === learnerId && l.school === school);
  if (!learner) throw new Error('Learner is outside this sample school.');
  if (
    learner.marks.length !== 7 ||
    learner.marks.some(
      (m, i) =>
        typeof m !== 'number' || !Number.isFinite(m) || m < 0 || m > 100 || m !== learner.report[i],
    )
  )
    throw new Error(
      'Entered marks do not match the sample report. Resolve the mismatch before verification.',
    );
  learner.resultsVerified = true;
  return learner;
}
export function verifyReviewDocument(state, learnerId, documentId, school = 'sample-school') {
  const learner = state.learners.find((l) => l.id === learnerId && l.school === school);
  const document = learner?.documents.find((d) => d.id === documentId);
  if (!document) throw new Error('Document is outside this sample school.');
  document.status = 'Verified';
  return document;
}
export function transitionReview(
  state,
  applicationId,
  target,
  actor,
  now = new Date().toISOString(),
) {
  const application = state.applications.find((a) => a.id === applicationId);
  if (!application) throw new Error('Sample application not found.');
  const learner = state.learners.find((l) => l.id === application.learnerId);
  if (actor.role === 'teacher') {
    if (
      learner?.school !== actor.school ||
      target !== 'Screened by Career Teacher' ||
      application.status !== 'Submitted'
    )
      throw new Error('Only a submitted application at this sample school can be screened.');
    if (
      !learner.resultsVerified ||
      !['Grade 11 Final Report', 'Certified ID Copy'].every((type) =>
        learner.documents.some((d) => d.type === type && d.status === 'Verified'),
      )
    )
      throw new Error('Verify the sample results, report and ID copy before screening.');
  } else if (actor.role === 'representative') {
    if (
      application.university !== actor.university ||
      application.status !== 'Screened by Career Teacher' ||
      !['Provisionally Accepted', 'Rejected'].includes(target)
    )
      throw new Error('Review requires a screened application for this sample institution.');
  } else throw new Error('This sample role cannot change an application.');
  application.status = target;
  application.history.push({
    status: target,
    at: now,
    actor: actor.role === 'teacher' ? 'Sample teacher' : 'Sample representative',
  });
  return application;
}
