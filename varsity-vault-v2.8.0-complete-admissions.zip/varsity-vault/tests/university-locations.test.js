import test from 'node:test';
import assert from 'node:assert/strict';
import { LocalStore } from '../server/storage.js';
import { ensureReferenceData } from '../server/reference-data.js';
import {
  universityLocationDirectory,
  universityLocations,
} from '../server/university-locations.js';
import {
  learnerAvailability,
  learnerAssessmentStatus,
} from '../shared/scoring/learner-display.js';
import { offeringAvailability } from '../shared/scoring/programme.js';

test('all 26 universities gain valid city links; aliases, existing rows and people are preserved; reruns add nothing', async () => {
  const store = new LocalStore(':memory:');
  try {
    await store.tx(async (db) => {
      for (const entry of universityLocationDirectory)
        await db.insert('UNIVERSITIES', {
          UNIVERSITY_NAME:
            entry.host === 'wsu.ac.za'
              ? 'iYunivesithi Walter Sisulu'
              : entry.name,
          WEBSITE: 'https://www.' + entry.host,
          PROVINCE_ID: 1,
        });
      await db.insert('PROVINCES', { PROVINCE_NAME: 'Eastern Cape' });
      await db.insert('PROVINCES', { PROVINCE_NAME: 'Gauteng' });
      await db.insert('CITIES', { CITY_NAME: 'kuGompo', PROVINCE_ID: 1 });
      await db.insert('CITIES', { CITY_NAME: 'Mahikeng', PROVINCE_ID: 2 }); // Existing bad geography must not be overwritten.
      await db.insert('ADDRESS_TYPES', { ADDRESS_TYPE_NAME: 'Campus' });
      await db.insert('UNIVERSITY_ADDRESSES', {
        UNIVERSITY_ID: 26,
        ADDRESS_TYPE_ID: 1,
        CITY_ID: 1,
        STREET_NAME: 'Existing address',
      });
      await db.insert('PERSONS', {
        FIRST_NAME: 'Existing',
        LAST_NAME: 'Learner',
        PERSON_TYPE: 'L',
      });
      await db.insert('security.Accounts', {
        ACCOUNT_ID: 'existing',
        PERSON_ID: 1,
        USERNAME: 'existing@example.test',
        PASSWORD_HASH: 'unchanged',
        DISABLED: false,
      });
    });
    const before = await store.tx(async (db) => ({
      people: await db.list('PERSONS'),
      accounts: await db.list('security.Accounts'),
    }));
    const first = await ensureReferenceData(store);
    assert.equal(first.locations.universitiesMatched, 26);
    assert.ok(first.locations.linksAdded >= 26);
    await store.tx(async (db) => {
      const universities = await db.list('UNIVERSITIES'),
        addresses = await db.list('UNIVERSITY_ADDRESSES'),
        cities = await db.list('CITIES'),
        provinces = await db.list('PROVINCES');
      for (const u of universities) {
        const locations = universityLocations(u, addresses, cities, provinces);
        assert.ok(locations.length >= 1, u.UNIVERSITY_NAME);
        assert.ok(locations.every((a) => a.CITY_NAME && a.PROVINCE_NAME));
      }
      assert.equal(
        addresses.filter((a) => a.UNIVERSITY_ID === 26 && a.CITY_ID === 1)
          .length,
        1,
      );
      assert.equal(
        addresses.find((a) => a.ADDRESS_ID === 1).STREET_NAME,
        'Existing address',
      );
      assert.equal(cities.find((c) => c.CITY_ID === 2).PROVINCE_ID, 2);
      const nwu = universityLocations(
        universities[5],
        addresses,
        cities,
        provinces,
      );
      assert.deepEqual(
        new Set(nwu.map((l) => l.PROVINCE_NAME)),
        new Set(['North West', 'Gauteng']),
      );
      assert.deepEqual(await db.list('PERSONS'), before.people);
      assert.deepEqual(await db.list('security.Accounts'), before.accounts);
    });
    const second = await ensureReferenceData(store);
    assert.equal(second.locations.linksAdded, 0);
    assert.equal(second.locations.citiesAdded, 0);
  } finally {
    await store.close();
  }
});

test('ambiguous institutions roll back instead of linking an arbitrary duplicate', async () => {
  const store = new LocalStore(':memory:');
  try {
    await store.tx(async (db) => {
      await db.insert('UNIVERSITIES', {
        UNIVERSITY_NAME: 'Walter Sisulu University',
        WEBSITE: 'https://www.wsu.ac.za',
        PROVINCE_ID: 1,
      });
      await db.insert('UNIVERSITIES', {
        UNIVERSITY_NAME: 'iYunivesithi Walter Sisulu',
        WEBSITE: 'https://wsu.ac.za',
        PROVINCE_ID: 1,
      });
    });
    await assert.rejects(ensureReferenceData(store), /Duplicate university/);
    assert.equal(
      (await store.tx((db) => db.list('UNIVERSITY_ADDRESSES'))).length,
      0,
    );
  } finally {
    await store.close();
  }
});

test('learner wording hides internal qualification review without changing admission gates', () => {
  const config = { status: 'pending', active: true, intake: 2028 };
  assert.equal(
    offeringAvailability(config, null),
    'Requirements pending verification',
  );
  assert.doesNotMatch(
    learnerAvailability(offeringAvailability(config, null)),
    /pending|verif/i,
  );
  assert.doesNotMatch(
    learnerAssessmentStatus('Programme requirements pending verification'),
    /pending|verif/i,
  );
  assert.equal(learnerAvailability('Open'), 'Applications open');
  assert.equal(
    learnerAssessmentStatus('Results incomplete'),
    'Results incomplete',
  );
});
