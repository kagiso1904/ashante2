import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { Script } from 'node:vm';
import { JSDOM } from 'jsdom';
import { assessSubjects } from '../shared/scoring/subjects.js';
import { isRequiredBeforeProvisional } from '../shared/review/documents.js';
import {
  learnerAvailability,
  learnerAssessmentStatus,
} from '../shared/scoring/learner-display.js';
const config = {
  intake: 2028,
  status: 'pending',
  minScore: 28,
  minEnglish: 50,
  minMath: 40,
  requiredCodes: ['MATH'],
  subjectMinimums: { MATH: 40 },
  subjectGroups: [{ group: 1, code: 'PHSC', minimum: 50 }],
  requiredDocumentIds: [],
  active: true,
  source: 'https://www.nwu.ac.za/',
  scoring: null,
  openingDate: null,
};
const offering = {
  UNI_QUAL_ID: 1,
  UNIVERSITY_ID: 1,
  APPLICATION_CLOSING_DATE: null,
  qualification: 'Bachelor of Science',
  university: 'North-West University',
  program: 'Natural Sciences',
  config,
  availability: 'Requirements pending verification',
};
const catalog = {
  universities: [
    {
      UNIVERSITY_ID: 1,
      UNIVERSITY_NAME: 'North-West University',
      WEBSITE: 'https://www.nwu.ac.za/',
      PROVINCE_ID: 1,
      CITY_ID: 1,
      LOCATIONS: [
        {
          CITY_ID: 1,
          CITY_NAME: 'Mahikeng',
          PROVINCE_ID: 1,
          PROVINCE_NAME: 'North West',
          STREET_NAME: null,
        },
        {
          CITY_ID: 2,
          CITY_NAME: 'Vanderbijlpark',
          PROVINCE_ID: 2,
          PROVINCE_NAME: 'Gauteng',
          STREET_NAME: null,
        },
      ],
    },
  ],
  cities: [
    { CITY_ID: 1, CITY_NAME: 'Mahikeng', PROVINCE_ID: 1 },
    { CITY_ID: 2, CITY_NAME: 'Vanderbijlpark', PROVINCE_ID: 2 },
  ],
  provinces: [
    { PROVINCE_ID: 1, PROVINCE_NAME: 'North West' },
    { PROVINCE_ID: 2, PROVINCE_NAME: 'Gauteng' },
  ],
  subjects: [
    {
      SUBJECT_ID: 1,
      SUBJECT_CODE: 'MATH',
      SUBJECT_NAME: 'Mathematics',
      SUBJECT_CATEGORY: 'MATHEMATICS',
    },
    {
      SUBJECT_ID: 2,
      SUBJECT_CODE: 'PHSC',
      SUBJECT_NAME: 'Physical Sciences',
      SUBJECT_CATEGORY: 'ELECTIVE',
    },
  ],
  examTypes: [{ EXAM_TYPE_ID: 1, EXAM_TYPE_NAME: 'Grade 11 Final' }],
  documentTypes: [
    {
      DOCUMENT_TYPE_ID: 1,
      DOCUMENT_TYPE_NAME: 'Grade 11 Final Report',
      IS_MANDATORY: true,
      IS_LOCKED_UNTIL_FINAL: false,
    },
    {
      DOCUMENT_TYPE_ID: 2,
      DOCUMENT_TYPE_NAME: 'Final NSC Certificate',
      IS_MANDATORY: false,
      IS_LOCKED_UNTIL_FINAL: true,
    },
  ],
  studyModes: [{ STUDY_MODE_ID: 1, STUDY_MODE_NAME: 'Full-time' }],
  verificationStatuses: [],
  schools: [],
  achievementLevels: [],
  applicationStatuses: [],
  actions: [],
};

function ui(page, search = '', role = 'learner', brochure = true) {
  const dom = new JSDOM(
    '<!doctype html><body data-page="' +
      page +
      '"><main id="main"></main></body>',
    {
      url: 'https://example.test/' + role + '/' + page + '.html' + search,
      runScripts: 'outside-only',
    },
  );
  const context = dom.getInternalVMContext();
  Object.assign(context, {
    assessSubjects,
    isRequiredBeforeProvisional,
    learnerAvailability,
    learnerAssessmentStatus,
  });
  context.api = async (path) => {
    const p = path.split('?')[0];
    if (p === '/api/offerings') return { offerings: [offering] };
    if (p === '/api/prospectuses')
      return {
        prospectuses: brochure
          ? [
              {
                PROSPECTUS_ID: 1,
                UNIVERSITY_ID: 1,
                PROSPECTUS_FILENAME: 'NWU Prospectus.pdf',
                PROSPECTUS_DATE: '2026-10-28',
              },
            ]
          : [],
      };
    if (p === '/api/results/summary') return { examTypeIds: [] };
    if (p === '/api/documents') return { documents: [] };
    if (p === '/api/applications') return { applications: [] };
    if (p === '/api/results') return { rows: [] };
    if (p === '/api/offerings/1/requirements')
      return {
        total: 42,
        contributions: [],
        eligible: false,
        status: 'Programme requirements pending verification',
        issues: [],
        metric: 'APS',
        offering,
      };
    throw Error('Unexpected API: ' + path);
  };
  let source = readFileSync(
    new URL('../public/assets/js/full.js', import.meta.url),
    'utf8',
  )
    .replace(/^import[\s\S]*?;\s*/gm, '')
    .replace(
      'export async function startFullApp',
      'async function startFullApp',
    );
  source +=
    '\n globalThis.uiTest={directory,universityProfile,requirements,qualificationInformation,selectableLearnerSubjects,set(c,u){catalog=c;user=u;}};';
  new Script(source).runInContext(context);
  context.uiTest.set(catalog, { role, personId: 1 });
  return { dom, document: dom.window.document, view: context.uiTest };
}
test('learner directory: all campus cities, cross-province and qualification search, profile links, no verification badges', async () => {
  const { dom, document, view } = ui('universities');
  try {
    await view.directory();
    assert.doesNotMatch(
      document.querySelector('#main').textContent,
      /pending|verified|verification/i,
    );
    assert.match(
      document.querySelector('#directory-grid').textContent,
      /Mahikeng, Vanderbijlpark/,
    );
    assert.equal(
      document
        .querySelector('a[href="/learner/university.html?id=1"]')
        .textContent.trim(),
      'North-West University',
    );
    document.querySelector('#province').value = '2';
    document
      .querySelector('#province')
      .dispatchEvent(new dom.window.Event('change'));
    assert.match(
      document.querySelector('#directory-grid').textContent,
      /North-West University/,
    );
    document.querySelector('#search').value = 'Bachelor of Science';
    document
      .querySelector('#search')
      .dispatchEvent(new dom.window.Event('input'));
    assert.match(
      document.querySelector('#directory-grid').textContent,
      /North-West University/,
    );
    document.querySelector('#search').value = 'does not exist';
    document
      .querySelector('#search')
      .dispatchEvent(new dom.window.Event('input'));
    assert.match(
      document.querySelector('#directory-grid').textContent,
      /No records yet/,
    );
  } finally {
    dom.window.close();
  }
});
test('university profile exposes campus provinces, safe website, downloads and qualification details; handles no prospectus', async () => {
  for (const brochure of [true, false]) {
    const { dom, document, view } = ui(
      'university',
      '?id=1',
      'learner',
      brochure,
    );
    try {
      await view.universityProfile();
      const text = document.querySelector('#main').textContent;
      assert.match(text, /Mahikeng/);
      assert.match(text, /Vanderbijlpark/);
      assert.doesNotMatch(text, /pending|verified|verification/i);
      assert.equal(
        document.querySelector('a[target="_blank"]').href,
        'https://www.nwu.ac.za/',
      );
      if (brochure)
        assert.ok(
          document.querySelector('a[href="/api/prospectuses/1/download"]'),
        );
      else assert.match(text, /No prospectus file/);
      assert.ok(
        document.querySelector(
          'a[href="/learner/requirements.html?offeringId=1"]',
        ),
      );
    } finally {
      dom.window.close();
    }
  }
});
test('direct qualification link opens details immediately, includes all requirement types, and preserves application gate', async () => {
  const { dom, document, view } = ui('requirements', '?offeringId=1');
  try {
    await view.requirements();
    const content = document.querySelector('#requirements-content'),
      text = content.textContent;
    assert.equal(content.hidden, false);
    assert.doesNotMatch(
      text,
      /pending verification|requirements verified|verified programme/i,
    );
    for (const expected of [
      'Bachelor of Science',
      '28 / 42',
      '50%',
      '40%',
      'Physical Sciences',
      'Mathematics',
      'Supporting documents',
      'Grade 11 Final Report',
      'Final NSC Certificate',
      'Not published',
    ])
      assert.ok(text.includes(expected), expected);
    assert.equal(document.querySelector('#apply'), null);
    assert.doesNotMatch(
      document.querySelector('#offering').textContent,
      /verified|pending|verification/i,
    );
    assert.ok(
      document.querySelector(
        '.qualification-information a[href="https://www.nwu.ac.za/"]',
      ),
    );
  } finally {
    dom.window.close();
  }
});
test('staff programme review retains verification status', async () => {
  const { dom, document, view } = ui('policies', '', 'admin');
  try {
    await view.directory();
    assert.match(document.querySelector('#main').textContent, /pending/);
  } finally {
    dom.window.close();
  }
});

test('every imported qualification renders score, dates, subject routes, scoring details and document checklist without unpublished cells', async () => {
  const profiles = JSON.parse(
    readFileSync(
      new URL('../data/admissions-complete.json', import.meta.url),
      'utf8',
    ),
  );
  const definitions = JSON.parse(
    readFileSync(
      new URL('../data/admission-subjects.json', import.meta.url),
      'utf8',
    ),
  );
  const full = structuredClone(catalog);
  full.subjects = Object.entries(definitions).map(([SUBJECT_CODE, v], i) => ({
    SUBJECT_ID: i + 1,
    SUBJECT_CODE,
    SUBJECT_NAME: v.name,
    SUBJECT_CATEGORY: v.category,
  }));
  const names = [
    ...new Set(profiles.flatMap((p) => p.config.requiredDocumentNames)),
  ];
  full.documentTypes = names.map((DOCUMENT_TYPE_NAME, i) => ({
    DOCUMENT_TYPE_ID: i + 1,
    DOCUMENT_TYPE_NAME,
    IS_MANDATORY: false,
    IS_LOCKED_UNTIL_FINAL: false,
  }));
  const { dom, document, view } = ui('requirements');
  try {
    view.set(full, { role: 'learner', personId: 1 });
    for (const profile of profiles) {
      const cfg = {
        ...profile.config,
        requiredDocumentIds: profile.config.requiredDocumentNames.map(
          (n) => names.indexOf(n) + 1,
        ),
      };
      const html = view.qualificationInformation({
        UNI_QUAL_ID: 1,
        UNIVERSITY_ID: 1,
        university: profile.university,
        qualification: profile.qualification,
        config: cfg,
        APPLICATION_CLOSING_DATE: cfg.closingDate,
        availability: 'Open',
      });
      const container = document.createElement('section');
      container.innerHTML = html;
      const text = container.textContent;
      for (const expected of [
        String(cfg.minScore),
        'Alternative admission routes',
        'Supporting documents',
        'How the admission score is calculated',
        cfg.closingDate,
      ])
        assert.ok(
          text.includes(expected),
          profile.qualification + ': ' + expected,
        );
      assert.doesNotMatch(
        text,
        /Not published|\bundefined\b|\bNaN\b|pending verification|requirements verified/i,
        profile.qualification,
      );
      assert.ok(container.querySelectorAll('.admission-route').length >= 1);
    }
  } finally {
    dom.window.close();
  }
});

test('national subjects work for a new school without duplicate subject choices or remapping existing school records', () => {
  const { dom, view } = ui('results');
  try {
    const full = structuredClone(catalog);
    full.subjects = [
      {
        SUBJECT_ID: 1,
        SUBJECT_CODE: 'MATH',
        SUBJECT_NAME: 'Mathematics',
        SCHOOL_ID: 1,
      },
      {
        SUBJECT_ID: 2,
        SUBJECT_CODE: 'MATH',
        SUBJECT_NAME: 'Mathematics',
        SCHOOL_ID: null,
      },
      {
        SUBJECT_ID: 3,
        SUBJECT_CODE: 'ENGHL',
        SUBJECT_NAME: 'English Home Language',
        SCHOOL_ID: null,
      },
    ];
    view.set(full, { role: 'learner', personId: 1, schoolId: 1 });
    assert.equal(
      view.selectableLearnerSubjects([]).find((s) => s.SUBJECT_CODE === 'MATH')
        .SUBJECT_ID,
      1,
    );
    assert.equal(
      view.selectableLearnerSubjects([{ SUBJECT_ID: 1, SUBJECT_CODE: 'MATH' }])
        .length,
      1,
    );
    view.set(full, { role: 'learner', personId: 2, schoolId: 4 });
    assert.equal(
      view.selectableLearnerSubjects([]).find((s) => s.SUBJECT_CODE === 'MATH')
        .SUBJECT_ID,
      2,
    );
  } finally {
    dom.window.close();
  }
});
