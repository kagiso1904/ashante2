import test from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { LocalStore } from '../server/storage.js';
import { createFullApplication } from '../server/app.js';
import { ensureReferenceData } from '../server/reference-data.js';

test('HTTP catalog exposes all linked campus cities and retains first-address compatibility', async () => {
  const store = new LocalStore(':memory:');
  let server;
  try {
    await store.tx(async (db) => {
      await db.insert('UNIVERSITIES', {
        UNIVERSITY_NAME: 'North-West University',
        WEBSITE: 'https://www.nwu.ac.za/',
        PROVINCE_ID: 1,
      });
    });
    await ensureReferenceData(store);
    server = createFullApplication(store).listen(0, '127.0.0.1');
    await once(server, 'listening');
    const origin = 'http://127.0.0.1:' + server.address().port;
    const catalogResponse = await fetch(origin + '/api/catalog');
    assert.equal(catalogResponse.status, 200);
    const { universities } = await catalogResponse.json();
    assert.equal(universities[0].LOCATIONS.length, 3);
    assert.deepEqual(
      new Set(universities[0].LOCATIONS.map((a) => a.CITY_NAME)),
      new Set(['Potchefstroom', 'Mahikeng', 'Vanderbijlpark']),
    );
    assert.equal(universities[0].CITY_ID, universities[0].LOCATIONS[0].CITY_ID);
    assert.ok(universities[0].LOCATIONS.every((a) => a.PROVINCE_NAME));
    const publicDirectory = await (
      await fetch(origin + '/api/universities')
    ).json();
    assert.equal(publicDirectory.universities[0].cities.length, 3);
    assert.equal(
      (await fetch(origin + '/learner/university.html?id=1')).status,
      200,
    );
  } finally {
    if (server) await new Promise((resolve) => server.close(resolve));
    await store.close();
  }
});
