import test from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { LocalStore } from '../server/storage.js';
import { createFullApplication } from '../server/app.js';
import { digest } from '../server/security.js';

async function fixture() {
  const previousUrl = process.env.PUBLIC_APP_URL;
  process.env.PUBLIC_APP_URL = 'https://example.test';
  const store = new LocalStore(':memory:');
  await store.tx(async (db) => {
    await db.insert('SCHOOLS', {
      SCHOOL_NAME: 'Presentation School',
      EMIS_NUMBER: 'PRES-001',
      CITY_ID: 1,
      PROVINCE_ID: 1,
    });
    const p = await db.createPerson(
      {
        FIRST_NAME: 'Admin',
        LAST_NAME: 'Presenter',
        EMAIL: 'admin@example.test',
        USERNAME: 'admin@example.test',
        PHONE_NUMBER: null,
        SA_ID_NUMBER: null,
      },
      { type: 'A', schoolId: 1 },
    );
    await db.insert('security.Accounts', {
      ACCOUNT_ID: 'admin-account',
      PERSON_ID: p.PERSON_ID,
      USERNAME: 'admin@example.test',
      PASSWORD_HASH: 'unused',
      DISABLED: false,
    });
    await db.insert('security.Sessions', {
      TOKEN_HASH: digest('test-session'),
      PERSON_ID: p.PERSON_ID,
      CSRF: 'test-csrf',
      EXPIRES: new Date(Date.now() + 3600000).toISOString(),
    });
  });
  let received;
  const email = new Promise((resolve) => {
    received = resolve;
  });
  const server = createFullApplication(store, {
    sendEmail: async (message) => received(message),
  }).listen(0, '127.0.0.1');
  await once(server, 'listening');
  const base = 'http://127.0.0.1:' + server.address().port;
  const request = async (path, method = 'GET', body, authenticated = true) => {
    const response = await fetch(base + '/api' + path, {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...(typeof authenticated === 'object'
          ? authenticated
          : authenticated
            ? { Cookie: 'vv_session=test-session', 'X-CSRF-Token': 'test-csrf' }
            : {}),
      },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    });
    return {
      status: response.status,
      body: await response.json(),
      cookie: response.headers.get('set-cookie'),
    };
  };
  return {
    store,
    server,
    request,
    email,
    close: async () => {
      await new Promise((resolve) => server.close(resolve));
      await store.close();
      if (previousUrl === undefined) delete process.env.PUBLIC_APP_URL;
      else process.env.PUBLIC_APP_URL = previousUrl;
    },
  };
}

test('account registration rejects invalid email and short passwords; creates person/subtype/hashed account and verifies email; duplicate registration is rejected', async () => {
  const f = await fixture();
  try {
    const details = {
      firstName: 'Lerato',
      lastName: 'Nkosi',
      email: 'presenter@example.test',
      schoolId: 1,
      password: 'PresentationPass123!',
      saIdNumber: '',
    };
    assert.equal(
      (
        await f.request(
          '/auth/register',
          'POST',
          { ...details, email: 'bad-email' },
          false,
        )
      ).status,
      400,
    );
    assert.equal(
      (
        await f.request(
          '/auth/register',
          'POST',
          { ...details, password: 'short' },
          false,
        )
      ).status,
      400,
    );
    assert.equal((await f.store.tx((db) => db.list('PERSONS'))).length, 1);
    const saved = await f.request('/auth/register', 'POST', details, false);
    assert.equal(saved.status, 200, JSON.stringify(saved.body));
    const account = (
      await f.store.tx((db) =>
        db.list('security.Accounts', { USERNAME: details.email }),
      )
    )[0];
    assert.ok(account);
    assert.notEqual(account.PASSWORD_HASH, details.password);
    assert.equal(
      (
        await f.store.tx((db) =>
          db.list('LEARNERS', { PERSON_ID: account.PERSON_ID }),
        )
      )[0].PERSON_ID,
      account.PERSON_ID,
    );
    assert.equal(
      (await f.request('/auth/register', 'POST', details, false)).status,
      409,
    );
    const message = await f.email;
    const url = message.text.match(
      /https?:\/\/\S*verify-email\.html\?token=\S+/,
    )?.[0];
    assert.ok(url, 'Email contains verification link');
    const verified = await f.request(
      '/auth/email/verify',
      'POST',
      { token: new URL(url).searchParams.get('token') },
      false,
    );
    assert.equal(verified.status, 200, JSON.stringify(verified.body));
    assert.ok(
      (
        await f.store.tx((db) =>
          db.list('security.EmailVerifications', {
            PERSON_ID: account.PERSON_ID,
          }),
        )
      )[0].VERIFIED_AT,
    );
    const logged = await f.request(
      '/auth/login',
      'POST',
      { username: details.email, password: details.password },
      false,
    );
    assert.equal(logged.status, 200, JSON.stringify(logged.body));
    const headers = {
      Cookie: logged.cookie.split(';')[0],
      'X-CSRF-Token': logged.body.csrf,
    };
    await f.store.tx(async (db) => {
      await db.insert('EXAM_TYPES', { EXAM_TYPE_NAME: 'Grade 11 Final' });
      await db.insert('VERIFICATION_STATUSES', {
        VERIFICATION_STATUS_NAME: 'Pending',
      });
      await db.insert('VERIFICATION_STATUSES', {
        VERIFICATION_STATUS_NAME: 'Verified',
      });
      await db.insert('SUBJECTS', {
        SUBJECT_CODE: 'MATH',
        SUBJECT_NAME: 'Mathematics',
        SUBJECT_CATEGORY: 'MATHEMATICS',
        SCHOOL_ID: null,
      });
    });
    const current = await f.request(
      '/results?examTypeId=1',
      'GET',
      undefined,
      headers,
    );
    const invalid = await f.request(
      '/results',
      'PUT',
      {
        examTypeId: 1,
        expectedVersion: current.body.resultVersion,
        rows: [{ subjectId: 1, percentage: 150 }],
      },
      headers,
    );
    assert.equal(invalid.status, 400, JSON.stringify(invalid.body));
    assert.equal(
      (await f.store.tx((db) => db.list('LEARNER_RESULTS'))).length,
      0,
    );
    const valid = await f.request(
      '/results',
      'PUT',
      {
        examTypeId: 1,
        expectedVersion: current.body.resultVersion,
        rows: [{ subjectId: 1, percentage: 75 }],
      },
      headers,
    );
    assert.equal(valid.status, 200, JSON.stringify(valid.body));
    const readBack = await f.request(
      '/results?examTypeId=1',
      'GET',
      undefined,
      headers,
    );
    assert.equal(readBack.body.rows[0].PERCENTAGE, 75);
  } finally {
    await f.close();
  }
});

test('admin PROGRAMS CRUD persists each operation and rejects blank names, duplicates, used-record deletion and unauthenticated writes', async () => {
  const f = await fixture();
  try {
    assert.equal(
      (
        await f.request('/admin/records/PROGRAMS', 'POST', {
          PROGRAM_NAME: ' ',
        })
      ).status,
      400,
    );
    assert.equal(
      (
        await f.request(
          '/admin/records/PROGRAMS',
          'POST',
          { PROGRAM_NAME: 'Unauthorised' },
          false,
        )
      ).status,
      401,
    );
    const created = await f.request('/admin/records/PROGRAMS', 'POST', {
      PROGRAM_NAME: 'Presentation Programme',
    });
    assert.equal(created.status, 200, JSON.stringify(created.body));
    const id = created.body.row.PROGRAM_ID;
    const read = await f.request('/admin/records/PROGRAMS');
    assert.ok(read.body.rows.some((r) => r.PROGRAM_ID === id));
    assert.equal(
      (
        await f.request('/admin/records/PROGRAMS', 'POST', {
          PROGRAM_NAME: 'Presentation Programme',
        })
      ).status,
      409,
    );
    assert.equal(
      (
        await f.request('/admin/records/PROGRAMS/' + id, 'PATCH', {
          PROGRAM_NAME: 'Presentation Programme Updated',
        })
      ).status,
      200,
    );
    assert.equal(
      (await f.store.tx((db) => db.list('PROGRAMS', { PROGRAM_ID: id })))[0]
        .PROGRAM_NAME,
      'Presentation Programme Updated',
    );
    const q = await f.request('/admin/records/QUALIFICATIONS', 'POST', {
      QUAL_NAME: 'Presentation Qualification',
      PROGRAM_ID: id,
    });
    assert.equal(q.status, 200);
    assert.equal(
      (await f.request('/admin/records/PROGRAMS/' + id, 'DELETE')).status,
      409,
    );
    assert.equal(
      (
        await f.request(
          '/admin/records/QUALIFICATIONS/' + q.body.row.QUAL_ID,
          'DELETE',
        )
      ).status,
      200,
    );
    assert.equal(
      (await f.request('/admin/records/PROGRAMS/' + id, 'DELETE')).status,
      200,
    );
    assert.equal(
      (await f.store.tx((db) => db.list('PROGRAMS', { PROGRAM_ID: id })))
        .length,
      0,
    );
  } finally {
    await f.close();
  }
});
