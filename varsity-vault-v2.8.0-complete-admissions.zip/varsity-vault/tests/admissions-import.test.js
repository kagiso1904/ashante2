import test from 'node:test';
import assert from 'node:assert/strict';
import { LocalStore } from '../server/storage.js';
import {
  admissionProfiles,
  importAdmissionProfiles,
} from '../server/admissions-import.js';
import { universityLocationDirectory } from '../server/university-locations.js';
import { assessSubjects } from '../shared/scoring/subjects.js';
import {
  evaluateConfiguredScoring,
  evaluateAdmissionRoutes,
} from '../shared/scoring/policy-engine.js';
import { offeringAvailability } from '../shared/scoring/programme.js';

async function catalogue(store) {
  await store.tx(async (db) => {
    const p = await db.insert('PROGRAMS', {
      PROGRAM_NAME: 'Existing category',
    });
    const universities = new Map(),
      qualifications = new Map();
    for (const row of admissionProfiles) {
      if (!universities.has(row.university)) {
        const dir = universityLocationDirectory.find(
          (u) => u.name === row.university,
        );
        universities.set(
          row.university,
          await db.insert('UNIVERSITIES', {
            UNIVERSITY_NAME:
              row.university === 'Walter Sisulu University'
                ? 'iYunivesithi Walter Sisulu'
                : row.university,
            WEBSITE: 'https://www.' + dir.host,
            PROVINCE_ID: 1,
          }),
        );
      }
      if (!qualifications.has(row.qualification))
        qualifications.set(
          row.qualification,
          await db.insert('QUALIFICATIONS', {
            QUAL_NAME: row.qualification,
            PROGRAM_ID: p.PROGRAM_ID,
          }),
        );
      await db.insert('UNI_QUALIFICATIONS', {
        UNIVERSITY_ID: universities.get(row.university).UNIVERSITY_ID,
        QUAL_ID: qualifications.get(row.qualification).QUAL_ID,
        APPLICATION_CLOSING_DATE: null,
      });
    }
    await db.insert('PERSONS', {
      FIRST_NAME: 'Keep',
      LAST_NAME: 'Existing',
      PERSON_TYPE: 'L',
    });
    await db.insert('security.Accounts', {
      ACCOUNT_ID: 'keep',
      PERSON_ID: 1,
      USERNAME: 'keep@example.test',
      PASSWORD_HASH: 'unchanged',
      DISABLED: false,
    });
  });
}
test('all 260 required profiles and existing WSU ICT receive scores, subject rules, documents, windows and matching legacy requirements without touching users', async () => {
  const store = new LocalStore(':memory:');
  try {
    await catalogue(store);
    assert.deepEqual(await importAdmissionProfiles(store), {
      catalogueProfiles: 260,
      existingAdditionalProfiles: 1,
      totalUpdated: 261,
    });
    const saved = await store.tx((db) => db.list('security.Policies'));
    const requirements = await store.tx((db) =>
      db.list('QUALIFICATION_REQUIREMENTS'),
    );
    assert.equal(saved.length, 261);
    assert.equal(requirements.length, 261);
    for (const row of saved) {
      const c = JSON.parse(row.PAYLOAD);
      assert.ok(Number.isFinite(c.minScore));
      assert.ok(c.admissionRoutes.routes.length);
      assert.ok(c.requiredDocumentIds.length >= 2);
      assert.equal(c.intake, 2028);
      assert.equal(
        offeringAvailability(
          c,
          c.closingDate,
          new Date('2026-10-28T12:00:00Z'),
        ),
        'Open',
      );
      assert.ok(
        requirements.some(
          (r) =>
            r.UNI_QUAL_ID === row.UNI_QUAL_ID && r.MIN_APS_SCORE === c.minScore,
        ),
      );
    }
    assert.equal((await store.tx((db) => db.list('PERSONS'))).length, 1);
    assert.equal(
      (await store.tx((db) => db.list('security.Accounts')))[0].PASSWORD_HASH,
      'unchanged',
    );
    await importAdmissionProfiles(store);
    assert.deepEqual(
      await store.tx((db) => db.list('security.Policies')),
      saved,
    );
    assert.equal(
      (await store.tx((db) => db.list('QUALIFICATION_REQUIREMENTS'))).length,
      261,
    );
    const empty = new LocalStore(':memory:');
    try {
      await assert.rejects(
        importAdmissionProfiles(empty),
        /Missing catalogue offering/,
      );
      assert.equal((await empty.tx((db) => db.list('SUBJECTS'))).length, 0);
    } finally {
      await empty.close();
    }
  } finally {
    await store.close();
  }
});

test('imported scoring and route configurations evaluate without malformed-rule errors', () => {
  const codes = [
    'ENGHL',
    'XHOFAL',
    'MATH',
    'LO',
    'PHSC',
    'LFSC',
    'ACCN',
    'BUSS',
    'ECON',
    'GEOG',
    'HIST',
    'AGRI',
    'CONS',
    'HOSP',
    'TOUR',
    'TSCI',
    'TMATH',
    'MLIT',
    'INFT',
  ];
  const marks = codes.map((code, i) => ({ code, id: i + 1, mark: 95 }));
  for (const row of admissionProfiles) {
    const c = row.config;
    const score = evaluateConfiguredScoring(
      c.scoring,
      marks,
      c.subjectGroups,
      3,
    );
    assert.notEqual(
      score.status,
      'CONFIG_ERROR',
      row.qualification + ': ' + score.message,
    );
    const routes = evaluateAdmissionRoutes(
      c.admissionRoutes,
      marks,
      c.minScore,
      'Grade 11 Final',
    );
    assert.notEqual(
      routes.status,
      'CONFIG_ERROR',
      row.qualification + ': ' + routes.message,
    );
  }
});

test('WSU maths / maths-literacy routes and programme-specific English thresholds affect eligibility', () => {
  const profile = admissionProfiles.find((r) => r.optional).config;
  const marks = (math = 'MATH', mathMark = 75, english = 75) =>
    [
      ['ENGHL', 'HOME_LANGUAGE', english],
      ['XHOFAL', 'FIRST_ADDITIONAL_LANGUAGE', 75],
      [
        math,
        math === 'MLIT' ? 'MATHEMATICAL_LITERACY' : 'MATHEMATICS',
        mathMark,
      ],
      ['LO', 'LIFE_ORIENTATION', 75],
      ['PHSC', 'ELECTIVE', 75],
      ['LFSC', 'ELECTIVE', 75],
      ['ACCN', 'ELECTIVE', 75],
    ].map(([SUBJECT_CODE, SUBJECT_CATEGORY, PERCENTAGE], i) => ({
      SUBJECT_ID: i + 1,
      SUBJECT_CODE,
      SUBJECT_CATEGORY,
      PERCENTAGE,
    }));
  assert.equal(assessSubjects(marks(), null, profile).eligible, true);
  assert.equal(
    assessSubjects(marks('MATH', 75, 40), null, profile).eligible,
    false,
  );
  assert.equal(
    assessSubjects(marks('MLIT', 50), null, profile).eligible,
    false,
  );
  const lit = assessSubjects(marks('MLIT', 65), null, profile);
  assert.equal(lit.eligible, true);
  assert.equal(lit.requiredScore, 24);
});

test('conditional school bonus is excluded when school context is unavailable while base scoring remains usable', () => {
  const config = admissionProfiles.find((p) =>
    p.university.includes('Nelson Mandela'),
  ).config;
  const records = [
    ['ENGHL', 'HOME_LANGUAGE'],
    ['XHOFAL', 'FIRST_ADDITIONAL_LANGUAGE'],
    ['MATH', 'MATHEMATICS'],
    ['LO', 'LIFE_ORIENTATION'],
    ['PHSC', 'ELECTIVE'],
    ['LFSC', 'ELECTIVE'],
    ['ACCN', 'ELECTIVE'],
  ].map(([SUBJECT_CODE, SUBJECT_CATEGORY], i) => ({
    SUBJECT_ID: i + 1,
    SUBJECT_CODE,
    SUBJECT_CATEGORY,
    PERCENTAGE: 75,
  }));
  const report = assessSubjects(records, null, config);
  assert.equal(report.total, 450);
  assert.equal(report.scoreBonus, 0);
  assert.match(report.contextNote, /quintile/);
  assert.equal(report.eligible, true);
});
