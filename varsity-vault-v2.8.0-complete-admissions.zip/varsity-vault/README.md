# Varsity Vault 2.8.0

This release fills the 260-qualification catalogue with entry scores, institutional scoring methods, common subject minimums, alternative admission routes, document checklists, selection notes and application windows. It also updates the existing WSU ICT Applications Development profile shown in the learner screenshot, if that record is present. The underlying academic ERD, tables, columns and keys are unchanged.

## Install on the existing SQL Server app

1. Stop the app with Ctrl+C and back up VARSITYVAULT2 and VarsityVaultSecurity.
2. Replace the project code with this release. Keep your existing `.env`, `.data` and `node_modules`. No new production dependency is required.
3. Run `npm run admissions:load` from the project folder. Confirm it reports SQL Server mode and **catalogueProfiles: 260**. A further existing WSU ICT record may make **totalUpdated: 261**.
4. Run `npm start`, refresh with Ctrl+Shift+R, and open Universities -> University details -> View requirements.
5. Use `docs/Presentation_Point_5_6_CRUD.md` for the recording and `database/09_presentation_evidence.sql` for read-only SSMS proof.

The import runs in one transaction, matches existing university/qualification names and preserves identifiers. It does not add or change people, accounts, sessions, marks, enrolments, uploaded documents, schools or applications. It adds national subject options where necessary so learners at different schools can enter a complete NSC subject set, while keeping existing school-specific subject IDs. Repeating the import does not duplicate policies or requirement rows.

If a required catalogue offering is missing or ambiguous, the import aborts without applying partial updates. Load `database/06_load_reference_data_no_users.sql` first only if the 260-entry catalogue is not already installed. The import is an explicit operator action; normal app startup does not overwrite admission profiles.

## What the data represents

- The main academic rules come from your existing 2027 admissions source set and Oracle exports. Common subject requirements are combined with the exported alternative routes and institution-specific scoring policies.
- The ten UMP profiles were rebuilt from official programme pages. These include route-specific Mathematics/Mathematical Literacy scores, required sciences or other subjects, and the revised Hospitality curriculum. The current Agriculture page gives APS 32, rather than the older brochure's 30.
- Wits subject requirements are included; the Civil Engineering export's conflicting 34-point note was corrected to APS 42, English 60%, Mathematics 60% and Physical Sciences 60% using its official course page.
- Twenty profiles whose original source work did not establish a published minimum retain the existing project minimum from the supplied export. They are recorded as `requirementsBasis: existing_project_profile`; the learner page identifies these as application-configured minimums. They are not asserted to be university-confirmed thresholds.
- The app still uses the 2028 intake. Its operational calendar keeps the exported opening date and moves the exported closing date forward one year. These are configured application windows, not a claim that universities published those 2028 dates. Original source dates remain in `sourceOpeningDate` / `sourceClosingDate`; the learner page identifies the source edition and configured intake calendar.
- Scoring methods differ: raw percentage totals, averages, six/seven-subject points, language selection groups, subject-specific bands and conditional bonuses are retained. NMU's conditional school-quintile bonus requires verified school context. Without it, the app calculates the conservative base score without awarding the conditional bonus and explains this beside the result. Meeting academic minimums never guarantees admission.
- UMP uses a seven-subject configured APS profile with its programme-specific academic thresholds; the historical scoring source is recorded separately from the current programme pages. Qualification-specific selection, endorsement, NCV/RPL and alternative-access conditions remain subject to the university's processes.

No learner-facing presentation-purpose labels or qualification review badges are added. Source transparency, missing personal evidence, additional selection requirements and normal access/validation safeguards remain in place.

## Presentation and verification

The guide covers account registration, invalid email / short-password validation, email verification, university/qualification information, out-of-range result rejection, saved-result persistence, and all four CRUD operations on an unused programme category. It includes duplicate-name and referenced-record deletion protection.

`npm test` checks the real HTTP account and CRUD workflows, all imported profiles, scoring/route evaluation, Maths vs Maths Literacy eligibility, idempotent imports, preservation of users/accounts, the learner detail rendering, city links and catalogue responses. Tests use local isolated databases. This release has not been executed against your Windows SQL Server, and a full visual browser check is still required after installing.

## Existing schema alignment

This release assumes the 2.7 PERSON_ID subtype migration is already installed. If your database is still at 2.6, stop the app, back up both databases, run `database/04_use_person_id_for_subtypes.sql`, then `database/03_verify_erd_alignment.sql` and require PASS with ISSUE_COUNT=0 before using this release. Do not rerun the original CREATE DATABASE script against a populated database. `npm run db:check` compares the live SQL Server schema with the project contract.

See `data/admissions-coverage.csv` for per-qualification coverage and sources, `data/admissions-complete.json` for the full rule profiles, and `data/admission-subjects.json` for the subject-code mapping. Imported advanced scoring/alternative routes are retained when basic offering details are saved through staff screens.
