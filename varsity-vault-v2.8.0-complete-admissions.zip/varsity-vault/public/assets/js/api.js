export async function api(path, options = {}) {
  const { timeoutMs = 20000, signal, ...requestOptions } = options;
  const controller = new AbortController();
  const cancelled = () => controller.abort(signal?.reason);
  if (signal?.aborted) cancelled();
  else signal?.addEventListener('abort', cancelled, { once: true });
  let timer;
  const deadline = new Promise((_, reject) => {
    timer = setTimeout(() => {
      const error = Object.assign(
        new Error(
          'The server took too long to respond. Try again. Before retrying a save, check whether it completed.',
        ),
        { status: 408, code: 'REQUEST_TIMEOUT' },
      );
      reject(error);
      controller.abort(error);
    }, timeoutMs);
  });
  const run = async () => {
    let response;
    try {
      response = await fetch(path, {
        ...requestOptions,
        signal: controller.signal,
        headers: { Accept: 'application/json', ...requestOptions.headers },
      });
    } catch {
      throw new Error(
        'Cannot reach Varsity Vault. Check that the server is running and your connection is available. Before retrying a save, check whether it completed.',
      );
    }
    let data;
    try {
      data = response.status === 204 ? {} : await response.json();
    } catch {
      throw Object.assign(
        new Error(
          response.status === 401
            ? 'Your session has expired. Please sign in again.'
            : 'The server returned an unexpected response. Check that Varsity Vault is running, then reload this page.',
        ),
        { status: response.status },
      );
    }
    if (!response.ok)
      throw Object.assign(
        new Error(data?.error || 'The request could not be completed. Please try again.'),
        { status: response.status },
      );
    return data;
  };
  try {
    // The deadline covers both the response headers and reading the body.
    // Never automatically replay a write after a timeout or network failure.
    return await Promise.race([run(), deadline]);
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener('abort', cancelled);
  }
}
