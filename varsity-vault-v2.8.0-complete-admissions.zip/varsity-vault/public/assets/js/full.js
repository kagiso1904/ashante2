import { api } from './api.js';
import {
  learnerAvailability,
  learnerAssessmentStatus,
} from '/shared/scoring/learner-display.js';
import { assessSubjects } from '/shared/scoring/subjects.js';
import { reconcileResultDraftRows } from '/shared/scoring/results-draft.js';
import { isRequiredBeforeProvisional } from '/shared/review/documents.js';
let user,
  csrf,
  catalog,
  offerings,
  supportEmail = '',
  emailEnabled = false;
const main = document.querySelector('#main'),
  page = document.body.dataset.page;
const esc = (x) =>
  String(x ?? '').replace(
    /[&<>"']/g,
    (c) =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[
        c
      ],
  );
const personNamePatternUi =
  /^\p{L}[\p{L}\p{M}]*(?:[ '\u2019-]\p{L}[\p{L}\p{M}]*)*(?:\.\s*\p{L}[\p{L}\p{M}]*)*\.?$/u;
function isValidSouthAfricanIdNumberUi(value) {
  const idNumber = String(value ?? '').trim();
  if (!idNumber) return true;
  if (!/^\d{13}$/.test(idNumber)) return false;
  const yy = Number(idNumber.slice(0, 2));
  const month = Number(idNumber.slice(2, 4));
  const day = Number(idNumber.slice(4, 6));
  const now = new Date();
  const shortYear = now.getFullYear() % 100;
  const year = yy <= shortYear ? 2000 + yy : 1900 + yy;
  const date = new Date(Date.UTC(year, month - 1, day));
  if (
    month < 1 ||
    month > 12 ||
    day < 1 ||
    day > 31 ||
    date.getUTCFullYear() !== year ||
    date.getUTCMonth() !== month - 1 ||
    date.getUTCDate() !== day ||
    date.getTime() > now.getTime()
  )
    return false;
  // Simulated records require format/date validity, not a government check digit.
  return true;
}
function wireSouthAfricanIdValidation(form) {
  if (!form) return;
  for (const input of form.querySelectorAll('[name="saIdNumber"]')) {
    const validate = () => {
      input.setCustomValidity(
        isValidSouthAfricanIdNumberUi(input.value)
          ? ''
          : 'Enter a valid 13-digit South African ID number with a valid, non-future date.',
      );
    };
    input.addEventListener('input', validate);
    input.addEventListener('change', validate);
    input.addEventListener('blur', validate);
    validate();
  }
}
function wirePersonNameValidation(form) {
  if (!form) return;
  for (const input of form.querySelectorAll(
    '[name="firstName"], [name="lastName"]',
  )) {
    const validate = () => {
      const value = input.value.trim();
      input.setCustomValidity(
        value && !personNamePatternUi.test(value)
          ? 'Use letters only for a person name. Spaces, apostrophes, periods and hyphens are allowed; numbers are not.'
          : '',
      );
    };
    input.addEventListener('beforeinput', (event) => {
      if (typeof event.data === 'string' && /\d/u.test(event.data)) {
        event.preventDefault();
        input.setCustomValidity(
          'Numbers are not permitted in a person name. Use letters, spaces, apostrophes, periods or hyphens.',
        );
        input.reportValidity?.();
      }
    });
    input.addEventListener('input', validate);
    input.addEventListener('blur', validate);
    validate();
  }
}
const formatDateTime = (value) => {
  if (!value) return 'Not recorded';
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? 'Not recorded'
    : new Intl.DateTimeFormat('en-ZA', {
        dateStyle: 'medium',
        timeStyle: 'short',
      }).format(date);
};
const safeHttps = (value) => {
  try {
    const url = new URL(String(value));
    return url.protocol === 'https:' ? url.href : '';
  } catch {
    return '';
  }
};
const nav = {
  learner: [
    ['overview', 'Dashboard', 'layout-dashboard'],
    ['profile', 'My Profile', 'user-round'],
    ['results', 'Results', 'file-chart-column'],
    ['subjects', 'Subjects', 'book-open'],
    ['universities', 'Universities', 'building-2'],
    ['requirements', 'Requirements', 'list-checks'],
    ['applications', 'My Applications', 'send'],
    ['documents', 'Documents', 'folder-open'],
    ['prospectuses', 'Prospectuses', 'book-open'],
  ],
  teacher: [
    ['overview', 'Dashboard', 'layout-dashboard'],
    ['profile', 'My Profile', 'user-round'],
    ['learners', 'Learners', 'users'],
    ['results', 'Results', 'file-check-2'],
    ['applications', 'Applications', 'send'],
    ['documents', 'Documents', 'folder-open'],
  ],
  representative: [
    ['overview', 'Dashboard', 'layout-dashboard'],
    ['profile', 'My Profile', 'user-round'],
    ['applications', 'Applications', 'inbox'],
    ['decisions', 'Admission Decisions', 'clipboard-check'],
    ['offerings', 'Programme Requirements', 'list-checks'],
    ['prospectuses', 'Prospectuses', 'book-open'],
  ],
  admin: [
    ['overview', 'Dashboard', 'layout-dashboard'],
    ['profile', 'My Profile', 'user-round'],
    ['accounts', 'Accounts', 'users'],
    ['directories', 'Directories', 'map-pinned'],
    ['lookups', 'Academic Records', 'table-properties'],
    ['offerings', 'Programme Requirements', 'list-checks'],
    ['policies', 'Requirements Review', 'book-open'],
    ['audit', 'Audit History', 'history'],
    ['applications', 'Applications', 'inbox'],
  ],
};
const navigationGroups = {
  learner: [
    ['Workspace', ['overview', 'profile']],
    ['My academic record', ['results', 'subjects', 'documents']],
    [
      'University applications',
      ['universities', 'requirements', 'applications', 'prospectuses'],
    ],
  ],
  teacher: [
    ['Workspace', ['overview', 'profile']],
    ['Learner support', ['learners', 'results', 'documents']],
    ['Application tracking', ['applications']],
  ],
  representative: [
    ['Workspace', ['overview', 'profile']],
    ['Admissions', ['applications', 'decisions']],
    ['University information', ['offerings', 'prospectuses']],
  ],
  admin: [
    ['Workspace', ['overview', 'profile']],
    ['People and institutions', ['accounts', 'directories']],
    ['Academic configuration', ['lookups', 'offerings', 'policies']],
    ['Oversight', ['applications', 'audit']],
  ],
};
const verifiedLabel = (id) =>
  catalog.verificationStatuses.find(
    (s) => String(s.VERIFICATION_STATUS_ID) === String(id),
  )?.VERIFICATION_STATUS_NAME || 'Unknown';
const icons = () => window.lucide?.createIcons();
const request = (path, method = 'GET', body) =>
  api(path, {
    method,
    headers: {
      ...(body instanceof Blob ? {} : { 'Content-Type': 'application/json' }),
      ...(csrf ? { 'X-CSRF-Token': csrf } : {}),
    },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
const title = (name, description = '') => /* HTML */ `
  <div class="page-heading">
    <span class="eyebrow">2028 UNIVERSITY ENTRY</span>
    <h1>${esc(name)}</h1>
    <p>${esc(description)}</p>
  </div>
`;
const link = (path, label) => /* HTML */ `
  <a class="inline-link" href="${path}">
    ${esc(label)}
    <i data-lucide="arrow-right" aria-hidden="true"></i>
  </a>
`;
const badge = (s) => /* HTML */ ` <span class="state-badge">${esc(s)}</span> `;
const table = (heads, rows) => /* HTML */ `
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          ${heads
            .map((h) => /* HTML */ ` <th scope="col">${esc(h)}</th> `)
            .join('')}
        </tr>
      </thead>
      <tbody>
        ${
          rows.length
            ? rows.join('')
            : /* HTML */ `
                <tr>
                  <td colspan="${heads.length}">No records yet.</td>
                </tr>
              `
        }
      </tbody>
    </table>
  </div>
`;
const auditDetail = (raw) => {
  try {
    const data = JSON.parse(raw),
      allowed = new Set([
        'role',
        'invitation',
        'method',
        'count',
        'table',
        'operator',
        'target',
        'status',
        'bytes',
      ]),
      items = Object.entries(data)
        .filter(
          ([key, value]) =>
            allowed.has(key) &&
            ['string', 'number', 'boolean'].includes(typeof value),
        )
        .map(
          ([key, value]) =>
            `${key.replaceAll('_', ' ')}: ${value === true ? 'yes' : value === false ? 'no' : value}`,
        );
    return items.length ? items.join(' · ') : 'Activity recorded';
  } catch {
    return 'Activity recorded';
  }
};
const auditAction = (event) =>
  String(event || 'Activity')
    .replace(/^demo\./i, 'records.')
    .replaceAll('.', ' ')
    .replaceAll('_', ' ')
    .replace(/\b\w/g, (char) => char.toUpperCase());
const select = (items, idField, labelField, selected) =>
  items
    .map(
      (x) => /* HTML */ `
        <option
          value="${esc(x[idField])}"
          ${String(x[idField]) === String(selected) ? 'selected' : ''}
        >
          ${esc(x[labelField])}
        </option>
      `,
    )
    .join('');
const examSelect = () => /* HTML */ `
  <label>
    Examination milestone
    <select id="exam">
      ${select(catalog.examTypes, 'EXAM_TYPE_ID', 'EXAM_TYPE_NAME')}
    </select>
  </label>
`;
const feedback = (message) => {
  let node = document.querySelector('#feedback');
  if (!node) {
    node = document.createElement('p');
    node.id = 'feedback';
    node.className = 'feedback';
    node.setAttribute('role', 'status');
  }
  const heading = main.querySelector('.page-heading');
  if (heading) heading.after(node);
  else if (!node.isConnected) main.prepend(node);
  node.textContent = message;
  if (message) node.scrollIntoView?.({ block: 'nearest' });
};
function show(html) {
  main.innerHTML =
    html + '<p id="feedback" class="feedback" role="status"></p>';
  icons();
}
const pendingActions = new WeakSet();
function guard(fn, concurrent = false) {
  return async (e) => {
    const target = concurrent ? null : e?.currentTarget;
    if (target && pendingActions.has(target)) {
      e.preventDefault();
      return;
    }
    const button = target?.matches?.('button') ? target : e?.submitter;
    const wasDisabled = button?.disabled;
    if (target) {
      pendingActions.add(target);
      target.setAttribute('aria-busy', 'true');
    }
    if (button) button.disabled = true;
    try {
      await fn(e);
    } catch (error) {
      if (error.status === 401) location.assign('/login.html');
      else feedback(error.message);
    } finally {
      if (target) {
        pendingActions.delete(target);
        target.removeAttribute('aria-busy');
      }
      if (button) button.disabled = wasDisabled;
    }
  };
}
async function upload(path, file, extra = {}) {
  if (!file) throw new Error('Choose a file first.');
  if (file.size === 0 || file.size > 6 * 1024 * 1024)
    throw new Error('Choose a non-empty file no larger than 6 MB.');
  if (!['application/pdf', 'image/png', 'image/jpeg'].includes(file.type))
    throw new Error('Choose a PDF, PNG or JPEG file.');
  if (path === '/api/prospectuses' && file.type !== 'application/pdf')
    throw new Error('Prospectuses must be PDF files.');
  return api(path, {
    method: 'POST',
    headers: {
      'Content-Type': file.type,
      'X-CSRF-Token': csrf,
      'X-File-Name': encodeURIComponent(file.name),
      ...extra,
    },
    body: file,
  });
}
function shell() {
  document.body.dataset.role = user.role;
  document.querySelector('#navigation').innerHTML = navigationGroups[user.role]
    .map(
      ([heading, pages], index) => `
      <section class="navigation-group" aria-labelledby="nav-group-${index}">
        <h2 id="nav-group-${index}" class="navigation-group-title">${esc(heading)}</h2>
        ${pages
          .map((key) => {
            const [p, n, i] = nav[user.role].find((entry) => entry[0] === key);
            const current =
              p === page ||
              (page === 'university' && p === 'universities') ||
              (page === 'verification' && p === 'results');
            return `<a href="/${user.role}/${p}.html" ${current ? 'aria-current="page"' : ''}>
            <i data-lucide="${i}" aria-hidden="true"></i>${esc(n)}</a>`;
          })
          .join('')}
      </section>`,
    )
    .join('');
  document.querySelector('#role-label').textContent =
    {
      learner: 'Learner',
      teacher: 'Career Guidance Teacher',
      representative: 'University Representative',
      admin: 'IT Administrator',
    }[user.role] + ' workspace';
  document.querySelector('#breadcrumb').textContent =
    (page === 'university'
      ? 'University details'
      : nav[user.role].find((n) => n[0] === page)?.[1]) || 'Workspace';
  document.querySelector('.topbar').lastElementChild.textContent = '2028 entry';
  document.querySelector('.brand').href = '/' + user.role + '/overview.html';
  document.querySelector('.brand').innerHTML = /* HTML */ `
    <img src="/assets/images/varsity-vault-mark.svg" alt="" />
    <span>Varsity Vault</span>
  `;
  document.querySelector('.portal-account').innerHTML =
    '<i data-lucide="log-out" aria-hidden="true"></i>Sign out';
  document.querySelector('.portal-account').href = '#';
  document.querySelector('.portal-account').addEventListener(
    'click',
    guard(async (e) => {
      e.preventDefault();
      await request('/api/auth/logout', 'POST', {});
      location.assign('/');
    }),
  );
  document.querySelector('.page-footer').innerHTML = /* HTML */ `
    <div class="footer-grid">
      <section>
        <strong class="footer-brand">Varsity Vault</strong>
        <p>Explore 26 university profiles and plan your 2028 entry.</p>
        <span class="footer-coverage">
          <i data-lucide="landmark" aria-hidden="true"></i>
          26 university profiles
        </span>
      </section>
      <nav aria-label="Help and guidance">
        <strong>Help &amp; guidance</strong>
        <a href="/help.html">Help centre</a>
        <a href="/help.html#application-checklist">Application checklist</a>
        <a href="/help.html#access-support">Account access help</a>
      </nav>
      <section>
        <strong>Support</strong>
        <p>
          ${
            supportEmail
              ? /* HTML */ `
                  Email
                  <a href="mailto:${esc(supportEmail)}">${esc(supportEmail)}</a>
                  for account support.
                `
              : 'For staff account access or password resets, contact your institution’s IT administrator.'
          }
        </p>
        <small>
          For programme decisions, follow the university’s official application
          instructions.
        </small>
      </section>
    </div>
    <div class="footer-bottom">
      <span>© ${new Date().getFullYear()} Varsity Vault</span>
      <span>2028 university entry</span>
    </div>
  `;
  document.title =
    (nav[user.role].find((n) => n[0] === page)?.[1] || 'Workspace') +
    ' | Varsity Vault';
  icons();
}
async function login() {
  let registrationSchools = [];
  // Render sign-in before asking SQL Server for registration data.
  document.body.classList.add('is-auth');
  document.querySelector('.sidebar').hidden = true;
  document.querySelector('.shell').classList.add('auth-shell');
  document.querySelector('.portal-header').hidden = true;
  document.querySelector('.topbar').hidden = true;
  document.querySelector('.page-footer').hidden = true;
  show(/* HTML */ `
    <section class="auth-layout">
      <aside class="auth-story">
        <a href="/" class="auth-brand" aria-label="Varsity Vault home">
          <span class="auth-brand-mark">
            <img src="/assets/images/varsity-vault-mark.svg" alt="" />
          </span>
          <span>
            Varsity Vault
            <small>UNIVERSITY PATHWAYS</small>
          </span>
        </a>
        <div class="auth-story-content">
          <span class="auth-overline">
            <i data-lucide="sparkles" aria-hidden="true"></i>
            2028 UNIVERSITY ENTRY
          </span>
          <h1>
            Your next chapter
            <br />
            <span>starts here.</span>
          </h1>
          <p>
            Bring your results, documents and university applications together
            in one secure place.
          </p>
          <div class="auth-story-actions">
            <a
              href="#auth-tab-register"
              id="auth-create-account"
              class="auth-story-cta"
            >
              Create learner account
              <i data-lucide="arrow-right" aria-hidden="true"></i>
            </a>
            <a
              href="/help.html#application-checklist"
              class="auth-story-secondary"
            >
              How applications work
            </a>
          </div>
          <div class="auth-feature-list">
            <div>
              <span class="auth-feature-icon">
                <i
                  data-lucide="chart-no-axes-column-increasing"
                  aria-hidden="true"
                ></i>
              </span>
              <span>
                <strong>Understand your results</strong>
                <small>Capture marks and see your APS clearly.</small>
              </span>
            </div>
            <div>
              <span class="auth-feature-icon">
                <i data-lucide="landmark" aria-hidden="true"></i>
              </span>
              <span>
                <strong>Explore your options</strong>
                <small>Compare requirements across South Africa.</small>
              </span>
            </div>
            <div>
              <span class="auth-feature-icon">
                <i data-lucide="file-check-2" aria-hidden="true"></i>
              </span>
              <span>
                <strong>Keep applications organised</strong>
                <small>Follow progress from one workspace.</small>
              </span>
            </div>
          </div>
        </div>
        <div class="auth-story-footer">
          <span>26 UNIVERSITY PROFILES</span>
          <span>Compare your options before you apply.</span>
        </div>
      </aside>
      <section class="auth-main">
        <a href="/" class="auth-mobile-brand" aria-label="Varsity Vault home">
          <span class="auth-brand-mark">
            <img src="/assets/images/varsity-vault-mark.svg" alt="" />
          </span>
          <span>Varsity Vault</span>
        </a>
        <div class="auth-card" id="auth-card">
          <div class="auth-card-heading">
            <span class="auth-overline">WELCOME TO VARSITY VAULT</span>
            <h2 id="auth-title">Welcome back</h2>
            <p id="auth-subtitle">Sign in to continue to your workspace.</p>
          </div>
          <div class="auth-tabs" role="tablist" aria-label="Account access">
            <button
              id="auth-tab-login"
              type="button"
              role="tab"
              aria-selected="true"
              aria-controls="auth-login-panel"
            >
              Sign in
            </button>
            <button
              id="auth-tab-register"
              type="button"
              role="tab"
              aria-selected="false"
              aria-controls="auth-register-panel"
            >
              Create learner account
            </button>
          </div>
          <div
            id="auth-login-panel"
            role="tabpanel"
            aria-labelledby="auth-tab-login"
          >
            <form id="login" class="auth-form">
              <label>
                Email or username
                <input
                  name="username"
                  type="text"
                  autocomplete="username"
                  placeholder="you@example.com"
                  required
                />
              </label>
              <label>
                Password
                <input
                  name="password"
                  type="password"
                  autocomplete="current-password"
                  placeholder="Enter your password"
                  required
                  maxlength="128"
                />
              </label>
              <button class="auth-submit" type="submit">
                Sign in
                <i data-lucide="arrow-right" aria-hidden="true"></i>
              </button>
            </form>
            <a class="inline-link" href="/account-recovery.html">
              Forgot password or need an email verification link?
            </a>
            <p class="auth-secondary-note">
              Staff and representative accounts are provided by your IT
              administrator.
            </p>
          </div>
          <div
            id="auth-register-panel"
            role="tabpanel"
            aria-labelledby="auth-tab-register"
            hidden
          >
            <form id="register" class="auth-form">
              <div class="auth-name-fields">
                <label>
                  First name
                  <input
                    name="firstName"
                    pattern="[^0-9]+"
                    title="Enter a name using letters, spaces, apostrophes or hyphens. Numbers are not allowed."
                    required
                    maxlength="100"
                    autocomplete="given-name"
                    placeholder="First name"
                  />
                </label>
                <label>
                  Last name
                  <input
                    name="lastName"
                    pattern="[^0-9]+"
                    title="Enter a surname using letters, spaces, apostrophes or hyphens. Numbers are not allowed."
                    required
                    maxlength="100"
                    autocomplete="family-name"
                    placeholder="Last name"
                  />
                </label>
              </div>
              <label>
                Email address
                <input
                  name="email"
                  type="email"
                  autocomplete="email"
                  placeholder="you@example.com"
                  required
                  maxlength="255"
                />
              </label>
              <label>
                South African ID number (optional)
                <input
                  name="saIdNumber"
                  type="text"
                  inputmode="numeric"
                  autocomplete="off"
                  maxlength="13"
                  pattern="[0-9]{13}"
                  placeholder="13 digits, if available"
                />
              </label>
              <p class="form-help">
                You can leave this blank and add it later in My Profile. Only
                enter your own ID number.
              </p>
              <label>
                Your school
                <select name="schoolId" required disabled>
                  <option value="" selected disabled>Choose your school</option>
                </select>
              </label>
              <p
                class="form-help"
                id="registration-schools-status"
                role="status"
              >
                Loading schools for learner registration… You can still sign in.
              </p>
              <label>
                Create password
                <input
                  name="password"
                  type="password"
                  autocomplete="new-password"
                  placeholder="At least 12 characters"
                  minlength="12"
                  maxlength="128"
                  required
                />
              </label>
              <button class="auth-submit" type="submit" disabled>
                Create learner account
                <i data-lucide="arrow-right" aria-hidden="true"></i>
              </button>
            </form>
            <button type="button" id="retry-registration-schools" hidden>
              Retry loading schools
            </button>
            <p class="auth-secondary-note">
              Teachers and representatives receive accounts from your IT
              administrator.
            </p>
          </div>
        </div>
        <p class="auth-privacy">
          <i data-lucide="shield-check" aria-hidden="true"></i>
          Your academic journey, organised in one secure workspace.
        </p>
      </section>
    </section>
  `);
  const loadSchools = async () => {
    const schoolSelect = document.querySelector('#register [name="schoolId"]');
    const status = document.querySelector('#registration-schools-status');
    const retry = document.querySelector('#retry-registration-schools');
    const submit = document.querySelector('#register button[type="submit"]');
    retry.hidden = true;
    status.textContent =
      'Loading schools for learner registration… You can still sign in.';
    try {
      const data = await api('/api/registration-schools');
      if (!Array.isArray(data.schools))
        throw new Error('The school list could not be read.');
      registrationSchools = data.schools.filter(
        (school) => school.EMIS_NUMBER !== 'LOCAL-ONLY',
      );
      schoolSelect.innerHTML =
        '<option value="" selected disabled>Choose your school</option>' +
        select(registrationSchools, 'SCHOOL_ID', 'SCHOOL_NAME');
      schoolSelect.disabled = registrationSchools.length === 0;
      submit.disabled = registrationSchools.length === 0;
      status.textContent = registrationSchools.length
        ? 'If your school is not listed, ask your school administrator to request an update.'
        : 'No schools are configured yet. Ask your institution administrator to add your school before creating an account.';
    } catch (error) {
      schoolSelect.disabled = true;
      submit.disabled = true;
      status.textContent =
        'Registration schools could not be loaded. ' +
        error.message +
        ' Sign-in remains available.';
      retry.hidden = false;
    }
  };
  document
    .querySelector('#retry-registration-schools')
    .addEventListener('click', guard(loadSchools));
  void loadSchools();
  const setTab = (register) => {
    const loginButton = document.querySelector('#auth-tab-login'),
      registerButton = document.querySelector('#auth-tab-register'),
      loginPanel = document.querySelector('#auth-login-panel'),
      registerPanel = document.querySelector('#auth-register-panel');
    loginButton.setAttribute('aria-selected', String(!register));
    registerButton.setAttribute('aria-selected', String(register));
    loginButton.tabIndex = register ? -1 : 0;
    registerButton.tabIndex = register ? 0 : -1;
    loginPanel.hidden = register;
    registerPanel.hidden = !register;
    document.querySelector('#auth-title').textContent = register
      ? 'Create your account'
      : 'Welcome back';
    document.querySelector('#auth-subtitle').textContent = register
      ? 'Start organising your university applications.'
      : 'Sign in to continue to your workspace.';
    icons();
  };
  document
    .querySelector('#auth-tab-login')
    .addEventListener('click', () => setTab(false));
  document
    .querySelector('#auth-tab-register')
    .addEventListener('click', () => setTab(true));
  document
    .querySelector('#auth-create-account')
    .addEventListener('click', (event) => {
      event.preventDefault();
      setTab(true);
      document
        .querySelector('#auth-card')
        ?.scrollIntoView?.({ block: 'start' });
      document.querySelector('#auth-tab-register').focus();
    });
  window.addEventListener('hashchange', () => {
    if (location.hash === '#auth-tab-register') setTab(true);
  });
  setTab(location.hash === '#auth-tab-register');
  document.querySelector('#login').addEventListener(
    'submit',
    guard(async (e) => {
      e.preventDefault();
      const button =
        e.submitter || e.target.querySelector('button[type="submit"]');
      if (!button) return;
      button.disabled = true;
      button.classList.add('is-loading');
      try {
        const data = Object.fromEntries(new FormData(e.target)),
          out = await request('/api/auth/login', 'POST', data);
        if (out.mfaRequired) {
          location.assign('/mfa-challenge.html');
          return;
        }
        location.assign('/' + out.user.role + '/overview.html');
      } finally {
        button.disabled = false;
        button.classList.remove('is-loading');
      }
    }),
  );
  document.querySelector('#register').addEventListener(
    'submit',
    guard(async (e) => {
      e.preventDefault();
      const button =
        e.submitter || e.target.querySelector('button[type="submit"]');
      if (!button) return;
      button.disabled = true;
      try {
        const data = Object.fromEntries(new FormData(e.target));
        data.schoolId = Number(data.schoolId);
        const out = await request('/api/auth/register', 'POST', data);
        feedback(out.message);
        e.target.reset();
        setTab(false);
      } finally {
        button.disabled = registrationSchools.length === 0;
      }
    }),
  );
}
async function profile() {
  const {
      person,
      identityWarnings = [],
      saIdNumber = '',
      hasSaIdNumber = false,
      saIdNumberMasked = null,
    } = await request('/api/me/profile'),
    school = catalog.schools.find(
      (item) => String(item.SCHOOL_ID) === String(user.schoolId),
    ),
    university = catalog.universities.find(
      (item) => String(item.UNIVERSITY_ID) === String(user.universityId),
    ),
    scope =
      school?.SCHOOL_NAME ||
      university?.UNIVERSITY_NAME ||
      (user.role === 'admin'
        ? 'System administration'
        : 'Institution not assigned');
  show(
    title('My Profile', 'Your identity and assigned portal scope.') +
      /* HTML */ `
        <section class="panel">
          ${
            identityWarnings.length
              ? /* HTML */ `
                  <div class="notice identity-warning" role="alert">
                    <strong>Account details need review</strong>
                    <ul>
                      ${identityWarnings.map((warning) => `<li>${esc(warning)}</li>`).join('')}
                    </ul>
                    <p>
                      To protect account access, this page does not change your
                      login email. Contact your IT administrator to verify and
                      correct identity details.
                    </p>
                  </div>
                `
              : ''
          }
          <form id="profile">
            <div class="fields">
              <label>
                First name
                <input
                  name="firstName"
                  pattern="[^0-9]+"
                  title="Enter a name using letters, spaces, apostrophes or hyphens. Numbers are not allowed."
                  value="${esc(person.FIRST_NAME)}"
                  required
                  maxlength="100"
                />
              </label>
              <label>
                Last name
                <input
                  name="lastName"
                  pattern="[^0-9]+"
                  title="Enter a surname using letters, spaces, apostrophes or hyphens. Numbers are not allowed."
                  value="${esc(person.LAST_NAME)}"
                  required
                  maxlength="100"
                />
              </label>
              <label>
                Phone number (optional)
                <input
                  name="phone"
                  type="tel"
                  inputmode="numeric"
                  value="${esc(person.PHONE_NUMBER)}"
                  maxlength="10"
                  pattern="0[0-9]{9}"
                  title="Enter a 10-digit South African number beginning with 0, or leave blank."
                />
                <small class="muted"
                  >Use 10 local digits beginning with 0, or leave blank.</small
                >
              </label>
              ${
                user.role === 'learner'
                  ? /* HTML */ `
                      <label>
                        South African ID number (optional)
                        <input
                          name="saIdNumber"
                          type="text"
                          inputmode="numeric"
                          autocomplete="off"
                          maxlength="13"
                          pattern="[0-9]{13}"
                          placeholder="Enter 13 digits"
                          aria-describedby="sa-id-help"
                          value="${esc(saIdNumber)}"
                          ${hasSaIdNumber ? 'readonly aria-readonly="true"' : ''}
                        />
                        <small id="sa-id-help" class="muted">
                          ${hasSaIdNumber ? 'Your saved ID number is read-only. Ask your administrator if it needs correction.' : 'Enter your own valid South African ID number. It becomes read-only after saving.'}
                        </small>
                      </label>
                    `
                  : ''
              }
              <label>
                Email
                <input value="${esc(person.EMAIL)}" readonly />
              </label>
            </div>
            <button>Save profile</button>
          </form>
          <p class="muted">
            ${esc({ learner: 'Learner', teacher: 'Career Guidance Teacher', representative: 'University Representative', admin: 'IT Administrator' }[user.role])}
            · ${esc(scope)}
          </p>
        </section>
      `,
  );
  document.querySelector('#profile').addEventListener(
    'submit',
    guard(async (e) => {
      e.preventDefault();
      const submitted = Object.fromEntries(new FormData(e.target));
      const out = await request('/api/me/profile', 'PUT', submitted);
      await profile();
      feedback(out.message);
    }),
  );
  main.insertAdjacentHTML(
    'beforeend',
    /* HTML */ `
      <section class="panel">
        <h2>Change password</h2>
        <form id="password-change">
          <div class="fields">
            <label>
              Current password
              <input
                name="currentPassword"
                type="password"
                required
                autocomplete="current-password"
              />
            </label>
            <label>
              New password
              <input
                name="newPassword"
                type="password"
                minlength="12"
                maxlength="128"
                required
                autocomplete="new-password"
              />
            </label>
          </div>
          <button>Change password and sign out</button>
        </form>
      </section>
    `,
  );
  document.querySelector('#password-change').addEventListener(
    'submit',
    guard(async (e) => {
      e.preventDefault();
      await request(
        '/api/me/password',
        'POST',
        Object.fromEntries(new FormData(e.target)),
      );
      location.assign('/login.html');
    }),
  );
}
function selectableLearnerSubjects(rows) {
  const existing = new Set(
    rows.map((r) =>
      String(
        r.SUBJECT_CODE ||
          catalog.subjects.find(
            (s) => String(s.SUBJECT_ID) === String(r.SUBJECT_ID),
          )?.SUBJECT_CODE ||
          '',
      ).toUpperCase(),
    ),
  );
  const choices = new Map();
  for (const subject of catalog.subjects) {
    if (
      subject.SCHOOL_ID != null &&
      String(subject.SCHOOL_ID) !== String(user.schoolId)
    )
      continue;
    const code = String(subject.SUBJECT_CODE || '').toUpperCase();
    if (existing.has(code)) continue;
    if (!choices.has(code) || subject.SCHOOL_ID != null)
      choices.set(code, subject);
  }
  return [...choices.values()];
}
function learnerExamKey() {
  return 'vv-results-exam-' + user.personId;
}
function rememberedExam() {
  try {
    return localStorage.getItem(learnerExamKey()) || '';
  } catch {
    return '';
  }
}
function rememberExam(examId) {
  try {
    localStorage.setItem(learnerExamKey(), String(examId));
  } catch {}
}
function learnerResultsDraftKey(examId) {
  return 'vv-results-draft-' + user.personId + '-' + examId;
}
function readLearnerResultsDraft(examId) {
  try {
    const value = localStorage.getItem(learnerResultsDraftKey(examId));
    return value === null ? null : JSON.parse(value);
  } catch {
    return null;
  }
}
function writeLearnerResultsDraft(examId, rows) {
  try {
    localStorage.setItem(learnerResultsDraftKey(examId), JSON.stringify(rows));
  } catch {}
}
function clearLearnerResultsDraft(examId) {
  try {
    localStorage.removeItem(learnerResultsDraftKey(examId));
  } catch {}
}
function sameResultRows(first, second) {
  if (
    !Array.isArray(first) ||
    !Array.isArray(second) ||
    first.length !== second.length
  )
    return false;
  const normalize = (rows) =>
    rows
      .map((row) => [String(row.SUBJECT_ID), Number(row.PERCENTAGE)])
      .sort(([a], [b]) => a.localeCompare(b));
  const left = normalize(first),
    right = normalize(second);
  return left.every(
    ([subjectId, mark], index) =>
      subjectId === right[index][0] &&
      Number.isFinite(mark) &&
      mark === right[index][1],
  );
}
async function resultsPage() {
  let learners = [];
  if (user.role === 'teacher')
    learners = (await request('/api/teacher/learners')).learners;
  show(
    title(
      user.role === 'teacher' ? 'Results Verification' : 'Academic Results',
      'Capture and review percentage marks by examination milestone.',
    ) +
      /* HTML */ `
        <section class="panel">
          <div class="fields">
            ${
              user.role === 'teacher'
                ? /* HTML */ `
                    <label>
                      Learner
                      <select id="learner">
                        ${select(learners, 'PERSON_ID', 'name')}
                      </select>
                    </label>
                  `
                : ''
            }${examSelect()}
          </div>
          <div id="result-grid"></div>
        </section>
      `,
  );
  const examSelectElement = document.querySelector('#exam'),
    queryExam = new URLSearchParams(location.search).get('examTypeId'),
    preferred = queryExam || rememberedExam();
  if (
    user.role === 'learner' &&
    catalog.examTypes.some(
      (item) => String(item.EXAM_TYPE_ID) === String(preferred),
    )
  )
    examSelectElement.value = String(preferred);
  let rows = [],
    resultVersion = 0,
    loadSequence = 0;
  const persistDraft = (examId) => {
    if (user.role === 'learner') writeLearnerResultsDraft(examId, rows);
  };
  const renderLearner = (examId) => {
    const grid = document.querySelector('#result-grid');
    grid.innerHTML =
      table(
        ['Subject', 'Percentage', 'Action'],
        rows.map(
          (row, index) => /* HTML */ `
            <tr>
              <th>
                ${esc(row.SUBJECT_NAME)}
                ${row.__subjectResolutionError ? `<small class="muted">${esc(row.__subjectResolutionError)}</small>` : ''}
              </th>
              <td>
                <input
                  type="number"
                  min="0"
                  max="100"
                  step="0.01"
                  data-mark="${index}"
                  value="${row.PERCENTAGE ?? ''}"
                />
              </td>
              <td>
                <button
                  type="button"
                  class="secondary compact"
                  data-remove="${index}"
                >
                  Remove
                </button>
              </td>
            </tr>
          `,
        ),
      ) +
      /* HTML */ `
        <div class="fields">
          <label>
            Add subject
            <select id="subject">
              ${select(
                selectableLearnerSubjects(rows),
                'SUBJECT_ID',
                'SUBJECT_NAME',
              )}
            </select>
          </label>
        </div>
        <div class="actions">
          <button type="button" class="secondary" id="add">Add subject</button>
          <button type="button" id="save-results">Save results</button>
          <button type="button" class="secondary" id="request-verification">
            Request teacher verification
          </button>
          <button type="button" class="secondary" id="result-versions">
            Result version history
          </button>
        </div>
      `;
    grid.querySelectorAll('[data-mark]').forEach((input) =>
      input.addEventListener('input', () => {
        rows[Number(input.dataset.mark)].PERCENTAGE =
          input.value === '' ? null : Number(input.value);
        persistDraft(examId);
      }),
    );
    grid.querySelectorAll('[data-remove]').forEach((button) =>
      button.addEventListener('click', () => {
        rows.splice(Number(button.dataset.remove), 1);
        persistDraft(examId);
        renderLearner(examId);
      }),
    );
    grid.querySelector('#add').addEventListener('click', () => {
      const subjectId = grid.querySelector('#subject').value,
        subject = catalog.subjects.find(
          (item) => String(item.SUBJECT_ID) === String(subjectId),
        );
      if (
        subject &&
        !rows.some(
          (row) => String(row.SUBJECT_ID) === String(subject.SUBJECT_ID),
        )
      ) {
        rows.push({ ...subject, PERCENTAGE: 0 });
        persistDraft(examId);
        renderLearner(examId);
      }
    });
    grid.querySelector('#request-verification').addEventListener(
      'click',
      guard(async () => {
        if (readLearnerResultsDraft(examId))
          throw new Error(
            'Save your latest marks before requesting verification.',
          );
        const out = await request('/api/results/request-verification', 'POST', {
          examTypeId: Number(examId),
          resultVersion,
        });
        feedback(out.message);
      }),
    );
    grid.querySelector('#result-versions').addEventListener(
      'click',
      guard(async () => {
        const out = await request('/api/results/versions?examTypeId=' + examId);
        const area = document.createElement('section');
        area.className = 'panel';
        area.innerHTML =
          '<h2>Saved result versions</h2>' +
          out.versions
            .map(
              (v) =>
                '<details><summary>Version ' +
                v.version +
                ' · ' +
                esc(v.recordedAt) +
                '</summary>' +
                table(
                  ['Subject', 'Mark'],
                  v.rows.map(
                    (r) =>
                      '<tr><td>' +
                      esc(
                        catalog.subjects.find(
                          (s) => String(s.SUBJECT_ID) === String(r.SUBJECT_ID),
                        )?.SUBJECT_NAME || 'Subject',
                      ) +
                      '</td><td>' +
                      r.PERCENTAGE +
                      '%</td></tr>',
                  ),
                ) +
                '</details>',
            )
            .join('');
        main.querySelector('#version-history')?.remove();
        area.id = 'version-history';
        main.append(area);
      }),
    );
    grid.querySelector('#save-results').addEventListener(
      'click',
      guard(async (event) => {
        const button = event.currentTarget;
        button.disabled = true;
        button.textContent = 'Saving results…';
        try {
          const reconciled = reconcileResultDraftRows(
            rows,
            catalog.subjects,
            user.schoolId,
          );
          if (reconciled.unresolved.length) {
            rows = reconciled.rows;
            persistDraft(examId);
            renderLearner(examId);
            throw new Error(
              `These draft subjects are not available in the current database: ${reconciled.unresolved.join(', ')}. Remove each marked row, then add the matching subject from the current subject list. Your marks have been kept in this browser.`,
            );
          }
          rows = reconciled.rows;
          persistDraft(examId);
          const submittedRows = rows.map((row) => ({
            SUBJECT_ID: Number(row.SUBJECT_ID),
            PERCENTAGE: row.PERCENTAGE,
          }));
          if (
            submittedRows.some(
              (row) =>
                !Number.isFinite(row.PERCENTAGE) ||
                row.PERCENTAGE < 0 ||
                row.PERCENTAGE > 100,
            )
          ) {
            throw new Error(
              'Enter a valid percentage from 0 to 100 for every subject before saving.',
            );
          }
          const result = await request('/api/results', 'PUT', {
            examTypeId: Number(examId),
            expectedVersion: resultVersion,
            rows: submittedRows.map((row) => ({
              subjectId: row.SUBJECT_ID,
              percentage: row.PERCENTAGE,
            })),
          });
          // Confirm the write from the API before clearing the local draft.
          // If SQL Server rejects the write, the learner's entries are retained.
          const saved = await request(
            '/api/results?examTypeId=' + encodeURIComponent(examId),
          );
          const confirmed = sameResultRows(submittedRows, saved.rows);
          if (confirmed) clearLearnerResultsDraft(examId);
          await load({ ignoreDraft: confirmed });
          feedback(
            confirmed
              ? `${result.message} Saved ${saved.rows.length} subject result(s) for this milestone.`
              : 'The server did not confirm these marks. Your browser draft has been kept. Check the VS Code terminal for the database error, then retry.',
          );
          syncPathwayWithResults(confirmed && saved.rows.length > 0);
          icons();
        } finally {
          if (button.isConnected) {
            button.disabled = false;
            button.textContent = 'Save results';
          }
        }
      }),
    );
  };
  const load = async ({ ignoreDraft = false } = {}) => {
    const learner = document.querySelector('#learner')?.value;
    if (user.role === 'teacher' && !learner) {
      document.querySelector('#result-grid').textContent =
        'No learners enrolled at your school.';
      return false;
    }
    const examId = examSelectElement.value,
      sequence = ++loadSequence,
      data = await request(
        '/api/results?examTypeId=' +
          examId +
          (learner ? '&learnerId=' + learner : ''),
      );
    if (sequence !== loadSequence) return false;
    rows = data.rows;
    resultVersion = data.resultVersion || 0;
    if (user.role === 'learner') {
      const draft = ignoreDraft ? null : readLearnerResultsDraft(examId);
      if (ignoreDraft) {
        rows = data.rows;
      } else if (Array.isArray(draft)) {
        // Browser drafts can outlive a database reseed. Subject IDs are IDENTITY
        // values and may change; remap by stable code/name before sending them.
        const reconciled = reconcileResultDraftRows(
          draft,
          catalog.subjects,
          user.schoolId,
        );
        rows = reconciled.rows;
        if (reconciled.unresolved.length) {
          persistDraft(examId);
          feedback(
            `Some saved browser-draft subjects are no longer in the current subject catalogue: ${reconciled.unresolved.join(', ')}. Remove each marked row and re-add it from the subject list; your percentages are retained.`,
          );
        } else if (sameResultRows(rows, data.rows)) {
          clearLearnerResultsDraft(examId);
          rows = data.rows;
        } else {
          persistDraft(examId);
          feedback(
            'Your unsaved marks were restored and matched to the current subject catalogue. Save results to add them to your account.',
          );
        }
      }
      const confirmed =
        ignoreDraft ||
        !Array.isArray(draft) ||
        (!rows.some((row) => row.__subjectResolutionError) &&
          sameResultRows(rows, data.rows));
      renderLearner(examId);
      return confirmed;
    }
    const grid = document.querySelector('#result-grid');
    grid.innerHTML =
      '<p>Result version ' +
      resultVersion +
      (data.verificationRequests?.length
        ? ' · Learner requested verification for version ' +
          data.verificationRequests.at(-1).resultVersion
        : ' · No explicit verification request recorded yet') +
      '</p>' +
      table(
        ['Subject', 'Percentage', 'Verification', 'Action'],
        rows.map(
          (row) => /* HTML */ `
            <tr>
              <th>${esc(row.SUBJECT_NAME)}</th>
              <td>${row.PERCENTAGE}%</td>
              <td>${esc(verifiedLabel(row.VERIFICATION_STATUS_ID))}</td>
              <td></td>
            </tr>
          `,
        ),
      ) +
      /* HTML */ `
        <div class="actions">
          <button type="button" id="verify">Verify against report</button>
          <button type="button" class="secondary" id="reject">
            Reject / unlock results
          </button>
          ${link('/teacher/documents.html', 'Review learner reports')}
        </div>
        <p class="muted">
          Download and compare the report before verifying. Your confirmation
          records that the marks match.
        </p>
      `;
    for (const [button, decision] of [
      ['verify', 'Verified'],
      ['reject', 'Rejected'],
    ])
      grid.querySelector('#' + button).addEventListener(
        'click',
        guard(async () => {
          feedback(
            (
              await request('/api/teacher/verify', 'POST', {
                learnerId: Number(learner),
                examTypeId: Number(examId),
                resultVersion,
                decision,
              })
            ).message,
          );
          await load();
        }),
      );
    icons();
    return true;
  };
  examSelectElement.addEventListener(
    'change',
    guard(() => {
      if (user.role === 'learner') rememberExam(examSelectElement.value);
      return load();
    }),
  );
  document.querySelector('#learner')?.addEventListener('change', guard(load));
  if (user.role === 'learner') rememberExam(examSelectElement.value);
  await load();
}
function campusLocations(university) {
  if (university?.LOCATIONS?.length) return university.LOCATIONS;
  const city = catalog.cities.find(
    (c) => String(c.CITY_ID) === String(university?.CITY_ID),
  );
  return city
    ? [
        {
          ...city,
          PROVINCE_NAME: catalog.provinces.find(
            (p) => String(p.PROVINCE_ID) === String(city.PROVINCE_ID),
          )?.PROVINCE_NAME,
          STREET_NAME: university.STREET_NAME,
        },
      ]
    : [];
}
const qualificationDate = (value) =>
  value ? String(value).slice(0, 10) : 'Not published';
function subjectDescription(code) {
  return (
    catalog.subjects.find((s) => s.SUBJECT_CODE === code)?.SUBJECT_NAME ||
    { APMATH: 'Advanced Programme Mathematics', MATH3: 'Mathematics Paper 3' }[
      code
    ] ||
    code
  );
}
function admissionRouteMarkup(config) {
  if (!config.admissionRoutes?.routes?.length) return '';
  return (
    '<h3>Alternative admission routes</h3><p>Meet every rule within at least one route, together with the common subject requirements above.</p>' +
    config.admissionRoutes.routes
      .map((route) => {
        return `<section class="admission-route"><h4>${esc(route.label)} · minimum ${esc(route.minimum_score)} ${esc(config.scoring?.label || 'APS')}</h4>${table(
          ['Subject combination', 'Minimum percentage / condition'],
          route.groups.map((g) => {
            const names =
              g.codes?.map(subjectDescription).join(' or ') ||
              'eligible subjects';
            const excluded = g.exclude_codes?.length
              ? ' (excluding ' +
                g.exclude_codes.map(subjectDescription).join(', ') +
                ')'
              : '';
            const specific = g.minimums
              ? Object.entries(g.minimums)
                  .map(
                    ([code, mark]) =>
                      subjectDescription(code) + ': ' + mark + '%',
                  )
                  .join('; ')
              : '';
            return `<tr><td>At least ${esc(g.count)} of ${esc(names)}${esc(excluded)}</td><td>${g.minimum === 0 ? 'No additional percentage cutoff' : esc(g.minimum) + '%'}${specific ? '; ' + esc(specific) : ''}${g.minimum_points != null ? '; combined NSC points at least ' + esc(g.minimum_points) : ''}</td></tr>`;
          }),
        )}</section>`;
      })
      .join('')
  );
}
function subjectRequirementSummary(o) {
  const config = o.config || {},
    parts = [];
  const groups = new Map();
  for (const g of config.subjectGroups || []) {
    if (!groups.has(g.group)) groups.set(g.group, []);
    groups
      .get(g.group)
      .push(subjectDescription(g.code) + ' ' + g.minimum + '%');
  }
  for (const choices of groups.values()) parts.push(choices.join(' or '));
  if (config.admissionRoutes?.routes?.length) {
    for (const route of config.admissionRoutes.routes) {
      const named = route.groups
        .filter((g) => g.codes?.length || g.minimum > 0)
        .map(
          (g) =>
            (g.codes?.length
              ? g.codes.map(subjectDescription).join(' or ')
              : 'Additional NSC subjects') +
            ' ' +
            g.minimum +
            '%',
        );
      parts.push(
        route.label +
          ' (' +
          route.minimum_score +
          ' ' +
          (config.scoring?.label || 'APS') +
          '): ' +
          named.join('; '),
      );
    }
  }
  return parts.length ? parts.join('; ') : 'Standard NSC subject combination';
}

function qualificationInformation(o, demoOffering = false) {
  const config = o.config || {},
    university = catalog.universities.find(
      (u) => String(u.UNIVERSITY_ID) === String(o.UNIVERSITY_ID),
    ),
    campusNames = campusLocations(university)
      .map((l) => l.CITY_NAME)
      .filter(Boolean),
    profileUrl =
      '/learner/university.html?id=' + encodeURIComponent(o.UNIVERSITY_ID),
    source = safeHttps(config.source),
    website = safeHttps(university?.WEBSITE),
    subjectName = (code) => subjectDescription(code),
    individual = [
      ...new Set([
        ...(config.requiredCodes || []),
        ...Object.keys(config.subjectMinimums || {}),
      ]),
    ],
    initialDocs = catalog.documentTypes.filter((d) =>
      isRequiredBeforeProvisional(d, config),
    ),
    finalDocs = catalog.documentTypes.filter((d) =>
      Boolean(d.IS_LOCKED_UNTIL_FINAL),
    );
  return /* HTML */ ` <section
    class="qualification-information"
    aria-label="Qualification information"
  >
    <h2>${esc(o.qualification)}</h2>
    <p>
      ${link(profileUrl, o.university)}${campusNames.length ? ' · ' + esc([...new Set(campusNames)].join(', ')) : ''}
    </p>
    <div class="review-meta">
      <p>
        <strong>Study area</strong
        ><br />${esc(o.program || 'See the university catalogue')}
      </p>
      <p><strong>Intake</strong><br />${esc(config.intake || 2028)}</p>
      <p>
        <strong
          >Minimum
          ${config.scoring ? esc(config.scoring.label || 'admission score') : 'APS'}</strong
        ><br />${config.minScore == null ? 'Not published' : esc(config.minScore) + (config.scoring ? '' : ' / 42')}
      </p>
      ${config.finalMinScore != null ? `<p><strong>Final NSC minimum score</strong><br>${esc(config.finalMinScore)}</p>` : ''}
      <p>
        <strong>Minimum English</strong
        ><br />${config.minEnglish == null ? 'See NSC subject requirements below' : esc(config.minEnglish) + '%'}
      </p>
      <p>
        <strong>Minimum Mathematics / Mathematical Literacy</strong
        ><br />${config.minMath == null ? 'See subject alternatives below' : esc(config.minMath) + '%'}
      </p>
      <p>
        <strong>Applications open</strong
        ><br />${esc(qualificationDate(config.openingDate))}
      </p>
      <p>
        <strong>Applications close</strong
        ><br />${esc(qualificationDate(o.APPLICATION_CLOSING_DATE))}${o.APPLICATION_CLOSING_DATE ? ' at ' + esc(config.closingTime || '23:59') + ' (South Africa)' : ''}
      </p>
    </div>
    <p>${esc(learnerAvailability(o.availability))}</p>
    ${config.notes && !config.catalogueOrigin ? `<p>${esc(config.notes)}</p>` : ''}
    ${demoOffering ? '<p class="notice"><strong>Simulated academic records.</strong> This synthetic profile is not official and must not be used for a real admission decision.</p>' : ''}
    <div class="actions">
      ${website ? `<a href="${esc(website)}" target="_blank" rel="noopener noreferrer">University website</a>` : ''}
      ${source && !demoOffering ? `<a href="${esc(source)}" target="_blank" rel="noopener noreferrer">University programme information</a>` : ''}
      ${link(profileUrl + '#prospectuses', 'University prospectuses')}
    </div>
    <h3>Subject requirements</h3>
    ${
      individual.length
        ? table(
            ['Subject', 'Minimum percentage'],
            individual.map(
              (code) =>
                `<tr><th>${esc(subjectName(code))}</th><td>${config.subjectMinimums?.[code] == null ? 'Subject required; minimum not published' : esc(config.subjectMinimums[code]) + '%'}</td></tr>`,
            ),
          )
        : ''
    }
    ${
      (config.subjectGroups || []).length
        ? `<p>Meet at least one subject alternative in each group.</p>${table(
            ['Group', 'Subject', 'Minimum percentage'],
            config.subjectGroups.map(
              (r) =>
                `<tr><td>${esc(r.group)}</td><th>${esc(subjectName(r.code))}</th><td>${esc(r.minimum)}%</td></tr>`,
            ),
          )}`
        : ''
    }
    ${!individual.length && !(config.subjectGroups || []).length && !config.admissionRoutes?.routes?.length ? '<p>The standard NSC subject combination applies.</p>' : ''}
    ${admissionRouteMarkup(config)}
    ${config.selectionNotes ? '<h3>Endorsement and additional selection</h3><p>' + esc(config.selectionNotes) + '</p>' : ''}
    ${config.requirementsBasis === 'existing_project_profile' ? '<p class="muted">This entry minimum is configured in Varsity Vault. Consult the linked university programme information before making an external application.</p>' : ''}
    ${config.sourceEdition ? '<p class="muted">Requirement sources: ' + esc(config.sourceEdition) + '. Application dates follow the configured intake calendar.</p>' : ''}
    <h3>How the admission score is calculated</h3>
    ${
      config.scoring
        ? `<p>${esc(config.scoring.label)}: ${esc(config.scoring.count)} subjects. ${config.scoring.exclude?.length ? 'Excluded subjects: ' + esc(config.scoring.exclude.map(subjectName).join(', ')) + '.' : ''}</p>
        ${
          config.scoring.mode === 'BANDS' && config.scoring.bands?.length
            ? table(
                ['Percentage', 'Points'],
                config.scoring.bands.map(
                  (b) =>
                    `<tr><td>${esc(b[0])}% to below ${esc(b[1])}%</td><td>${esc(b[2])}</td></tr>`,
                ),
              )
            : ''
        }
        ${
          (config.scoring.overrides || []).length
            ? table(
                ['Subject', 'Score weighting'],
                config.scoring.overrides.map(
                  (r) =>
                    `<tr><td>${esc((r.codes || []).map(subjectName).join(', '))}</td><td>${
                      r.bands
                        ? table(
                            ['Percentage', 'Points'],
                            r.bands.map(
                              (b) =>
                                '<tr><td>' +
                                esc(b[0]) +
                                '% to below ' +
                                esc(b[1]) +
                                '%</td><td>' +
                                esc(b[2]) +
                                '</td></tr>',
                            ),
                          )
                        : esc(r.weight ?? 1)
                    }</td></tr>`,
                ),
              )
            : ''
        }
        ${config.scoring.divisor && config.scoring.divisor !== 1 ? `<p>The selected total is divided by ${esc(config.scoring.divisor)}.</p>` : ''}`
        : '<p>Your standard APS uses up to six academic subjects, with 1–7 points per subject and Life Orientation excluded. University-specific admission rules take precedence.</p>'
    }
    ${config.scoring?.bonuses?.length ? '<h4>Additional score rules</h4><ul>' + config.scoring.bonuses.map((b) => '<li>' + esc(subjectDescription(b.subject)) + ' at ' + esc(b.minimum) + '% or above: ' + esc(b.points) + ' additional points' + (b.quintiles?.length ? '; school quintile ' + esc(b.quintiles.join(', ')) + ' required' : '') + '</li>').join('') + '</ul>' : ''}
    <p>
      Record at least ${esc(config.minimumSubjectCount || 7)} NSC subjects. The
      configured calculation counts ${esc(config.scoring?.count || 6)} subjects.
    </p>
    <h3>Supporting documents</h3>
    <p>Prepare these documents for your initial application:</p>
    ${initialDocs.length ? '<ul>' + initialDocs.map((d) => `<li>${esc(d.DOCUMENT_TYPE_NAME)}</li>`).join('') + '</ul>' : '<p>Consult the university for its document checklist.</p>'}
    ${finalDocs.length ? '<p>For the final-results stage, when requested:</p><ul>' + finalDocs.map((d) => `<li>${esc(d.DOCUMENT_TYPE_NAME)}</li>`).join('') + '</ul>' : ''}
    <p class="muted">
      Check the official programme page for duration, fees, campus-specific
      delivery and study modes. Meeting minimum requirements does not guarantee
      admission.
    </p>
  </section>`;
}
async function universityProfile() {
  const id = new URLSearchParams(location.search).get('id'),
    university = catalog.universities.find(
      (u) => String(u.UNIVERSITY_ID) === id,
    );
  if (!university) {
    show(
      title('University not found', 'Choose a university from the directory.') +
        link('/learner/universities.html', 'Browse universities'),
    );
    return;
  }
  const [offeringData, prospectusData] = await Promise.all([
      request('/api/offerings'),
      request('/api/prospectuses'),
    ]),
    programmes = offeringData.offerings.filter(
      (o) => String(o.UNIVERSITY_ID) === id,
    ),
    brochures = prospectusData.prospectuses.filter(
      (p) => String(p.UNIVERSITY_ID) === id,
    ),
    locations = campusLocations(university),
    website = safeHttps(university.WEBSITE);
  show(
    title(
      university.UNIVERSITY_NAME,
      'University information and qualifications for 2028 entry.',
    ) +
      `
    <section class="panel">
      ${link('/learner/universities.html', 'All universities')}
      <h2>University information</h2>
      ${website ? `<p><a href="${esc(website)}" target="_blank" rel="noopener noreferrer">Visit the university website</a></p>` : '<p>University website not provided.</p>'}
      <h3>Campus cities and towns</h3>
      ${
        locations.length
          ? table(
              ['City / town', 'Province', 'Street address'],
              locations.map(
                (a) =>
                  `<tr><th>${esc(a.CITY_NAME || 'Not provided')}</th><td>${esc(a.PROVINCE_NAME || 'Not provided')}</td><td>${esc(a.STREET_NAME || 'See the university website for campus directions')}</td></tr>`,
              ),
            )
          : '<p>Campus locations are not provided. Check the university website.</p>'
      }
      <p class="muted">Locations describe the university, not the delivery campus of every qualification. Confirm your qualification’s campus with the university.</p>
    </section>
    <section class="panel" id="prospectuses">
      <h2>Prospectuses</h2>
      ${brochures.length ? '<ul>' + brochures.map((p) => `<li><a href="/api/prospectuses/${encodeURIComponent(p.PROSPECTUS_ID)}/download">${esc(p.PROSPECTUS_FILENAME || 'Download prospectus')}</a>${p.PROSPECTUS_DATE ? ' · ' + esc(p.PROSPECTUS_DATE) : ''}</li>`).join('') + '</ul>' : `<p>No prospectus file has been uploaded here.${website ? ` Find the latest prospectus on the <a href="${esc(website)}" target="_blank" rel="noopener noreferrer">university website</a>.` : ''}</p>`}
    </section>
    <section class="panel">
      <h2>Qualifications (${programmes.length})</h2>
      ${table(
        [
          'Qualification',
          'Study area',
          'Minimum score',
          'Subject requirements',
          'Closing date',
          'Details',
        ],
        programmes.map(
          (o) =>
            `<tr><th>${esc(o.qualification)}</th><td>${esc(o.program || 'See programme information')}</td><td>${o.config.minScore == null ? 'Not published' : esc(o.config.minScore) + ' ' + esc(o.config.scoring?.label || 'APS')}</td><td>${esc(subjectRequirementSummary(o))}</td><td>${esc(qualificationDate(o.APPLICATION_CLOSING_DATE))}</td><td>${link('/learner/requirements.html?offeringId=' + encodeURIComponent(o.UNI_QUAL_ID), 'View requirements')}</td></tr>`,
        ),
      )}
    </section>`,
  );
}

async function requirements() {
  offerings = (await request('/api/offerings')).offerings;
  let learnerDocuments = [],
    learnerApplications = [],
    learnerRecordsLoaded = true;
  if (user.role === 'learner') {
    const [documentsResult, applicationsResult] = await Promise.allSettled([
      request('/api/documents'),
      request('/api/applications'),
    ]);
    if (documentsResult.status === 'fulfilled')
      learnerDocuments = documentsResult.value.documents || [];
    else learnerRecordsLoaded = false;
    if (applicationsResult.status === 'fulfilled')
      learnerApplications = applicationsResult.value.applications || [];
    else learnerRecordsLoaded = false;
  }
  show(
    title(
      'Qualification requirements',
      'Explore university information and admission requirements, then compare your results and prepare an application.',
    ) +
      /* HTML */ `
        <section class="panel">
          <ol class="application-steps" aria-label="Application steps">
            <li data-wizard-indicator="1">1. University and results</li>
            <li data-wizard-indicator="2">2. Choose programme</li>
            <li data-wizard-indicator="3">3. Review and apply</li>
          </ol>
          <div class="fields" id="wizard-context">
            <label>
              University
              <select id="university">
                ${select(catalog.universities, 'UNIVERSITY_ID', 'UNIVERSITY_NAME')}
              </select>
            </label>
            ${examSelect()}
          </div>
          <div id="wizard-programme">
            <label class="search">
              Programme
              <select id="offering"></select>
            </label>
          </div>
          <div id="requirements-content"></div>
          <div class="actions application-step-actions">
            <button type="button" class="secondary" id="wizard-back">
              Previous step
            </button>
            <button type="button" id="wizard-next">Choose programme</button>
          </div>
        </section>
      `,
  );
  let wizardStep = 1;
  function setWizardStep(step) {
    wizardStep = step;
    document.querySelector('#wizard-context').hidden = step !== 1;
    document.querySelector('#wizard-programme').hidden = step !== 2;
    document.querySelector('#requirements-content').hidden = step !== 3;
    document.querySelector('#wizard-back').hidden = step === 1;
    document.querySelector('#wizard-next').hidden = step === 3;
    document.querySelector('#wizard-next').textContent =
      step === 1 ? 'Choose programme' : 'Review requirements';
    document.querySelectorAll('[data-wizard-indicator]').forEach((item) => {
      if (Number(item.dataset.wizardIndicator) === step)
        item.setAttribute('aria-current', 'step');
      else item.removeAttribute('aria-current');
    });
  }
  document
    .querySelector('#wizard-back')
    .addEventListener('click', () => setWizardStep(wizardStep - 1));
  document.querySelector('#wizard-next').addEventListener('click', () => {
    if (
      wizardStep === 1 &&
      (!document.querySelector('#university').value ||
        !document.querySelector('#exam').value)
    ) {
      feedback('Choose a university and examination milestone.');
      return;
    }
    if (wizardStep === 2 && !document.querySelector('#offering').value) {
      feedback('Choose a programme before reviewing your application.');
      return;
    }
    feedback('');
    setWizardStep(wizardStep + 1);
  });
  setWizardStep(1);
  const params = new URLSearchParams(location.search),
    requestedExam = params.get('examTypeId'),
    remembered = rememberedExam();
  if (
    requestedExam &&
    catalog.examTypes.some(
      (item) => String(item.EXAM_TYPE_ID) === String(requestedExam),
    )
  )
    document.querySelector('#exam').value = String(requestedExam);
  else {
    const summary = await request('/api/results/summary'),
      saved = new Set((summary.examTypeIds || []).map(String));
    const rememberedHasResults = saved.has(String(remembered));
    const latestSaved = [...catalog.examTypes]
      .reverse()
      .find((item) => saved.has(String(item.EXAM_TYPE_ID)));
    const preferred = rememberedHasResults
      ? remembered
      : (latestSaved?.EXAM_TYPE_ID ?? remembered);
    if (
      catalog.examTypes.some(
        (item) => String(item.EXAM_TYPE_ID) === String(preferred),
      )
    )
      document.querySelector('#exam').value = String(preferred);
  }
  let assessmentRequest = 0;
  const load = async () => {
    const requestVersion = ++assessmentRequest;
    document.querySelector('#requirements-content').innerHTML =
      '<p role="status">Checking requirements…</p>';
    const universityId = document.querySelector('#university').value,
      examId = Number(document.querySelector('#exam').value),
      offerId = document.querySelector('#offering').value,
      o = offerings.find(
        (item) => String(item.UNI_QUAL_ID) === String(offerId),
      ),
      demoOffering =
        !!o &&
        (String(o.university || '').startsWith('DEMO -') ||
          String(o.qualification || '').startsWith('DEMO -') ||
          /DEMO ONLY|Simulated academic profile/.test(
            String(o.config?.notes || ''),
          ));
    const assessment = o
      ? await request(
          '/api/offerings/' + offerId + '/requirements?examTypeId=' + examId,
        )
      : assessSubjects(
          (await request('/api/results?examTypeId=' + examId)).rows,
          null,
          {},
        );
    if (requestVersion !== assessmentRequest) return;
    const grade11 = catalog.examTypes.find(
        (item) => item.EXAM_TYPE_NAME === 'Grade 11 Final',
      ),
      isApplicationMilestone =
        !grade11 ||
        String(document.querySelector('#exam').value) ===
          String(grade11.EXAM_TYPE_ID),
      requiredDocs = catalog.documentTypes.filter((item) =>
        isRequiredBeforeProvisional(item, o?.config),
      ),
      missingDocs = requiredDocs.filter(
        (type) =>
          !learnerDocuments.some(
            (doc) =>
              String(doc.DOCUMENT_TYPE_ID) === String(type.DOCUMENT_TYPE_ID),
          ),
      ),
      closingDate = String(o?.APPLICATION_CLOSING_DATE || '').slice(0, 10),
      today = new Intl.DateTimeFormat('en-CA', {
        timeZone: 'Africa/Johannesburg',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
      }).format(new Date()),
      deadlineOpen = o?.availability
        ? o.availability === 'Open'
        : /^\d{4}-\d{2}-\d{2}$/.test(closingDate) && closingDate >= today,
      alreadyApplied =
        !!o &&
        learnerApplications.some(
          (item) =>
            String(item.UNI_QUAL_ID) === String(o.UNI_QUAL_ID) &&
            Number(item.ACADEMIC_YEAR) === 2028,
        ),
      studyModesAvailable =
        Array.isArray(catalog.studyModes) && catalog.studyModes.length > 0,
      ready =
        !!assessment.eligible &&
        isApplicationMilestone &&
        !missingDocs.length &&
        learnerRecordsLoaded &&
        deadlineOpen &&
        !alreadyApplied;
    const readiness = o
      ? /* HTML */ `
          <ul class="apply-checklist">
            <li
              class="${isApplicationMilestone && assessment.eligible ? 'is-ready' : 'is-pending'}"
            >
              <span
                >${isApplicationMilestone && assessment.eligible ? 'Ready' : 'Check'}</span
              >
              ${isApplicationMilestone ? (assessment.eligible ? 'Grade 11 Final results meet the listed requirements.' : /requirements pending verification/i.test(assessment.status) ? 'Check the university information for admission requirements before comparing your results.' : 'Complete your Grade 11 Final results and compare them with the listed requirements.') : `Select Grade 11 Final to check application eligibility.`}
            </li>
            ${requiredDocs
              .map((type) => {
                const uploaded = !missingDocs.some(
                  (item) =>
                    String(item.DOCUMENT_TYPE_ID) ===
                    String(type.DOCUMENT_TYPE_ID),
                );
                return /* HTML */ `
                  <li class="${uploaded ? 'is-ready' : 'is-pending'}">
                    <span>${uploaded ? 'Ready' : 'Needed'}</span>
                    ${esc(type.DOCUMENT_TYPE_NAME)}${
                      uploaded
                        ? ' uploaded'
                        : /* HTML */ `
                            ·
                            <a href="/learner/documents.html"
                              >Upload in Documents</a
                            >
                          `
                    }
                  </li>
                `;
              })
              .join('')}${
              !learnerRecordsLoaded
                ? /* HTML */ `
                    <li class="is-pending">
                      <span>Check</span>
                      Could not confirm your documents and existing
                      applications. Reload this page to try again.
                    </li>
                  `
                : ''
            }
            <li class="${deadlineOpen ? 'is-ready' : 'is-pending'}">
              <span
                >${esc(learnerAvailability(o?.availability || (deadlineOpen ? 'Open' : 'Closed')))}</span
              >
              Application deadline: ${esc(closingDate || 'not confirmed')}
            </li>
            ${
              alreadyApplied
                ? /* HTML */ `
                    <li class="is-pending">
                      <span>Already applied</span>
                      You already submitted an application for this programme in
                      2028.
                      <a href="/learner/applications.html"
                        >View your application</a
                      >
                    </li>
                  `
                : ''
            }
          </ul>
        `
      : '';
    document.querySelector('#requirements-content').innerHTML = /* HTML */ `
      <div class="split">
        <section>
          <h2>${esc(assessment.metric)}</h2>
          <div class="score">
            ${assessment.total === null ? 'Not calculated' : assessment.total}
          </div>
          ${table(
            [
              'Subject',
              'Percentage',
              o?.config.scoring ? 'Score contribution' : 'APS points',
            ],
            assessment.contributions.map(
              (row) => /* HTML */ `
                <tr>
                  <th>${esc(row.SUBJECT_NAME)}</th>
                  <td>${row.PERCENTAGE}%</td>
                  <td>${row.points}</td>
                </tr>
              `,
            ),
          )}
          <p class="muted">
            ${o?.config.scoring ? 'This programme uses its configured subject selection, weights and score scale.' : 'Life Orientation is excluded. Each academic subject contributes 1–7 points; the total uses up to six subjects.'}
          </p>
        </section>
        <section class="requirements-review">
          <div class="notice">
            <strong>${esc(learnerAssessmentStatus(assessment.status))}</strong>
            ${assessment.contextNote ? '<p>' + esc(assessment.contextNote) + '</p>' : ''}
            ${assessment.routeLabel ? '<p>Assessed route: ' + esc(assessment.routeLabel) + '; minimum ' + esc(assessment.requiredScore) + ' ' + esc(o?.config.scoring?.label || 'APS') + '.</p>' : ''}
            ${assessment.scoreBonus ? '<p>The total includes ' + esc(assessment.scoreBonus) + ' additional points under this programme scoring policy.</p>' : ''}
            ${assessment.issues
              .map((issue) => /* HTML */ ` <p>${esc(issue)}</p> `)
              .join('')}
          </div>
          ${
            o
              ? /* HTML */ `
                  ${qualificationInformation(o, demoOffering)}
                  <div class="apply-panel">
                    <span class="section-kicker">Your next step</span>
                    <h3>Apply for ${esc(o.qualification)}</h3>
                    <p>
                      Submit your application here. Eligibility is checked using
                      Grade 11 Final results. Your teacher reviews the
                      submission before it goes to the university
                      representative.
                    </p>
                    ${readiness}${
                      grade11 && !isApplicationMilestone
                        ? /* HTML */ `
                            <div class="actions">
                              <button
                                type="button"
                                class="secondary"
                                id="review-grade11"
                              >
                                Review Grade 11 eligibility
                              </button>
                            </div>
                          `
                        : ''
                    }${
                      assessment.eligible && isApplicationMilestone
                        ? /* HTML */ `
                            ${
                              studyModesAvailable
                                ? /* HTML */ `
                                    <label>
                                      Study mode
                                      <select id="study-mode" required>
                                        <option value="" selected disabled>
                                          Choose a study mode
                                        </option>
                                        ${select(catalog.studyModes, 'STUDY_MODE_ID', 'STUDY_MODE_NAME')}
                                      </select>
                                    </label>
                                  `
                                : /* HTML */ `
                                    <div class="notice" role="status">
                                      <strong
                                        >Study modes are not configured</strong
                                      >
                                      <p>
                                        Ask the IT administrator to add
                                        Full-time or Part-time in Academic
                                        Lookups. Applications cannot be
                                        submitted until a study mode is
                                        available.
                                      </p>
                                    </div>
                                  `
                            }
                            <div class="actions">
                              ${
                                ready && studyModesAvailable
                                  ? /* HTML */ `
                                      <label class="application-confirmation">
                                        <span>
                                          <input
                                            id="application-confirm"
                                            type="checkbox"
                                          />
                                          I checked the programme requirements
                                          and my supporting documents.
                                        </span>
                                      </label>
                                      <button id="apply" type="button">
                                        Submit application
                                        <i
                                          data-lucide="arrow-right"
                                          aria-hidden="true"
                                        ></i>
                                      </button>
                                    `
                                  : !studyModesAvailable
                                    ? ''
                                    : /* HTML */ `
                                        <a
                                          class="button-link secondary"
                                          href="/learner/results.html"
                                        >
                                          Review my results
                                          <i
                                            data-lucide="arrow-right"
                                            aria-hidden="true"
                                          ></i>
                                        </a>
                                        <a
                                          class="button-link secondary"
                                          href="/learner/documents.html"
                                        >
                                          Prepare documents
                                          <i
                                            data-lucide="arrow-right"
                                            aria-hidden="true"
                                          ></i>
                                        </a>
                                      `
                              }
                            </div>
                          `
                        : /* HTML */ `
                            <p class="muted">
                              Complete the checklist above before submitting.
                              Applications are assessed using the published
                              admission requirements and your Grade 11 Final
                              results.
                            </p>
                            <div class="actions">
                              <a
                                class="button-link"
                                href="/learner/results.html"
                              >
                                Review my results
                                <i
                                  data-lucide="arrow-right"
                                  aria-hidden="true"
                                ></i>
                              </a>
                              <a
                                class="button-link secondary"
                                href="/learner/documents.html"
                              >
                                Prepare documents
                                <i
                                  data-lucide="arrow-right"
                                  aria-hidden="true"
                                ></i>
                              </a>
                            </div>
                          `
                    }
                  </div>
                `
              : '<p>No programme is listed for this university yet. You can still review your standard APS; check back when the university publishes its programme listing.</p>'
          }
          <p class="muted">
            Meeting listed minimums does not guarantee an admission offer.
          </p>
        </section>
      </div>
    `;
    document.querySelector('#review-grade11')?.addEventListener('click', () => {
      document.querySelector('#exam').value = String(grade11.EXAM_TYPE_ID);
      document
        .querySelector('#exam')
        .dispatchEvent(new Event('change', { bubbles: true }));
    });
    document.querySelector('#apply')?.addEventListener(
      'click',
      guard(async () => {
        if (!document.querySelector('#application-confirm')?.checked) {
          feedback(
            'Confirm that you checked the requirements and supporting documents.',
          );
          return;
        }
        const studyModeId = Number(
          document.querySelector('#study-mode')?.value,
        );
        if (!Number.isInteger(studyModeId) || studyModeId < 1) {
          feedback('Choose a study mode before submitting your application.');
          return;
        }
        const out = await request('/api/applications', 'POST', {
          offeringId: Number(offerId),
          studyModeId,
        });
        learnerApplications.push({
          UNI_QUAL_ID: o.UNI_QUAL_ID,
          ACADEMIC_YEAR: 2028,
        });
        await load();
        feedback(out.message);
      }),
    );
    icons();
  };
  const updateOptions = async (selectedOfferingId = '') => {
    const universityId = document.querySelector('#university').value,
      available = offerings.filter(
        (item) => String(item.UNIVERSITY_ID) === String(universityId),
      );
    document.querySelector('#offering').innerHTML =
      '<option value="">APS overview only</option>' +
      available
        .map(
          (item) => /* HTML */ `
            <option value="${item.UNI_QUAL_ID}">
              ${esc(item.qualification)}
            </option>
          `,
        )
        .join('');
    if (
      available.some(
        (item) => String(item.UNI_QUAL_ID) === String(selectedOfferingId),
      )
    )
      document.querySelector('#offering').value = String(selectedOfferingId);
    await load();
  };
  document.querySelector('#university').addEventListener(
    'change',
    guard(() => updateOptions(), true),
  );
  document
    .querySelector('#offering')
    .addEventListener('change', guard(load, true));
  document.querySelector('#exam').addEventListener(
    'change',
    guard(async () => {
      rememberExam(document.querySelector('#exam').value);
      await load();
    }, true),
  );
  const requested = offerings.find(
    (item) => String(item.UNI_QUAL_ID) === params.get('offeringId'),
  );
  if (requested) {
    document.querySelector('#university').value = String(
      requested.UNIVERSITY_ID,
    );
    await updateOptions(requested.UNI_QUAL_ID);
    setWizardStep(3);
  } else await updateOptions();
}
async function subjectsPage() {
  show(
    title(
      'My Subjects',
      'Review saved marks and any unsaved changes for each examination milestone.',
    ) +
      /* HTML */ `
        <section class="panel">
          <div class="fields">${examSelect()}</div>
          <div id="subject-records"></div>
          <div class="actions" id="subject-actions"></div>
        </section>
      `,
  );
  const examControl = document.querySelector('#exam'),
    preferred = rememberedExam();
  if (
    catalog.examTypes.some(
      (item) => String(item.EXAM_TYPE_ID) === String(preferred),
    )
  )
    examControl.value = String(preferred);
  const load = async () => {
    const examId = Number(examControl.value),
      out = await request('/api/results?examTypeId=' + examId),
      saved = out.rows || [];
    let rows = saved,
      draft = readLearnerResultsDraft(examId),
      state = saved.length
        ? 'Saved for this milestone'
        : 'No results saved for this milestone';
    if (Array.isArray(draft) && sameResultRows(draft, saved))
      clearLearnerResultsDraft(examId);
    else if (Array.isArray(draft)) {
      rows = draft;
      state = 'Draft · not saved';
    }
    const examName =
      catalog.examTypes.find(
        (item) => String(item.EXAM_TYPE_ID) === String(examId),
      )?.EXAM_TYPE_NAME || 'Selected milestone';
    document.querySelector('#subject-records').innerHTML =
      /* HTML */ `<h2>${esc(examName)}</h2><p class="muted">${esc(state)}</p>` +
      table(
        ['Subject', 'Category', 'Percentage'],
        rows.map(
          (row) => /* HTML */ `
            <tr>
              <th>
                ${esc(row.SUBJECT_NAME || catalog.subjects.find((subject) => String(subject.SUBJECT_ID) === String(row.SUBJECT_ID))?.SUBJECT_NAME || 'Subject')}
              </th>
              <td>
                ${esc({ HOME_LANGUAGE: 'Home language', FIRST_ADDITIONAL_LANGUAGE: 'First additional language', MATHEMATICS: 'Mathematics', MATHEMATICAL_LITERACY: 'Mathematical literacy', LIFE_ORIENTATION: 'Life Orientation', ELECTIVE: 'Elective' }[row.SUBJECT_CATEGORY] || 'Other subject')}
              </td>
              <td>
                ${row.PERCENTAGE == null ? 'Not entered' : esc(row.PERCENTAGE) + '%'}
              </td>
            </tr>
          `,
        ),
      );
    document.querySelector('#subject-actions').innerHTML = link(
      '/learner/results.html?examTypeId=' + encodeURIComponent(examId),
      'Add or update results',
    );
  };
  document.querySelector('#exam').addEventListener('change', guard(load));
  await load();
}
async function documentsPage() {
  let learners = [];
  if (user.role === 'teacher')
    learners = (await request('/api/teacher/learners')).learners;
  show(
    title(
      'Documents',
      user.role === 'teacher'
        ? 'Download reports and identity documents before verifying.'
        : 'Upload PDF, PNG or JPEG documents up to 6 MB.',
    ) +
      /* HTML */ `
        <section class="panel">
          ${
            user.role === 'teacher'
              ? /* HTML */ `
                  <div class="fields">
                    <label>
                      Learner
                      <select id="learner">
                        ${select(learners, 'PERSON_ID', 'name')}
                      </select>
                    </label>
                  </div>
                `
              : ''
          }
          <div id="documents-grid"></div>
          ${
            user.role === 'learner'
              ? /* HTML */ `
                  <form id="upload">
                    <div class="fields">
                      <label>
                        Document type
                        <select name="type">
                          ${select(catalog.documentTypes, 'DOCUMENT_TYPE_ID', 'DOCUMENT_TYPE_NAME')}
                        </select>
                      </label>
                      <label>
                        File
                        <input
                          name="file"
                          type="file"
                          accept="application/pdf,image/png,image/jpeg"
                          required
                        />
                      </label>
                    </div>
                    <button>Upload document</button>
                  </form>
                `
              : ''
          }
        </section>
      `,
  );
  const load = async () => {
    const learner = document.querySelector('#learner')?.value;
    if (user.role === 'teacher' && !learner) return;
    const { documents } = await request(
      '/api/documents' + (learner ? '?learnerId=' + learner : ''),
    );
    document.querySelector('#documents-grid').innerHTML = table(
      ['Document', 'Uploaded', 'Verification', 'Action'],
      documents.map(
        (d) => /* HTML */ `
          <tr>
            <th>${esc(d.DOCUMENT_NAME)}</th>
            <td>${esc(d.UPLOAD_DATE)}</td>
            <td>${esc(verifiedLabel(d.VERIFICATION_STATUS_ID))}</td>
            <td>
              <a href="/api/documents/${d.DOCUMENT_ID}/download">Download</a>
              ${
                user.role === 'teacher'
                  ? /* HTML */ `
                      <button
                        class="secondary compact"
                        data-doc="${d.DOCUMENT_ID}"
                      >
                        Verify
                      </button>
                      <button
                        class="secondary compact"
                        data-reject="${d.DOCUMENT_ID}"
                      >
                        Reject
                      </button>
                    `
                  : ''
              }
            </td>
          </tr>
        `,
      ),
    );
    for (const [attribute, decision] of [
      ['data-doc', 'Verified'],
      ['data-reject', 'Rejected'],
    ])
      document.querySelectorAll('[' + attribute + ']').forEach((b) =>
        b.addEventListener(
          'click',
          guard(async () => {
            feedback(
              (
                await request('/api/teacher/verify', 'POST', {
                  learnerId: Number(learner),
                  documentId: Number(b.getAttribute(attribute)),
                  decision,
                })
              ).message,
            );
            await load();
          }),
        ),
      );
  };
  document.querySelector('#learner')?.addEventListener('change', guard(load));
  document.querySelector('#upload')?.addEventListener(
    'submit',
    guard(async (e) => {
      e.preventDefault();
      const form = e.target,
        file = form.elements.namedItem('file'),
        type = form.elements.namedItem('type');
      feedback(
        (
          await upload('/api/documents', file.files[0], {
            'X-Document-Type': type.value,
          })
        ).message,
      );
      await load();
      form.reset();
    }),
  );
  await load();
}
async function prospectuses() {
  const data = await request('/api/prospectuses'),
    universityNames = new Map(
      catalog.universities.map((item) => [
        String(item.UNIVERSITY_ID),
        item.UNIVERSITY_NAME,
      ]),
    );
  show(
    title(
      'Prospectuses',
      user.role === 'representative'
        ? 'Share the latest official prospectus with learners.'
        : 'Download university prospectuses to explore programme options.',
    ) +
      /* HTML */ `
        <section class="panel">
          ${table(
            ['University', 'Prospectus', 'Published'],
            data.prospectuses.map(
              (item) => /* HTML */ `
                <tr>
                  <th>
                    ${esc(universityNames.get(String(item.UNIVERSITY_ID)) || 'University')}
                  </th>
                  <td>
                    <a
                      href="/api/prospectuses/${encodeURIComponent(item.PROSPECTUS_ID)}/download"
                    >
                      ${esc(item.PROSPECTUS_FILENAME)}
                    </a>
                  </td>
                  <td>${esc(item.PROSPECTUS_DATE)}</td>
                </tr>
              `,
            ),
          )}
        </section>
        ${
          user.role === 'representative'
            ? /* HTML */ `
                <section class="panel">
                  <h2>Upload a prospectus</h2>
                  <form id="prospectus-upload">
                    <div class="fields">
                      <label>
                        PDF prospectus
                        <input
                          type="file"
                          name="file"
                          accept="application/pdf"
                          required
                        />
                      </label>
                    </div>
                    <button>Upload prospectus</button>
                  </form>
                  <p class="muted">
                    Use a current, official prospectus in PDF format, up to 6
                    MB.
                  </p>
                </section>
              `
            : ''
        }
      `,
  );
  document.querySelector('#prospectus-upload')?.addEventListener(
    'submit',
    guard(async (event) => {
      event.preventDefault();
      const file = event.target.elements.namedItem('file').files[0];
      if (!file) return;
      await api('/api/prospectuses', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/pdf',
          'X-CSRF-Token': csrf,
          'X-File-Name': encodeURIComponent(file.name),
        },
        body: await file.arrayBuffer(),
      });
      await prospectuses();
      feedback('Prospectus uploaded.');
    }),
  );
}
function applicationEvidenceMarkup(out) {
  return (
    '<h2>Applicant Evidence</h2>' +
    (out.resultBindings?.length
      ? '<p>Attached result versions: ' +
        out.resultBindings
          .map(
            (v) =>
              v.resultVersion +
              ' (' +
              esc(
                catalog.examTypes.find(
                  (e) => String(e.EXAM_TYPE_ID) === String(v.examId),
                )?.EXAM_TYPE_NAME || 'Milestone',
              ) +
              ')',
          )
          .join(', ') +
        '</p>'
      : '') +
    out.exams
      .map(
        (ex) => /* HTML */ `
          <h3>${esc(ex.name)}</h3>
          ${table(
            ['Subject', 'Mark', 'Verification'],
            ex.rows.map(
              (r) => /* HTML */ `
                <tr>
                  <td>${esc(r.SUBJECT_NAME)}</td>
                  <td>${r.PERCENTAGE}%</td>
                  <td>${esc(verifiedLabel(r.VERIFICATION_STATUS_ID))}</td>
                </tr>
              `,
            ),
          )}
        `,
      )
      .join('') +
    table(
      ['Document', 'Verification', 'Download'],
      out.documents.map(
        (d) => /* HTML */ `
          <tr>
            <td>${esc(d.DOCUMENT_NAME)}</td>
            <td>${esc(verifiedLabel(d.VERIFICATION_STATUS_ID))}</td>
            <td>
              <a href="/api/documents/${d.DOCUMENT_ID}/download">Download</a>
            </td>
          </tr>
        `,
      ),
    )
  );
}
async function applicationsPage() {
  const { applications } = await request('/api/applications');
  const allowed =
    user.role === 'teacher'
      ? { Submitted: ['Screened by Career Teacher'] }
      : user.role === 'representative'
        ? {
            'Screened by Career Teacher': [
              'Provisionally Accepted',
              'Rejected',
            ],
            'Provisionally Accepted': ['Final Matric Verified'],
            'Final Matric Verified': ['Admitted', 'Offer Revoked'],
          }
        : {};
  show(
    title(
      page === 'decisions' ? 'Admission Decisions' : 'Applications',
      user.role === 'representative'
        ? 'To update a status: open Review application, check the evidence, choose the next status, then save your decision.'
        : 'Track verification, decisions and the permanent application timeline.',
    ) +
      (user.role === 'learner'
        ? /* HTML */ `
            <section class="panel" aria-labelledby="start-application-title">
              <h2 id="start-application-title">
                ${applications.length ? 'Apply to another programme' : 'Start your first application'}
              </h2>
              <p>
                Choose a university and programme, compare your Grade 11 Final
                results with its entry requirements, and submit your application
                once your required documents are uploaded.
              </p>
              <a
                class="button-link"
                id="start-application"
                href="/learner/requirements.html"
              >
                Start an application
              </a>
            </section>
          `
        : '') +
      /* HTML */ `
        ${user.role === 'learner' ? '<p class="notice">Your saved results and documents are available automatically. Ask your career educator to verify them so that the university can review your current evidence.</p>' : ''}
        <section class="panel application-list">
          <div class="fields application-filters">
            <label>
              Search applications
              <input
                id="application-search"
                type="search"
                placeholder="Learner, university or programme"
              />
            </label>
            <label>
              Application status
              <select id="application-status-filter">
                <option value="">All statuses</option>
                ${(catalog.applicationStatuses || [...new Set(applications.map((a) => a.status))].map((STATUS_NAME) => ({ STATUS_NAME }))).map((row) => '<option value="' + esc(row.STATUS_NAME) + '">' + esc(row.STATUS_NAME) + '</option>').join('')}
              </select>
            </label>
          </div>
          <p id="application-count" class="form-help" role="status"></p>
          ${table(
            ['Learner', 'Qualification', 'Status', 'Actions'],
            applications.map(
              (a) => /* HTML */ `
                <tr
                  data-application-status="${esc(a.status)}"
                  data-application-search="${esc([a.learnerName, a.offering.qualification, a.offering.university].join(' ').toLowerCase())}"
                >
                  <th>${esc(a.learnerName)}</th>
                  <td>
                    ${esc(a.offering.qualification)}
                    <small class="cell-note">
                      ${esc(a.offering.university)} · ${a.ACADEMIC_YEAR}
                    </small>
                  </td>
                  <td>
                    ${badge(a.status)}${user.role === 'representative' ? `<small class="cell-note">${esc({ Submitted: 'Waiting for career educator screening', 'Screened by Career Teacher': 'Ready for a university review', 'Provisionally Accepted': 'Next: verify final matric evidence', 'Final Matric Verified': 'Next: record the final admission decision', Admitted: 'Admission completed', Rejected: 'Application decision completed', 'Offer Revoked': 'Offer revocation completed' }[a.status] || 'Open the application to review its next step')}</small>` : ''}
                  </td>
                  <td>
                    <button
                      class="secondary compact"
                      data-history="${a.APPLICATION_ID}"
                    >
                      Timeline
                    </button>
                    ${user.role === 'learner' && !['Rejected', 'Admitted', 'Offer Revoked'].includes(a.status) ? `<button class="secondary compact" data-supply="${a.APPLICATION_ID}">Notify reviewer of verified results</button>` : ''}
                    ${(user.role === 'representative'
                      ? []
                      : allowed[a.status] || []
                    )
                      .map(
                        (status) => /* HTML */ `
                          <button
                            class="secondary compact"
                            data-transition="${a.APPLICATION_ID}"
                            data-status="${status}"
                          >
                            ${esc(user.role === 'teacher' ? 'Screen application' : status)}
                          </button>
                        `,
                      )
                      .join('')}${
                      user.role === 'representative'
                        ? /* HTML */ `
                            <button
                              class="compact"
                              data-review="${a.APPLICATION_ID}"
                            >
                              ${['Admitted', 'Rejected', 'Offer Revoked'].includes(a.status) ? 'View application' : 'Review application'}
                            </button>
                          `
                        : ''
                    }
                  </td>
                </tr>
              `,
            ),
          )}
        </section>
        <section class="panel" id="detail" aria-live="polite" hidden></section>
      `,
  );
  const filterApplications = () => {
    const query = document
      .querySelector('#application-search')
      .value.trim()
      .toLowerCase();
    const status = document.querySelector('#application-status-filter').value;
    let visible = 0;
    document.querySelectorAll('[data-application-status]').forEach((row) => {
      row.hidden = Boolean(
        (query && !row.dataset.applicationSearch.includes(query)) ||
        (status && row.dataset.applicationStatus !== status),
      );
      if (!row.hidden) visible++;
    });
    document.querySelector('#application-count').textContent =
      visible +
      ' of ' +
      applications.length +
      ' applications' +
      (visible === 0 ? ' — no applications match your filters.' : '');
  };
  document
    .querySelector('#application-search')
    .addEventListener('input', filterApplications);
  document
    .querySelector('#application-status-filter')
    .addEventListener('change', filterApplications);
  filterApplications();
  document.querySelectorAll('[data-supply]').forEach((b) =>
    b.addEventListener(
      'click',
      guard(async () => {
        const app = applications.find(
          (a) => String(a.APPLICATION_ID) === b.dataset.supply,
        );
        const name = ['Submitted', 'Screened by Career Teacher'].includes(
          app.status,
        )
          ? 'Grade 11 Final'
          : 'Grade 12 Final (NSC)';
        const exam = catalog.examTypes.find((e) => e.EXAM_TYPE_NAME === name);
        if (!exam)
          throw new Error('Required examination milestone is not configured.');
        const result = await request(
          '/api/results?examTypeId=' + exam.EXAM_TYPE_ID,
        );
        const out = await request(
          '/api/applications/' + b.dataset.supply + '/supply-results',
          'POST',
          {
            examTypeId: exam.EXAM_TYPE_ID,
            resultVersion: result.resultVersion,
            reviewToken: app.reviewToken,
          },
        );
        await applicationsPage();
        feedback(out.message);
      }),
    ),
  );
  document.querySelectorAll('[data-transition]').forEach((b) =>
    b.addEventListener(
      'click',
      guard(async () => {
        const notes = window.prompt('Decision / review notes (optional):', '');
        if (notes === null) return;
        const out = await request(
          '/api/applications/' + b.dataset.transition + '/transition',
          'POST',
          {
            status: b.dataset.status,
            notes,
            reviewToken: applications.find(
              (a) => String(a.APPLICATION_ID) === b.dataset.transition,
            )?.reviewToken,
          },
        );
        await applicationsPage();
        feedback(out.message);
      }),
    ),
  );
  document.querySelectorAll('[data-history]').forEach((b) =>
    b.addEventListener(
      'click',
      guard(async () => {
        const out = await request(
            '/api/applications/' + b.dataset.history + '/timeline',
          ),
          detail = document.querySelector('#detail');
        detail.hidden = false;
        detail.innerHTML =
          /* HTML */ `<h2>Application Timeline</h2><ol class="timeline">` +
          out.timeline
            .map(
              (t) => /* HTML */ `
                <li>
                  <strong>${esc(t.status)}</strong>
                  <span>${esc(t.ACTION_DATE)} UTC</span>
                </li>
              `,
            )
            .join('') +
          '</ol>' +
          (out.resultBindings?.length
            ? '<h3>Result versions supplied</h3><ul>' +
              out.resultBindings
                .map(
                  (v) =>
                    '<li>Result version ' +
                    v.resultVersion +
                    ' · ' +
                    esc(
                      catalog.examTypes.find(
                        (e) => String(e.EXAM_TYPE_ID) === String(v.examId),
                      )?.EXAM_TYPE_NAME || 'Milestone',
                    ) +
                    ' · ' +
                    esc(v.recordedAt) +
                    '</li>',
                )
                .join('') +
              '</ul>'
            : '');
      }),
    ),
  );
  let reviewGeneration = 0;
  async function openReview(app) {
    const generation = ++reviewGeneration;
    const detail = document.querySelector('#detail');
    detail.hidden = false;
    detail.innerHTML =
      '<h2>Loading application review</h2><p>Checking the current status and evidence…</p>';
    detail.scrollIntoView?.({ block: 'start', behavior: 'smooth' });
    const review = await request(
      '/api/applications/' + app.APPLICATION_ID + '/review',
    );
    const evidence = review.canReviewEvidence
      ? await request('/api/applications/' + app.APPLICATION_ID + '/evidence')
      : null;
    if (generation !== reviewGeneration) return;
    const ready = review.actions.filter((action) => action.enabled);
    const blocked = review.actions.filter((action) => !action.enabled);
    detail.innerHTML = `
      <h2 id="review-title" tabindex="-1">Application review: ${esc(app.learnerName)}</h2>
      <p>${esc(app.offering.qualification)} · ${esc(app.offering.university)}</p>
      <p><strong>Current status:</strong> ${esc(review.currentStatus)}</p>
      <p>${esc(review.explanation)}</p>
      ${review.previousNotes ? `<p><strong>Previous review notes:</strong> ${esc(review.previousNotes)}</p>` : ''}
      ${
        (review.checklist || []).length
          ? '<section class="evidence-readiness"><h3>Evidence checklist</h3>' +
            table(
              ['Requirement', 'Ready', 'What happens next'],
              review.checklist.map(
                (check) =>
                  '<tr><th>' +
                  esc(check.label) +
                  '</th><td>' +
                  (check.ready ? 'Yes' : 'No') +
                  '</td><td>' +
                  esc(check.detail) +
                  (check.ready
                    ? ''
                    : '<small class="cell-note">Responsible: ' +
                      esc(check.owner) +
                      '</small>') +
                  '</td></tr>',
              ),
            ) +
            '</section>'
          : ''
      }
      ${blocked.length ? '<div class="notice"><h3>Action needed</h3><ul>' + blocked.map((action) => `<li><strong>${esc(action.label)}:</strong> ${esc(action.reason)}</li>`).join('') + '</ul></div>' : ''}
      ${
        review.actions.length
          ? `
        <form id="application-decision" class="decision-form">
          <h3>Update application status</h3>
          <label>Next status
            <select id="decision-status" name="status" required>
              <option value="" selected disabled>Choose the next status</option>
              ${review.actions.map((action) => `<option value="${esc(action.statusId ?? action.status)}">${esc(action.status)}${action.enabled ? '' : ' — review requirements below'}</option>`).join('')}
            </select>
          </label>
          <label>Review notes (optional)
            <textarea name="notes" maxlength="400" rows="3" placeholder="Record the reason for your decision (up to 400 characters)"></textarea>
          </label>
          <p id="decision-action-help" class="form-help" role="status">Choose a next status to see whether the application is ready.</p><button type="submit" disabled>Save decision</button>
          <p class="form-help">Saving records the status, your representative details, review date and decision history. The server checks the evidence again before saving.</p>
        </form>`
          : '<p><strong>No status update is available at this stage.</strong></p>'
      }
      <button type="button" id="refresh-application-review" class="secondary">Refresh review</button>
      ${evidence ? applicationEvidenceMarkup(evidence) : '<p>Applicant evidence becomes available to the university representative after career educator screening.</p>'}
    `;
    detail.querySelector('#review-title').focus?.({ preventScroll: true });
    detail.querySelector('#refresh-application-review').addEventListener(
      'click',
      guard(() => openReview(app)),
    );
    const decisionForm = detail.querySelector('#application-decision');
    const selectedAction = () =>
      review.actions.find(
        (action) =>
          String(action.statusId ?? action.status) ===
          decisionForm?.elements.status.value,
      );
    const updateDecisionControl = () => {
      const action = selectedAction();
      if (!decisionForm) return;
      decisionForm.querySelector('button[type="submit"]').disabled =
        !action?.enabled;
      detail.querySelector('#decision-action-help').textContent = action
        ? action.enabled
          ? 'Ready to record: ' + action.status + '.'
          : action.reason
        : 'Choose a next status to see whether the application is ready.';
    };
    decisionForm?.elements.status.addEventListener(
      'change',
      updateDecisionControl,
    );
    detail.querySelector('#application-decision')?.addEventListener(
      'submit',
      guard(async (event) => {
        event.preventDefault();
        const form = event.currentTarget;
        if (!form.reportValidity()) return;
        const action = selectedAction();
        if (!action?.enabled)
          throw new Error(action?.reason || 'Choose an available next status.');
        const status = action.status;
        const out = await request(
          '/api/applications/' + app.APPLICATION_ID + '/transition',
          'POST',
          {
            status,
            ...(action.statusId != null ? { statusId: action.statusId } : {}),
            notes: form.elements.notes.value.trim(),
            reviewToken: review.reviewToken,
          },
        );
        await applicationsPage();
        feedback(out.message);
      }),
    );
  }
  document.querySelectorAll('[data-review]').forEach((button) => {
    button.addEventListener(
      'click',
      guard(async () => {
        const app = applications.find(
          (a) => String(a.APPLICATION_ID) === button.dataset.review,
        );
        await openReview(app);
      }),
    );
  });
}
function pathwayProgress() {
  try {
    return JSON.parse(
      localStorage.getItem('vv-pathway-' + user.personId) || '{}',
    );
  } catch {
    return {};
  }
}
function savePathwayProgress(progress) {
  try {
    localStorage.setItem(
      'vv-pathway-' + user.personId,
      JSON.stringify(progress),
    );
  } catch {}
}
function syncPathwayWithResults(hasResults) {
  const progress = pathwayProgress();
  if (!hasResults || progress.resultsReady !== true) {
    delete progress.explored;
    delete progress.requirementsReviewed;
  }
  progress.resultsReady = hasResults;
  savePathwayProgress(progress);
}
function markPathwayVisit() {
  if (user.role !== 'learner') return;
  const progress = pathwayProgress();
  if (progress.resultsReady !== true) return;
  if (page === 'universities') progress.explored = true;
  if (page === 'requirements' && progress.explored === true)
    progress.requirementsReviewed = true;
  savePathwayProgress(progress);
}
function dashboardDate(value) {
  const date = new Date(value);
  return Number.isNaN(date.valueOf())
    ? 'Date unavailable'
    : new Intl.DateTimeFormat('en-ZA', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      }).format(date);
}
async function dashboard() {
  const summary = await request('/api/dashboard/summary'),
    { applications, applicationCount, actionQueue, counts } = summary,
    learner = user.role === 'learner';
  if (learner) syncPathwayWithResults(counts.results > 0);
  const journey = learner
    ? [
        {
          number: '01',
          icon: 'file-chart-column-increasing',
          title: 'Capture your results',
          description: 'Add Grade 11 or NSC marks to see your starting point.',
          href: '/learner/results.html',
          action: counts.results ? 'Review results' : 'Add results',
          complete: counts.results > 0,
        },
        {
          number: '02',
          icon: 'landmark',
          title: 'Explore universities',
          description:
            'Compare institutions and discover where you could study.',
          href: '/learner/universities.html',
          action: 'Explore universities',
          complete: counts.results > 0 && pathwayProgress().explored === true,
        },
        {
          number: '03',
          icon: 'list-checks',
          title: 'Check entry requirements',
          description:
            'Review subject rules, score scales and programme deadlines.',
          href: '/learner/requirements.html',
          action: 'Check requirements',
          complete:
            counts.results > 0 &&
            pathwayProgress().explored === true &&
            pathwayProgress().requirementsReviewed === true,
        },
        {
          number: '04',
          icon: 'send',
          title: 'Apply with confidence',
          description:
            'Choose a programme, check its requirements and submit from the programme review.',
          href: '/learner/requirements.html',
          action: applicationCount
            ? 'Apply to another programme'
            : 'Find a programme to apply',
          complete: applicationCount > 0,
        },
      ]
    : [];
  const activeStep = learner ? journey.findIndex((step) => !step.complete) : -1,
    active = learner ? journey[activeStep] : null;
  const heroActions = {
    learner: active
      ? { href: active.href, label: active.action }
      : { href: '/learner/applications.html', label: 'View applications' },
    teacher: actionQueue.length
      ? {
          href: '/teacher/applications.html',
          label: 'Review oldest submission',
        }
      : { href: '/teacher/results.html', label: 'Review learner results' },
    representative: actionQueue.length
      ? {
          href: '/representative/decisions.html',
          label: 'Review oldest application',
        }
      : {
          href: '/representative/applications.html',
          label: 'View applications',
        },
    admin: actionQueue.length
      ? {
          href: '/admin/offerings.html',
          label: 'Verify programme requirements',
        }
      : { href: '/admin/offerings.html', label: 'Manage 2028 offerings' },
  };
  const welcomeCopy = {
    learner:
      'Plan your journey from results to the right university application.',
    teacher:
      'Review the oldest learner submissions and keep verification moving.',
    representative:
      'Review teacher-screened applications and record admission decisions.',
    admin:
      'Keep university programme requirements accurate and source-verified.',
  }[user.role];
  const journeyMarkup = learner
    ? /* HTML */ `
        <section class="journey-section" aria-labelledby="journey-title">
          <div class="section-heading">
            <div>
              <span class="section-kicker">Your progress</span>
              <h2 id="journey-title">Your university journey</h2>
              <p>
                Add results first. Then explore universities and check entry
                rules. Visits are remembered in this browser; results and
                applications stay with your account.
              </p>
            </div>
            <span class="journey-progress-count">
              ${journey.filter((step) => step.complete).length} of 4 steps
              complete
            </span>
          </div>
          <ol class="journey-grid">
            ${journey
              .map(
                (step, index) => /* HTML */ `
                  <li
                    class="journey-card ${step.complete ? 'is-complete' : ''} ${index === activeStep ? 'is-current' : ''}"
                    ${index === activeStep ? 'aria-current="step"' : ''}
                  >
                    <div class="journey-card-top">
                      <span class="journey-number">${step.number}</span>
                      <span class="journey-state">
                        ${
                          step.complete
                            ? /* HTML */ `
                                <i
                                  data-lucide="circle-check"
                                  aria-hidden="true"
                                ></i>
                                Done
                              `
                            : index === activeStep
                              ? 'Next step'
                              : 'Up next'
                        }
                      </span>
                    </div>
                    <div class="journey-card-title">
                      <i data-lucide="${step.icon}" aria-hidden="true"></i>
                      <h3>${step.title}</h3>
                    </div>
                    <p>${step.description}</p>
                    <a href="${step.href}" class="journey-action">
                      ${step.action}
                      <i data-lucide="arrow-right" aria-hidden="true"></i>
                    </a>
                  </li>
                `,
              )
              .join('')}
          </ol>
        </section>
      `
    : '';
  const recentRows = applications.map(
    (a) => /* HTML */ `
      <tr>
        <td>${esc(a.offering.university)}</td>
        <td>${esc(a.offering.qualification)}</td>
        <td>${badge(a.status)}</td>
      </tr>
    `,
  );
  const learnerApplications =
    learner && !recentRows.length
      ? /* HTML */ `
          <div class="application-empty">
            <span class="empty-illustration">
              <i data-lucide="file-check-2" aria-hidden="true"></i>
            </span>
            <div>
              <h3>Your application story starts here</h3>
              <p>
                Choose a university programme, review its requirements and
                submit your application from that page.
              </p>
              <a class="button-link" href="/learner/requirements.html">
                Find a programme to apply
                <i data-lucide="arrow-right" aria-hidden="true"></i>
              </a>
            </div>
          </div>
        `
      : `${table(learner ? ['University', 'Programme', 'Status'] : ['Learner', 'Qualification', 'Status'], recentRows)}${link('/' + user.role + '/applications.html', learner ? 'View all applications' : 'Open application queue')}${
          learner
            ? /* HTML */ `
                <p>
                  <a class="inline-link" href="/learner/requirements.html">
                    Apply to another programme
                    <i data-lucide="arrow-right" aria-hidden="true"></i>
                  </a>
                </p>
              `
            : ''
        }`;
  const roleMetrics =
    {
      teacher: [
        [String(counts.learners || 0), 'learners at your school'],
        [
          String(counts.awaitingScreening || 0),
          'applications awaiting screening',
        ],
      ],
      representative: [
        [String(applicationCount), 'applications for your institution'],
        [String(counts.awaitingReview || 0), 'ready for admission review'],
      ],
      admin: [
        [
          String(counts.accounts || 0),
          counts.accounts === 1 ? 'user account' : 'user accounts',
        ],
        [
          String(counts.universities || 0),
          counts.universities === 1 ? 'university' : 'universities',
        ],
        [
          String(counts.offerings || 0),
          counts.offerings === 1
            ? 'configured offering'
            : 'configured offerings',
        ],
      ],
    }[user.role] || [];
  const queueTitle =
    {
      teacher: 'Applications to screen',
      representative: 'Admission decisions to make',
      admin: 'Programme requirements to verify',
    }[user.role] || 'Your action queue';
  const queueHint =
    {
      teacher: 'Oldest submissions first',
      representative: 'Oldest screened applications first',
      admin: 'Nearest closing dates first',
    }[user.role] || '';
  const queueEmpty =
    {
      teacher:
        'No submitted applications are waiting for screening. Check learner results if a school has just added marks.',
      representative:
        'No teacher-screened applications are waiting for an admission decision.',
      admin: counts.offerings
        ? 'All configured programmes are verified.'
        : 'No programme offerings are configured yet.',
    }[user.role] || '';
  const queueMarkup = !learner
    ? /* HTML */ `
        <section class="panel action-queue">
          <div class="panel-heading-row">
            <div>
              <span class="section-kicker">Needs your action</span>
              <h2>${queueTitle}</h2>
            </div>
            <span class="queue-order">${queueHint}</span>
          </div>
          ${
            actionQueue.length
              ? /* HTML */ `
                  <ol class="queue-list">
                    ${actionQueue
                      .slice(0, 6)
                      .map(
                        (item) => /* HTML */ `
                          <li>
                            <div class="queue-copy">
                              <strong>${esc(item.title)}</strong>
                              <span
                                >${esc(item.detail)} |
                                ${esc(item.context)}</span
                              >
                              <small>
                                ${item.date ? dashboardDate(item.date) : 'Deadline to confirm'}
                              </small>
                            </div>
                            <a class="queue-action" href="${item.href}">
                              ${item.label}
                              <i
                                data-lucide="arrow-right"
                                aria-hidden="true"
                              ></i>
                            </a>
                          </li>
                        `,
                      )
                      .join('')}
                  </ol>
                `
              : /* HTML */ `
                  <div class="queue-empty">
                    <i
                      data-lucide="${user.role === 'admin' ? 'list-checks' : 'inbox'}"
                      aria-hidden="true"
                    ></i>
                    <div>
                      <strong>${queueEmpty}</strong>
                      ${
                        user.role === 'admin' && !counts.offerings
                          ? /* HTML */ `
                              <p>
                                Use the short setup checklist to add and verify
                                your first programme.
                              </p>
                              <a
                                class="inline-link"
                                href="/help.html#admin-programme-setup"
                              >
                                View setup checklist
                                <i
                                  data-lucide="arrow-right"
                                  aria-hidden="true"
                                ></i>
                              </a>
                            `
                          : /* HTML */ `
                              <a
                                class="inline-link"
                                href="${heroActions[user.role].href}"
                              >
                                ${heroActions[user.role].label}
                                <i
                                  data-lucide="arrow-right"
                                  aria-hidden="true"
                                ></i>
                              </a>
                            `
                      }
                    </div>
                  </div>
                `
          }
        </section>
      `
    : '';
  const learnerHistory = learner
    ? /* HTML */ `
        <section class="panel recent-applications">
          <div class="panel-heading-row">
            <div>
              <span class="section-kicker">Your submitted choices</span>
              <h2>Recent Applications</h2>
            </div>
            ${
              applicationCount
                ? /* HTML */ `
                    <span class="application-count">
                      ${applicationCount}
                      ${applicationCount === 1 ? 'application' : 'applications'}
                    </span>
                  `
                : ''
            }
          </div>
          ${learnerApplications}
        </section>
      `
    : '';
  const metrics = roleMetrics.length
    ? /* HTML */ `
        <section class="role-metrics" aria-label="Workspace summary">
          ${roleMetrics
            .map(
              ([number, label]) => /* HTML */ `
                <div>
                  <strong>${number}</strong>
                  <span>${label}</span>
                </div>
              `,
            )
            .join('')}
        </section>
      `
    : '';
  const closingSoon =
    learner && summary.closingSoon?.length
      ? /* HTML */ `
          <section class="closing-soon" aria-label="Applications closing soon">
            <div class="closing-soon-heading">
              <span class="section-kicker">Verified programme deadlines</span>
              <h2>Closing soon</h2>
              <p>Published application deadlines in the next 30 days.</p>
            </div>
            <ul>
              ${summary.closingSoon
                .map(
                  (item) => /* HTML */ `
                    <li>
                      <span>
                        <strong>${esc(item.title)}</strong>
                        <small>${esc(item.university)}</small>
                      </span>
                      <span class="closing-date"
                        >Closes ${esc(dashboardDate(item.date))}</span
                      >
                      <a
                        href="/learner/requirements.html?offeringId=${encodeURIComponent(item.id)}"
                      >
                        Check requirements
                        <i data-lucide="arrow-right" aria-hidden="true"></i>
                      </a>
                    </li>
                  `,
                )
                .join('')}
            </ul>
          </section>
        `
      : '';
  show(/* HTML */ `
    <section class="welcome-panel">
      <div class="welcome-copy">
        <span>${esc(user.role)} portal | 2028 entry</span>
        <h1>Welcome back, ${esc(user.firstName)}</h1>
        <p>${welcomeCopy}</p>
        <a class="welcome-cta" href="${heroActions[user.role].href}">
          ${heroActions[user.role].label}
          <i data-lucide="arrow-right" aria-hidden="true"></i>
        </a>
      </div>
      <span class="welcome-cycle" aria-label="2028 admissions">
        <strong>2028</strong>
        <small>ADMISSIONS</small>
      </span>
    </section>
    ${learner ? journeyMarkup : metrics + queueMarkup}${closingSoon}${learnerHistory}
  `);
}
async function directory() {
  const adminDirectory = user.role === 'admin' && page === 'directories',
    provinceNames = new Map(
      catalog.provinces.map((item) => [
        String(item.PROVINCE_ID),
        item.PROVINCE_NAME,
      ]),
    );
  if (page === 'policies' && user.role === 'admin') {
    const data = await request('/api/offerings');
    show(
      title(
        'Programme requirements',
        'Review the real offerings and source verification maintained by your administrators.',
      ) +
        /* HTML */ `
          <section class="panel">
            ${table(
              [
                'University',
                'Qualification',
                'Minimum APS',
                'Status',
                'Closing date',
                'Official source',
              ],
              data.offerings.map(
                (item) => /* HTML */ `
                  <tr>
                    <th>${esc(item.university)}</th>
                    <td>${esc(item.qualification)}</td>
                    <td>
                      ${item.config.minScore == null ? 'Not set' : esc(item.config.minScore) + ' ' + esc(item.config.scoring?.label || '/ 42')}
                    </td>
                    <td>${badge(item.config.status)}</td>
                    <td>
                      ${esc(String(item.APPLICATION_CLOSING_DATE).slice(0, 10))}
                    </td>
                    <td>
                      ${
                        item.config.source
                          ? /* HTML */ `
                              <a
                                href="${esc(safeHttps(item.config.source))}"
                                target="_blank"
                                rel="noopener noreferrer"
                              >
                                View source
                              </a>
                            `
                          : 'Not set'
                      }
                    </td>
                  </tr>
                `,
              ),
            )}
          </section>
          <section class="panel">
            <p>
              Use the programme requirements workspace to add or update
              offerings.
            </p>
            ${link('/admin/offerings.html', 'Manage programme requirements')}
          </section>
        `,
    );
    return;
  }
  if (!adminDirectory) {
    const data = await request('/api/offerings'),
      list = () => {
        const term = document
            .querySelector('#search')
            .value.trim()
            .toLowerCase(),
          province = document.querySelector('#province').value;
        const rows = catalog.universities
          .filter((item) => {
            const locations = campusLocations(item),
              city = locations.map((c) => c.CITY_NAME).join(' '),
              campusProvinces = locations.map((c) => String(c.PROVINCE_ID)),
              qualifications = data.offerings
                .filter(
                  (o) => String(o.UNIVERSITY_ID) === String(item.UNIVERSITY_ID),
                )
                .map((o) => o.qualification)
                .join(' ');
            return (
              `${item.UNIVERSITY_NAME} ${city} ${qualifications} ${provinceNames.get(String(item.PROVINCE_ID)) || ''} ${locations.map((c) => c.PROVINCE_NAME || '').join(' ')}`
                .toLowerCase()
                .includes(term) &&
              (!province ||
                String(item.PROVINCE_ID) === province ||
                campusProvinces.includes(province))
            );
          })
          .map((item) => {
            const locations = campusLocations(item),
              city =
                [
                  ...new Set(locations.map((c) => c.CITY_NAME).filter(Boolean)),
                ].join(', ') || 'City not provided',
              provinceName =
                [
                  ...new Set(
                    locations.map((c) => c.PROVINCE_NAME).filter(Boolean),
                  ),
                ].join(', ') ||
                provinceNames.get(String(item.PROVINCE_ID)) ||
                'Province not provided',
              programmes = data.offerings.filter(
                (o) => String(o.UNIVERSITY_ID) === String(item.UNIVERSITY_ID),
              );
            return /* HTML */ `
              <tr>
                <th>
                  ${link('/learner/university.html?id=' + encodeURIComponent(item.UNIVERSITY_ID), item.UNIVERSITY_NAME)}
                  <p>
                    ${link('/learner/university.html?id=' + encodeURIComponent(item.UNIVERSITY_ID), 'University details')}
                  </p>
                </th>
                <td>${esc(city)}</td>
                <td>${esc(provinceName)}</td>
                <td>
                  ${programmes.length ? '<ul class="university-programmes">' + programmes.map((o) => `<li><strong>${esc(o.qualification)}</strong> ${link('/learner/requirements.html?offeringId=' + encodeURIComponent(o.UNI_QUAL_ID), 'View requirements')}</li>`).join('') + '</ul>' : 'No programme offerings listed yet'}
                </td>
              </tr>
            `;
          });
        document.querySelector('#directory-grid').innerHTML = table(
          ['University', 'City', 'Province', 'Programmes'],
          rows,
        );
      };
    show(
      title(
        'Universities',
        'Search by institution, city or province and compare programme requirements.',
      ) +
        /* HTML */ `
          <section class="panel">
            <div class="fields">
              <label>
                Search university, city or qualification
                <input
                  id="search"
                  type="search"
                  aria-label="Search universities, cities and qualifications"
                />
              </label>
              <label>
                Province
                <select id="province">
                  <option value="">All provinces</option>
                  ${catalog.provinces
                    .map(
                      (item) => /* HTML */ `
                        <option value="${item.PROVINCE_ID}">
                          ${esc(item.PROVINCE_NAME)}
                        </option>
                      `,
                    )
                    .join('')}
                </select>
              </label>
            </div>
            <div id="directory-grid"></div>
          </section>
        `,
    );
    document.querySelector('#search').addEventListener('input', list);
    document.querySelector('#province').addEventListener('change', list);
    list();
    return;
  }
  show(
    title(
      'Directories',
      'Manage schools, university campus locations, cities, provinces and academic reference records.',
    ) +
      /* HTML */ `
        <section class="panel">
          <div class="fields">
            <label>
              Directory
              <select id="directory-type">
                <option value="schools">Schools</option>
                <option value="universities">Universities</option>
                <option value="cities">Cities</option>
                <option value="provinces">Provinces</option>
                <option value="subjects">Subjects</option>
                <option value="exams">Examination milestones</option>
                <option value="studyModes">Study modes</option>
              </select>
            </label>
          </div>
          <div id="managed-directory"></div>
          <form id="directory-form">
            <div class="fields" id="directory-fields"></div>
            <div class="actions">
              <button id="directory-submit">Save record</button>
              <button
                class="secondary"
                id="directory-cancel"
                type="button"
                hidden
              >
                Cancel edit
              </button>
            </div>
          </form>
        </section>
      `,
  );
  let editing = null;
  const fields = {
      schools: ['SCHOOL_NAME', 'EMIS_NUMBER', 'CITY_ID', 'PROVINCE_ID'],
      universities: [
        'UNIVERSITY_NAME',
        'WEBSITE',
        'STREET_NAME',
        'CITY_ID',
        'PROVINCE_ID',
      ],
      cities: ['CITY_NAME', 'PROVINCE_ID'],
      provinces: ['PROVINCE_NAME'],
      subjects: ['SUBJECT_NAME', 'SUBJECT_CODE', 'SUBJECT_CATEGORY'],
      exams: ['EXAM_TYPE_NAME'],
      studyModes: ['STUDY_MODE_NAME'],
    },
    primary = {
      schools: 'SCHOOL_ID',
      universities: 'UNIVERSITY_ID',
      cities: 'CITY_ID',
      provinces: 'PROVINCE_ID',
      subjects: 'SUBJECT_ID',
      exams: 'EXAM_TYPE_ID',
      studyModes: 'STUDY_MODE_ID',
    },
    labels = {
      SCHOOL_NAME: 'School name',
      EMIS_NUMBER: 'EMIS number',
      CITY_ID: 'City',
      PROVINCE_ID: 'Province',
      UNIVERSITY_NAME: 'University name',
      WEBSITE: 'Official website',
      STREET_NAME: 'Campus address',
      CITY_NAME: 'City name',
      PROVINCE_NAME: 'Province name',
      SUBJECT_NAME: 'Subject name',
      SUBJECT_CODE: 'Subject code',
      SUBJECT_CATEGORY: 'NSC category',
      EXAM_TYPE_NAME: 'Examination milestone',
      STUDY_MODE_NAME: 'Study mode',
    };
  const display = (type, row, field) =>
    field === 'CITY_ID'
      ? catalog.cities.find(
          (item) => String(item.CITY_ID) === String(row[field]),
        )?.CITY_NAME || 'Not assigned'
      : field === 'PROVINCE_ID'
        ? provinceNames.get(String(row[field])) || 'Not assigned'
        : field === 'SUBJECT_CATEGORY'
          ? {
              HOME_LANGUAGE: 'Home language',
              FIRST_ADDITIONAL_LANGUAGE: 'First additional language',
              MATHEMATICS: 'Mathematics',
              MATHEMATICAL_LITERACY: 'Mathematical literacy',
              LIFE_ORIENTATION: 'Life Orientation',
              ELECTIVE: 'Elective',
            }[row[field]] || 'Not assigned'
          : type === 'schools' &&
              field === 'SCHOOL_NAME' &&
              row.EMIS_NUMBER === 'LOCAL-ONLY'
            ? `${row[field]} (local setup)`
            : (row[field] ?? '');
  const reset = () => {
    editing = null;
    for (const field of fields[
      document.querySelector('#directory-type').value
    ] || []) {
      const control = document
        .querySelector('#directory-form')
        .elements.namedItem(field);
      if (control) {
        if (control.tagName === 'SELECT') control.selectedIndex = 0;
        else control.value = '';
      }
    }
    document.querySelector('#directory-submit').textContent = 'Save record';
    document.querySelector('#directory-cancel').hidden = true;
  };
  const drawFields = () => {
    const type = document.querySelector('#directory-type').value;
    document.querySelector('#directory-fields').innerHTML = fields[type]
      .map(
        (field) => /* HTML */ `
          <label>
            ${labels[field]}${
              field === 'PROVINCE_ID'
                ? /* HTML */ `
                    <select name="${field}" required>
                      <option value="" selected disabled>
                        Choose a province
                      </option>
                      ${select(catalog.provinces, 'PROVINCE_ID', 'PROVINCE_NAME')}
                    </select>
                  `
                : field === 'CITY_ID'
                  ? /* HTML */ `
                      <select name="${field}" required>
                        <option value="" selected disabled>
                          Choose a city
                        </option>
                        ${select(catalog.cities, 'CITY_ID', 'CITY_NAME')}
                      </select>
                    `
                  : field === 'SUBJECT_CATEGORY'
                    ? /* HTML */ `
                        <select name="${field}" required>
                          ${[
                            ['HOME_LANGUAGE', 'Home language'],
                            [
                              'FIRST_ADDITIONAL_LANGUAGE',
                              'First additional language',
                            ],
                            ['MATHEMATICS', 'Mathematics'],
                            ['MATHEMATICAL_LITERACY', 'Mathematical literacy'],
                            ['LIFE_ORIENTATION', 'Life Orientation'],
                            ['ELECTIVE', 'Elective'],
                          ]
                            .map(
                              ([value, label]) => /* HTML */ `
                                <option value="${value}">${label}</option>
                              `,
                            )
                            .join('')}
                        </select>
                      `
                    : /* HTML */ `
                        <input
                          name="${field}"
                          ${field === 'WEBSITE' ? 'type="url"' : field === 'EMIS_NUMBER' ? 'maxlength="20"' : ''}
                          ${field === 'STREET_NAME' ? 'maxlength="150"' : ''}
                          required
                        />
                      `
            }
          </label>
        `,
      )
      .join('');
    if (type === 'schools') {
      const form = document.querySelector('#directory-form');
      form.elements.CITY_ID.addEventListener('change', () => {
        const city = catalog.cities.find(
          (c) => String(c.CITY_ID) === form.elements.CITY_ID.value,
        );
        if (city?.PROVINCE_ID)
          form.elements.PROVINCE_ID.value = String(city.PROVINCE_ID);
      });
    }
  };
  const redraw = async () => {
    reset();
    drawFields();
    const type = document.querySelector('#directory-type').value,
      rows = (await request('/api/admin/directories/' + type)).rows;
    document.querySelector('#managed-directory').innerHTML = table(
      [...fields[type].map((field) => labels[field]), 'Action'],
      rows.map(
        (row) => /* HTML */ `
          <tr>
            ${fields[type]
              .map(
                (field) => /* HTML */ `
                  <td>${esc(display(type, row, field))}</td>
                `,
              )
              .join('')}
            <td>
              <button
                type="button"
                class="secondary compact"
                data-directory-edit="${esc(row[primary[type]])}"
              >
                Edit
              </button>
              <button
                type="button"
                class="secondary compact"
                data-directory-delete="${esc(row[primary[type]])}"
              >
                Delete
              </button>
            </td>
          </tr>
        `,
      ),
    );
    document.querySelectorAll('[data-directory-delete]').forEach((b) =>
      b.addEventListener(
        'click',
        guard(async () => {
          if (
            !window.confirm('Delete this unused directory record permanently?')
          )
            return;
          const names = {
            schools: 'SCHOOLS',
            universities: 'UNIVERSITIES',
            cities: 'CITIES',
            provinces: 'PROVINCES',
            subjects: 'SUBJECTS',
            studyModes: 'STUDY_MODES',
          };
          if (!names[type])
            throw new Error('This reference is managed by the workflow.');
          const out = await request(
            '/api/admin/records/' +
              names[type] +
              '/' +
              b.dataset.directoryDelete,
            'DELETE',
          );
          catalog = await request('/api/catalog');
          await redraw();
          feedback(out.message);
        }),
      ),
    );
    document.querySelectorAll('[data-directory-edit]').forEach((button) =>
      button.addEventListener('click', () => {
        const row = rows.find(
          (item) =>
            String(item[primary[type]]) === button.dataset.directoryEdit,
        );
        if (!row) return;
        editing = String(row[primary[type]]);
        for (const field of fields[type]) {
          const control = document
            .querySelector('#directory-form')
            .elements.namedItem(field);
          if (control) control.value = row[field] ?? '';
        }
        document.querySelector('#directory-submit').textContent =
          'Update record';
        document.querySelector('#directory-cancel').hidden = false;
        document
          .querySelector('#directory-form')
          .scrollIntoView?.({ block: 'center', behavior: 'smooth' });
      }),
    );
  };
  document
    .querySelector('#directory-type')
    .addEventListener('change', guard(redraw));
  document.querySelector('#directory-cancel').addEventListener('click', () => {
    reset();
    drawFields();
  });
  await redraw();
  document.querySelector('#directory-form').addEventListener(
    'submit',
    guard(async (event) => {
      event.preventDefault();
      const type = document.querySelector('#directory-type').value,
        data = Object.fromEntries(new FormData(event.target));
      for (const key of Object.keys(data))
        if (key.endsWith('_ID')) data[key] = Number(data[key]);
      const path =
        '/api/admin/directories/' +
        type +
        (editing !== null ? '/' + encodeURIComponent(editing) : '');
      const result = await request(
        path,
        editing !== null ? 'PATCH' : 'POST',
        data,
      );
      catalog = await request('/api/catalog');
      await redraw();
      feedback(result.message || 'Directory record saved.');
    }),
  );
}
async function academicRecords() {
  const { tables } = await request('/api/admin/records');
  show(
    title(
      'Academic Records',
      'Manage addresses, staff details and reference data.',
    ) +
      '<section class="panel"><label>Record type<select id="record-type">' +
      tables
        .map(
          (t) =>
            '<option value="' +
            esc(t) +
            '">' +
            esc(t.replaceAll('_', ' ')) +
            '</option>',
        )
        .join('') +
      '</select></label><label>Filter records<input id="record-search" type="search" placeholder="Search this table"></label><div id="record-list"></div></section><section class="panel" id="record-edit"></section><section class="panel"><button class="secondary" id="show-coverage" type="button">Database field coverage</button><div id="column-coverage"></div></section>',
  );
  let model,
    editing = null,
    sequence = 0;
  const label = (k) =>
    k
      .toLowerCase()
      .replaceAll('_', ' ')
      .replace(/\b\w/g, (c) => c.toUpperCase());
  const drawForm = () => {
    const row =
      editing === null
        ? {}
        : model.rows.find((r) => String(r[model.primary]) === editing);
    const fields = model.columns.filter(
      (c) => c.editable && !(editing !== null && c.name === model.primary),
    );
    const area = document.querySelector('#record-edit');
    if (model.managed) {
      area.innerHTML =
        '<p>These reference values are generated and maintained by the application workflow.</p>';
      return;
    }
    if (model.updateOnly && editing === null) {
      area.innerHTML =
        '<p>Select Edit to update an existing staff record. New people and assigned roles are created from Accounts.</p>';
      return;
    }
    area.innerHTML =
      '<h2>' +
      (editing === null ? 'Add record' : 'Edit record') +
      '</h2><form id="record-form"><div class="fields">' +
      fields
        .map((c) => {
          const value = row?.[c.name] ?? '';
          let input;
          if (model.choices[c.name])
            input =
              '<select name="' +
              c.name +
              '" required><option value="">Choose an existing record</option>' +
              model.choices[c.name]
                .map(
                  (o) =>
                    '<option value="' +
                    o.value +
                    '" ' +
                    (String(o.value) === String(value) ? 'selected' : '') +
                    '>' +
                    esc(o.label) +
                    '</option>',
                )
                .join('') +
              '</select>';
          else if (c.type === 'BIT')
            input =
              '<input type="checkbox" name="' +
              c.name +
              '" ' +
              (value ? 'checked' : '') +
              '>';
          else if (['INT', 'TINYINT', 'SMALLINT', 'DECIMAL'].includes(c.type))
            input =
              '<input name="' +
              c.name +
              '" type="number" min="0" step="' +
              (c.type === 'DECIMAL' ? '0.01' : '1') +
              '" value="' +
              esc(value) +
              '" required>';
          else
            input =
              '<input name="' +
              c.name +
              '" value="' +
              esc(value) +
              '" maxlength="' +
              esc(c.size || 150) +
              '" required>';
          return '<label>' + label(c.name) + input + '</label>';
        })
        .join('') +
      '</div><button>Save record</button> <button class="secondary" type="button" id="record-cancel">Cancel / new record</button></form>';
    document.querySelector('#record-cancel').onclick = () => {
      editing = null;
      drawForm();
    };
    document.querySelector('#record-form').addEventListener(
      'submit',
      guard(async (e) => {
        e.preventDefault();
        const body = {};
        for (const c of fields) {
          const field = e.target.elements.namedItem(c.name);
          body[c.name] =
            c.type === 'BIT'
              ? field.checked
              : model.choices[c.name] ||
                  ['INT', 'TINYINT', 'SMALLINT', 'DECIMAL'].includes(c.type)
                ? Number(field.value)
                : field.value;
        }
        const out = await request(
          '/api/admin/records/' +
            model.table +
            (editing !== null ? '/' + editing : ''),
          editing === null ? 'POST' : 'PATCH',
          body,
        );
        await load();
        feedback(out.message);
      }),
    );
  };
  const drawList = () => {
    const search = document.querySelector('#record-search').value.toLowerCase();
    const names = model.columns.map((c) => c.name);
    document.querySelector('#record-list').innerHTML = table(
      [...names.map(label), 'Actions'],
      model.rows
        .filter((r) =>
          Object.values(r).join(' ').toLowerCase().includes(search),
        )
        .map(
          (r) =>
            '<tr>' +
            names
              .map(
                (k) =>
                  '<td>' +
                  esc(
                    model.choices[k]?.find(
                      (o) => String(o.value) === String(r[k]),
                    )?.label ??
                      r[k] ??
                      'Not yet recorded',
                  ) +
                  '</td>',
              )
              .join('') +
            '<td>' +
            (model.managed
              ? 'Managed by workflow'
              : '<button class="secondary compact" data-record-edit="' +
                r[model.primary] +
                '">Edit</button>' +
                (['TEACHERS', 'ITADMINS', 'ACHIEVEMENT_LEVELS'].includes(
                  model.table,
                )
                  ? ''
                  : '<button class="secondary compact" data-delete-record="' +
                    r[model.primary] +
                    '">Delete</button>')) +
            '</td></tr>',
        ),
    );
    document.querySelectorAll('[data-delete-record]').forEach((b) =>
      b.addEventListener(
        'click',
        guard(async () => {
          if (!window.confirm('Delete this unused record permanently?')) return;
          const out = await request(
            '/api/admin/records/' + model.table + '/' + b.dataset.deleteRecord,
            'DELETE',
          );
          await load();
          feedback(out.message);
        }),
      ),
    );
    document.querySelectorAll('[data-record-edit]').forEach(
      (b) =>
        (b.onclick = () => {
          editing = b.dataset.recordEdit;
          drawForm();
          document
            .querySelector('#record-edit')
            .scrollIntoView?.({ block: 'start' });
        }),
    );
  };
  const load = async () => {
    const current = ++sequence;
    const data = await request(
      '/api/admin/records/' + document.querySelector('#record-type').value,
    );
    if (current !== sequence) return;
    model = data;
    editing = null;
    drawList();
    drawForm();
  };
  document
    .querySelector('#record-type')
    .addEventListener('change', guard(load, true));
  document.querySelector('#record-search').addEventListener('input', () => {
    if (model) drawList();
  });
  document.querySelector('#show-coverage').addEventListener(
    'click',
    guard(async () => {
      const out = await request('/api/admin/column-coverage');
      document.querySelector('#column-coverage').innerHTML = out.tables
        .map(
          (t) =>
            '<details><summary>' +
            esc(t.table) +
            ' · ' +
            t.columns.length +
            ' columns</summary><p>' +
            esc(t.entry) +
            '</p>' +
            table(
              ['Column', 'Saved through'],
              t.columns.map(
                (c) =>
                  '<tr><td>' +
                  esc(c.column) +
                  '</td><td>' +
                  esc(c.mode) +
                  '</td></tr>',
              ),
            ) +
            '</details>',
        )
        .join('');
    }),
  );
  await load();
}

async function accounts() {
  const data = await request('/api/admin/accounts');
  show(
    title(
      'Accounts',
      'Create role-scoped accounts; learners can also register themselves.',
    ) +
      /* HTML */ `
        <section class="panel">
          ${table(
            [
              'Person',
              'Username',
              'Role',
              'Access status',
              'Added',
              'Last updated',
              'Removed',
              'Actions',
            ],
            data.accounts.map(
              (a) => /* HTML */ `
                <tr>
                  <td>
                    ${esc(a.firstName || a.user?.firstName || 'Unknown')}
                    ${esc(a.lastName || a.user?.lastName || '')}
                    <small class="muted"
                      >Person ID ${esc(a.personId ?? a.user?.personId)}</small
                    >
                  </td>
                  <td>${esc(a.username ?? a.user?.username)}</td>
                  <td>${esc(a.user?.role || 'Role needs review')}</td>
                  <td>
                    ${a.disabled ? 'Access removed' : 'Active'}${a.emailVerified ? '' : ' · Email pending'}
                    ${a.identityWarnings?.length ? `<small class="muted">Identity warning: ${esc(a.identityWarnings.join(' '))}</small>` : ''}
                  </td>
                  <td>${esc(formatDateTime(a.createdAt))}</td>
                  <td>${esc(formatDateTime(a.updatedAt))}</td>
                  <td>${esc(formatDateTime(a.removedAt))}</td>
                  <td>
                    ${(a.personId ?? a.user?.personId) != null ? `<button class="secondary compact" data-account-edit-person="${esc(a.personId ?? a.user?.personId)}">Edit person</button>` : ''}
                    ${
                      a.user?.personId !== user.personId
                        ? /* HTML */ `
                            ${
                              a.identitySyncAvailable
                                ? /* HTML */ `
                                    <button
                                      class="secondary compact"
                                      data-account-sync-identity="${esc(a.accountId)}"
                                    >
                                      Sync profile email
                                    </button>
                                  `
                                : ''
                            }
                            ${
                              !a.disabled
                                ? /* HTML */ `
                                    <button
                                      class="secondary compact"
                                      data-account-password-reset="${esc(a.accountId)}"
                                    >
                                      ${a.emailVerified ? 'Send password reset' : a.accountSetupPending ? 'Resend setup link' : 'Send verification email'}
                                    </button>
                                  `
                                : ''
                            }
                            <button
                              class="secondary compact"
                              data-account-action="${a.disabled ? 'enable' : 'disable'}"
                              data-account-id="${esc(a.accountId)}"
                            >
                              ${a.disabled ? 'Restore access' : 'Disable access'}
                            </button>
                            <button
                              class="secondary compact"
                              data-delete-person="${a.personId ?? a.user?.personId}"
                            >
                              Delete person
                            </button>
                          `
                        : ''
                    }
                  </td>
                </tr>
              `,
            ),
          )}
        </section>
        <section class="panel" id="person-edit-panel" hidden>
          <h2>Update person details</h2>
          <p class="form-help">
            Changes are saved to PERSONS and timestamped in audit history.
            Removing access below disables sign-in but preserves the person's
            application and audit records.
          </p>
          <form id="person-update">
            <input type="hidden" name="personId" />
            <div class="fields">
              <label>
                First name
                <input
                  name="firstName"
                  required
                  maxlength="100"
                  autocomplete="given-name"
                />
              </label>
              <label>
                Last name
                <input
                  name="lastName"
                  required
                  maxlength="100"
                  autocomplete="family-name"
                />
              </label>
              <label>
                Phone number (optional)
                <input
                  name="phone"
                  type="tel"
                  inputmode="numeric"
                  maxlength="10"
                  pattern="0[0-9]{9}"
                  title="10 digits beginning with 0, or leave blank"
                />
              </label>
              <label>
                South African ID number (learner only)
                <input
                  name="saIdNumber"
                  inputmode="numeric"
                  autocomplete="off"
                  maxlength="13"
                  pattern="[0-9]{13}"
                  placeholder="Leave blank to keep the current value"
                />
              </label>
            </div>
            <p id="person-edit-hint" class="muted"></p>
            <div class="button-row">
              <button type="submit">Save person changes</button>
              <button type="button" class="secondary" id="person-edit-cancel">
                Cancel
              </button>
            </div>
          </form>
        </section>
        <section class="panel">
          <h2>Create an account</h2>
          <form id="account">
            <div class="fields">
              <label>
                First name
                <input
                  name="firstName"
                  required
                  maxlength="100"
                  autocomplete="given-name"
                />
              </label>
              <label>
                Last name
                <input
                  name="lastName"
                  required
                  maxlength="100"
                  autocomplete="family-name"
                />
              </label>
              <label>
                Email
                <input
                  name="email"
                  type="email"
                  required
                  maxlength="100"
                  autocomplete="email"
                />
              </label>
              <p class="form-help">
                The user will receive a secure link to verify their email and
                set their own password.
              </p>
              <label>
                Role
                <select name="role">
                  <option value="learner">Learner</option>
                  <option value="teacher">Career Guidance Teacher</option>
                  <option value="representative">
                    University Representative
                  </option>
                  <option value="admin">IT Administrator</option>
                </select>
              </label>
              <label id="admin-sa-id-field" hidden>
                South African ID number (learner only, optional)
                <input
                  name="saIdNumber"
                  type="text"
                  inputmode="numeric"
                  autocomplete="off"
                  maxlength="13"
                  pattern="[0-9]{13}"
                />
              </label>
              <label id="account-school-field">
                School (learner / teacher / administrator)
                <select name="schoolId" required disabled>
                  <option value="" selected disabled>Choose a school</option>
                  ${select(catalog.schools, 'SCHOOL_ID', 'SCHOOL_NAME')}
                </select>
              </label>
              <label id="account-university-field" hidden>
                University (representative)
                <select name="universityId" required disabled>
                  <option value="" selected disabled>
                    Choose a university
                  </option>
                  ${select(catalog.universities, 'UNIVERSITY_ID', 'UNIVERSITY_NAME')}
                </select>
              </label>
            </div>
            <button>Create account</button>
          </form>
        </section>
      `,
  );
  wirePersonNameValidation(document.querySelector('#account'));
  wireSouthAfricanIdValidation(document.querySelector('#account'));
  const accountRoleSelect = document.querySelector('#account [name="role"]');
  const accountSaIdField = document.querySelector('#admin-sa-id-field');
  const accountSchoolField = document.querySelector('#account-school-field');
  const accountUniversityField = document.querySelector(
    '#account-university-field',
  );
  const accountSchoolSelect = accountSchoolField.querySelector('select');
  const accountUniversitySelect =
    accountUniversityField.querySelector('select');
  const syncRoleFields = () => {
    const needsSchool = ['learner', 'teacher', 'admin'].includes(
      accountRoleSelect.value,
    );
    const needsUniversity = accountRoleSelect.value === 'representative';
    accountSaIdField.hidden = accountRoleSelect.value !== 'learner';
    accountSchoolField.hidden = !needsSchool;
    accountSchoolSelect.required = needsSchool;
    accountSchoolSelect.disabled = !needsSchool;
    accountUniversityField.hidden = !needsUniversity;
    accountUniversitySelect.required = needsUniversity;
    accountUniversitySelect.disabled = !needsUniversity;
    if (!needsSchool) accountSchoolSelect.value = '';
    if (!needsUniversity) accountUniversitySelect.value = '';
    if (accountRoleSelect.value !== 'learner')
      accountSaIdField.querySelector('input').value = '';
  };
  accountRoleSelect.addEventListener('change', syncRoleFields);
  syncRoleFields();
  const personPanel = document.querySelector('#person-edit-panel');
  const personUpdateForm = document.querySelector('#person-update');
  wirePersonNameValidation(personUpdateForm);
  wireSouthAfricanIdValidation(personUpdateForm);
  const populatePersonEditor = (personId) => {
    const item = data.accounts.find(
      (account) =>
        String(account.personId ?? account.user?.personId) === String(personId),
    );
    if (!item) return;
    personUpdateForm.elements.namedItem('personId').value =
      item.personId ?? item.user?.personId;
    personUpdateForm.elements.namedItem('firstName').value =
      item.firstName ?? item.user?.firstName ?? '';
    personUpdateForm.elements.namedItem('lastName').value =
      item.lastName ?? item.user?.lastName ?? '';
    personUpdateForm.elements.namedItem('phone').value = item.phoneNumber || '';
    personUpdateForm.elements.namedItem('saIdNumber').value = '';
    personUpdateForm.elements.namedItem('saIdNumber').disabled =
      item.user?.role !== 'learner';
    document.querySelector('#person-edit-hint').textContent =
      `Login email: ${item.username}. ID on file: ${item.hasSaIdNumber ? item.saIdNumberMasked : 'not recorded'}. Added: ${formatDateTime(item.createdAt)}. Last updated: ${formatDateTime(item.updatedAt)}. Blank ID means keep the current value.`;
    personPanel.hidden = false;
    personPanel.scrollIntoView?.({ block: 'center', behavior: 'smooth' });
    personUpdateForm.elements.namedItem('firstName').focus();
  };
  document
    .querySelectorAll('[data-account-edit-person]')
    .forEach((button) =>
      button.addEventListener('click', () =>
        populatePersonEditor(button.dataset.accountEditPerson),
      ),
    );
  document
    .querySelector('#person-edit-cancel')
    .addEventListener('click', () => {
      personPanel.hidden = true;
      personUpdateForm.reset();
    });
  personUpdateForm.addEventListener(
    'submit',
    guard(async (event) => {
      event.preventDefault();
      const dataToSave = Object.fromEntries(new FormData(personUpdateForm));
      const personId = dataToSave.personId;
      delete dataToSave.personId;
      const out = await request(
        '/api/admin/people/' + encodeURIComponent(personId),
        'PATCH',
        dataToSave,
      );
      await accounts();
      feedback(out.message || 'Person details updated.');
    }),
  );
  document.querySelector('#account').addEventListener(
    'submit',
    guard(async (e) => {
      e.preventDefault();
      const b = Object.fromEntries(new FormData(e.target));
      b.schoolId = b.schoolId ? Number(b.schoolId) : null;
      b.universityId = b.universityId ? Number(b.universityId) : null;
      if (b.role !== 'learner') delete b.saIdNumber;
      const out = await request('/api/admin/accounts', 'POST', b);
      await accounts();
      feedback(out.message);
    }),
  );
  document.querySelectorAll('[data-account-password-reset]').forEach((b) =>
    b.addEventListener(
      'click',
      guard(async () => {
        const out = await request(
          '/api/admin/accounts/' +
            b.dataset.accountPasswordReset +
            '/password-reset',
          'POST',
          {},
        );
        feedback(out.message);
      }),
    ),
  );
  document.querySelectorAll('[data-account-sync-identity]').forEach((b) =>
    b.addEventListener(
      'click',
      guard(async () => {
        const out = await request(
          '/api/admin/accounts/' +
            b.dataset.accountSyncIdentity +
            '/sync-profile-email',
          'POST',
          {},
        );
        await accounts();
        feedback(out.message);
      }),
    ),
  );
  document.querySelectorAll('[data-delete-person]').forEach((b) =>
    b.addEventListener(
      'click',
      guard(async () => {
        if (
          !window.confirm(
            'Permanently delete this unused person and their sign-in account? People with application or evidence history cannot be deleted.',
          )
        )
          return;
        const out = await request(
          '/api/admin/people/' + b.dataset.deletePerson,
          'DELETE',
        );
        await accounts();
        feedback(out.message);
      }),
    ),
  );
  document.querySelectorAll('[data-account-action]').forEach((b) =>
    b.addEventListener(
      'click',
      guard(async () => {
        const action = b.dataset.accountAction;
        if (
          action === 'disable' &&
          !window.confirm(
            'Remove this person’s sign-in access? Their person record, applications, documents and audit history will be preserved.',
          )
        )
          return;
        const out = await request(
          '/api/admin/accounts/' + b.dataset.accountId + '/' + action,
          'POST',
          {},
        );
        await accounts();
        feedback(out.message);
      }),
    ),
  );
  const unlinked = (await request('/api/admin/unlinked')).people;
  if (unlinked.length) {
    main.insertAdjacentHTML(
      'beforeend',
      /* HTML */ `
        <section class="panel">
          <h2>Enable sign-in for an existing database person</h2>
          <form id="link-account">
            <div class="fields">
              <label>
                Existing person
                <select name="personId">
                  ${unlinked
                    .map(
                      (p) => /* HTML */ `
                        <option value="${p.personId}">
                          ${esc(p.firstName)} ${esc(p.lastName)} ·
                          ${esc(p.email || p.username || 'No email recorded')} ·
                          Person ID ${esc(p.personId)} ·
                          ${esc(p.role)}${p.identityWarnings?.length ? ' · CHECK: ' + esc(p.identityWarnings.join(' ')) : ''}
                        </option>
                      `,
                    )
                    .join('')}
                </select>
              </label>
              <label>
                Login email
                <input name="email" type="email" required />
              </label>
              <p class="form-help">
                The user will receive a secure link to verify their email and
                set their own password.
              </p>
            </div>
            <button>Enable sign-in</button>
          </form>
        </section>
      `,
    );
    document.querySelector('#link-account').addEventListener(
      'submit',
      guard(async (e) => {
        e.preventDefault();
        const b = Object.fromEntries(new FormData(e.target));
        b.personId = Number(b.personId);
        const out = await request('/api/admin/accounts/link', 'POST', b);
        await accounts();
        feedback(out.message);
      }),
    );
  }
}
async function offeringAdmin() {
  let editing = null;
  const data = await request('/api/offerings');
  const subjectOptions = catalog.subjects
    .map(
      (subject) => /* HTML */ `
        <option value="${esc(subject.SUBJECT_CODE)}">
          ${esc(subject.SUBJECT_NAME)}
        </option>
      `,
    )
    .join('');
  show(
    title(
      'Programme Requirements',
      'Manage the score scale, subject requirements, documents and application window for each programme.',
    ) +
      /* HTML */ `
        <section class="panel">
          ${table(
            [
              'University',
              'Qualification',
              'Programme category',
              'Minimum APS',
              'Verification',
              'Closing date',
              'Action',
            ],
            data.offerings.map(
              (item) => /* HTML */ `
                <tr>
                  <td>${esc(item.university)}</td>
                  <td>${esc(item.qualification)}</td>
                  <td>${esc(item.program)}</td>
                  <td>
                    ${item.config.minScore == null ? 'Not set' : esc(item.config.minScore) + ' ' + esc(item.config.scoring?.label || '/ 42')}
                  </td>
                  <td>${badge(item.config.status)}</td>
                  <td>
                    ${esc(String(item.APPLICATION_CLOSING_DATE).slice(0, 10))}
                  </td>
                  <td>
                    <button
                      type="button"
                      class="secondary compact"
                      data-edit-offering="${item.UNI_QUAL_ID}"
                    >
                      Edit requirements
                    </button>
                    <button
                      type="button"
                      class="secondary compact"
                      data-delete-offering="${item.UNI_QUAL_ID}"
                    >
                      Delete offering
                    </button>
                  </td>
                </tr>
              `,
            ),
          )}
        </section>
        <section class="panel">
          <h2>Add a programme offering</h2>
          <form id="offering-form">
            <div class="fields">
              <label>
                University
                <select name="universityId" required>
                  ${select(
                    catalog.universities.filter(
                      (item) =>
                        user.role !== 'representative' ||
                        String(item.UNIVERSITY_ID) ===
                          String(user.universityId),
                    ),
                    'UNIVERSITY_ID',
                    'UNIVERSITY_NAME',
                  )}
                </select>
              </label>
              <label>
                Qualification name
                <input name="name" required maxlength="150" />
              </label>
              <label>
                Programme category
                <input name="program" required maxlength="100" />
              </label>
              <label>
                Application closing date
                <input name="closingDate" type="date" required />
              </label>
              <label>
                Minimum academic score
                <input
                  name="minScore"
                  type="number"
                  min="0"
                  max="32767"
                  step="1"
                  required
                />
              </label>
              <label>
                Final admission APS (optional)
                <input
                  name="finalMinScore"
                  type="number"
                  min="0"
                  max="32767"
                  step="0.01"
                />
              </label>
              <label>
                Minimum English (%)
                <input name="minEnglish" type="number" min="0" max="100" />
              </label>
              <label>
                Minimum Mathematics (%)
                <input name="minMath" type="number" min="0" max="100" />
              </label>
              <label>
                Required additional subjects (optional)
                <select name="requiredCodes" multiple size="5">
                  ${subjectOptions}
                </select>
                <span class="form-help">
                  Select only compulsory subjects in addition to English and
                  Mathematics.
                </span>
              </label>
              <label>
                Opening date (optional for existing listings)
                <input name="openingDate" type="date" />
              </label>
              <label>
                Closing time (South Africa)
                <input name="closingTime" type="time" value="23:59" />
              </label>
              <label>
                Offering availability
                <select name="active">
                  <option value="yes">Active</option>
                  <option value="no">Inactive</option>
                </select>
              </label>
              <label>
                Score method
                <select name="scoringMode">
                  <option value="standard">Standard six-subject APS</option>
                  <option value="BANDS">Custom points bands</option>
                  <option value="RAW">Percentage total / average</option>
                </select>
              </label>
              <div class="search fields" id="custom-scoring" hidden>
                <label>
                  Score label
                  <input
                    name="scoreLabel"
                    value="Academic score"
                    maxlength="80"
                  />
                </label>
                <label>
                  Number of subjects counted
                  <input
                    name="scoreCount"
                    type="number"
                    min="1"
                    max="10"
                    value="6"
                  />
                </label>
                <label>
                  Divide total by
                  <input
                    name="scoreDivisor"
                    type="number"
                    min="0.01"
                    max="1000"
                    step="0.01"
                    value="1"
                  />
                </label>
                <label>
                  Marks below this percentage earn zero
                  <input
                    name="scoreFloor"
                    type="number"
                    min="0"
                    max="100"
                    value="0"
                  />
                </label>
                <label>
                  Subjects excluded from score
                  <select name="scoreExclude" multiple size="5">
                    ${subjectOptions}
                  </select>
                </label>
                <label>
                  Subject weights: one SUBJECT_CODE, multiplier per line
                  <textarea
                    name="scoreWeights"
                    rows="4"
                    placeholder="MATH, 2"
                  ></textarea>
                </label>
                <label class="search">
                  Points bands: lower mark, upper boundary (excluded), points
                  <textarea name="scoreBands" rows="7">
0,30,1
30,40,2
40,50,3
50,60,4
60,70,5
70,80,6
80,101,7</textarea>
                  <span class="form-help">
                    Use 101 as the final upper boundary to include 100%. Bands
                    are unused for percentage scoring.
                  </span>
                </label>
              </div>
              <label class="search">
                Subject alternatives: group, subject code, minimum percentage
                <textarea
                  name="subjectGroups"
                  rows="4"
                  placeholder="1, MATH, 50&#10;1, MLIT, 70"
                ></textarea>
                <span class="form-help">
                  At least one subject must pass in each group. Use different
                  group numbers for requirements that must both be met.
                  Available codes:
                  ${catalog.subjects.map((x) => esc(x.SUBJECT_CODE)).join(', ')}.
                </span>
              </label>
              <label class="search">
                Additional documents required before applying
                <select name="requiredDocumentIds" multiple size="4">
                  ${select(
                    catalog.documentTypes.filter(
                      (x) => !x.IS_LOCKED_UNTIL_FINAL,
                    ),
                    'DOCUMENT_TYPE_ID',
                    'DOCUMENT_TYPE_NAME',
                  )}
                </select>
                <span class="form-help"
                  >The system's mandatory documents remain required.</span
                >
              </label>
              <label>
                Official programme source
                <input
                  name="source"
                  type="url"
                  placeholder="https://"
                  required
                />
              </label>
              <label class="search">
                Additional selection conditions
                <input name="notes" required maxlength="400" />
              </label>
              <label class="search">
                <span>
                  <input
                    name="verified"
                    type="checkbox"
                    class="inline-checkbox"
                  />
                  I checked this qualification’s 2028 requirements and closing
                  date against its official source.
                </span>
              </label>
            </div>
            <div class="actions">
              <button id="offering-submit">Save offering</button>
              <button
                class="secondary"
                id="offering-cancel"
                type="button"
                hidden
              >
                Cancel edit
              </button>
            </div>
          </form>
          <p class="muted">
            Only mark requirements verified after checking the official 2028
            source. Custom scoring applies only to this programme; existing
            listings keep their current scale.
          </p>
        </section>
      `,
  );
  const form = document.querySelector('#offering-form');
  const syncScoring = () => {
    document.querySelector('#custom-scoring').hidden =
      form.elements.scoringMode.value === 'standard';
  };
  const library = document.createElement('section');
  library.className = 'panel';
  library.innerHTML =
    '<h2>Reusable scoring policies</h2><p>Load a named policy to use its scoring formula for another programme in the same university. Each offering keeps the selected policy version.</p><button type="button" id="load-policy-library" class="secondary">Load policies</button><label>Policy<select id="policy-library"><option value="">Choose a saved policy</option></select></label><button type="button" id="apply-library-policy" class="secondary">Use selected policy</button><label>Policy name<input id="policy-library-name" maxlength="100"></label><button type="button" id="save-library-policy" class="secondary">Save current formula as policy</button><button type="button" id="update-library-policy" class="secondary">Update selected policy version</button>';
  form.before(library);
  let policyItems = [],
    selectedPolicy = null;
  const loadPolicies = async () => {
    policyItems = (await request('/api/scoring-policies')).policies;
    document.querySelector('#policy-library').innerHTML =
      '<option value="">Choose a saved policy</option>' +
      policyItems
        .map(
          (p) =>
            '<option value="' +
            esc(p.key) +
            '">' +
            esc(p.name) +
            ' · version ' +
            p.version +
            '</option>',
        )
        .join('');
  };
  document
    .querySelector('#load-policy-library')
    .addEventListener('click', guard(loadPolicies));
  document.querySelector('#apply-library-policy').addEventListener(
    'click',
    guard(() => {
      const p = policyItems.find(
        (p) => p.key === document.querySelector('#policy-library').value,
      );
      if (!p) throw new Error('Choose a policy first.');
      if (String(form.elements.universityId.value) !== String(p.universityId))
        throw new Error(
          'Choose the same university in the programme form first.',
        );
      selectedPolicy = p;
      const c = p.scoring;
      form.elements.scoringMode.value = c?.mode || 'standard';
      form.elements.source.value = p.source;
      if (c) {
        form.elements.scoreLabel.value = c.label;
        form.elements.scoreCount.value = c.count;
        form.elements.scoreDivisor.value = c.divisor;
        form.elements.scoreFloor.value = c.floor;
        form.elements.scoreBands.value = c.bands
          .map((r) => r.join(', '))
          .join('\n');
        form.elements.scoreWeights.value = c.overrides
          .map((r) => r.codes[0] + ', ' + r.weight)
          .join('\n');
        for (const o of form.elements.scoreExclude.options)
          o.selected = c.exclude.includes(o.value);
      }
      document.querySelector('#policy-library-name').value = p.name;
      syncScoring();
      feedback('Policy version loaded. Save the offering to attach it.');
    }),
  );
  const savePolicy = async (update) => {
    const b = readOfferingForm();
    if (update && !selectedPolicy)
      throw new Error('Load a policy before updating it.');
    const out = await request('/api/scoring-policies', 'POST', {
      name: document.querySelector('#policy-library-name').value,
      universityId: b.universityId,
      source: b.source,
      scoring: b.scoring,
      ...(update
        ? {
            policyId: selectedPolicy.key,
            expectedVersion: selectedPolicy.version,
          }
        : {}),
    });
    selectedPolicy = out.policy;
    await loadPolicies();
    feedback(out.message);
  };
  document.querySelector('#save-library-policy').addEventListener(
    'click',
    guard(() => savePolicy(false)),
  );
  document.querySelector('#update-library-policy').addEventListener(
    'click',
    guard(() => savePolicy(true)),
  );
  form.addEventListener('input', (event) => {
    if (
      [
        'universityId',
        'scoringMode',
        'scoreLabel',
        'scoreCount',
        'scoreDivisor',
        'scoreFloor',
        'scoreBands',
        'scoreWeights',
        'scoreExclude',
      ].includes(event.target.name)
    )
      selectedPolicy = null;
  });
  form.elements.scoringMode.addEventListener('change', syncScoring);
  const lines = (value) =>
    value
      .split(/\r?\n/)
      .map((v) => v.trim())
      .filter(Boolean)
      .map((v) => v.split(',').map((x) => x.trim()));

  const readOfferingForm = () => {
    const b = Object.fromEntries(new FormData(form));
    b.universityId = Number(b.universityId);
    b.intake = 2028;
    b.minScore = Number(b.minScore);
    b.finalMinScore = b.finalMinScore === '' ? null : Number(b.finalMinScore);
    for (const key of ['minEnglish', 'minMath'])
      b[key] = b[key] === '' ? null : Number(b[key]);
    b.requiredCodes = [
      ...form.elements.namedItem('requiredCodes').selectedOptions,
    ].map((option) => option.value);
    b.subjectMinimums =
      editing === null
        ? {}
        : data.offerings.find((x) => String(x.UNI_QUAL_ID) === editing)?.config
            .subjectMinimums || {};
    b.active = b.active !== 'no';
    b.requiredDocumentIds = [
      ...form.elements.requiredDocumentIds.selectedOptions,
    ].map((o) => Number(o.value));
    b.subjectGroups = lines(b.subjectGroups).map((row) => {
      if (row.length !== 3)
        throw new Error(
          'Use group, subject code, minimum percentage on each requirements line.',
        );
      return { group: Number(row[0]), code: row[1], minimum: Number(row[2]) };
    });
    b.scoring =
      b.scoringMode === 'standard'
        ? null
        : {
            mode: b.scoringMode,
            count: Number(b.scoreCount),
            divisor: Number(b.scoreDivisor),
            floor: Number(b.scoreFloor),
            label: b.scoreLabel,
            bands: lines(b.scoreBands).map((row) => {
              if (row.length !== 3)
                throw new Error('Each band needs lower, upper and points.');
              return row.map(Number);
            }),
            exclude: [...form.elements.scoreExclude.selectedOptions].map(
              (o) => o.value,
            ),
            overrides: lines(b.scoreWeights).map((row) => {
              if (row.length !== 2)
                throw new Error(
                  'Each weighting needs subject code and multiplier.',
                );
              return { codes: [row[0]], weight: Number(row[1]) };
            }),
          };
    b.verified = form.elements.namedItem('verified').checked;
    return b;
  };
  form.addEventListener(
    'submit',
    guard(async (event) => {
      event.preventDefault();
      const b = readOfferingForm();
      if (selectedPolicy) {
        b.reusablePolicyId = selectedPolicy.key;
        b.reusablePolicyVersion = selectedPolicy.version;
      }
      await request(
        '/api/' +
          (user.role === 'representative' ? 'representative' : 'admin') +
          '/offerings' +
          (editing !== null ? '/' + encodeURIComponent(editing) : ''),
        editing !== null ? 'PATCH' : 'POST',
        b,
      );
      await offeringAdmin();
      feedback('Programme offering saved.');
    }),
  );
  document.querySelectorAll('[data-delete-offering]').forEach((b) =>
    b.addEventListener(
      'click',
      guard(async () => {
        if (
          !window.confirm(
            'Delete this unused programme offering? Applications already linked to it prevent deletion.',
          )
        )
          return;
        const out = await request(
          '/api/' +
            (user.role === 'representative' ? 'representative' : 'admin') +
            '/offerings/' +
            b.dataset.deleteOffering,
          'DELETE',
        );
        await offeringAdmin();
        feedback(out.message);
      }),
    ),
  );
  document.querySelectorAll('[data-edit-offering]').forEach((button) =>
    button.addEventListener('click', () => {
      const item = data.offerings.find(
        (row) => String(row.UNI_QUAL_ID) === button.dataset.editOffering,
      );
      if (!item) return;
      selectedPolicy = null;
      editing = String(item.UNI_QUAL_ID);
      const values = {
        universityId: item.UNIVERSITY_ID,
        name: item.qualification,
        program: item.program || 'Undergraduate',
        closingDate: String(item.APPLICATION_CLOSING_DATE).slice(0, 10),
        minScore: item.config.minScore ?? '',
        finalMinScore: item.config.finalMinScore ?? '',
        minEnglish: item.config.minEnglish ?? '',
        minMath: item.config.minMath ?? '',
        openingDate: item.config.openingDate || '',
        closingTime: item.config.closingTime || '23:59',
        active: item.config.active === false ? 'no' : 'yes',
        scoringMode: item.config.scoring?.mode || 'standard',
        scoreLabel: item.config.scoring?.label || 'Academic score',
        scoreCount: item.config.scoring?.count || 6,
        scoreDivisor: item.config.scoring?.divisor || 1,
        scoreFloor: item.config.scoring?.floor || 0,
        scoreBands: (
          item.config.scoring?.bands || [
            [0, 30, 1],
            [30, 40, 2],
            [40, 50, 3],
            [50, 60, 4],
            [60, 70, 5],
            [70, 80, 6],
            [80, 101, 7],
          ]
        )
          .map((row) => row.join(','))
          .join('\n'),
        scoreWeights: (item.config.requirementsImport
          ? []
          : item.config.scoring?.overrides || []
        )
          .map((o) => o.codes[0] + ', ' + o.weight)
          .join('\n'),
        subjectGroups: (item.config.subjectGroups || [])
          .map((r) => [r.group, r.code, r.minimum].join(', '))
          .join('\n'),
        source: item.config.source || '',
        notes: (
          item.config.notes ||
          'Check the official programme instructions for complete selection conditions.'
        ).slice(0, 400),
      };
      for (const [key, value] of Object.entries(values))
        form.elements.namedItem(key).value = value;
      for (const option of form.elements.scoreExclude.options)
        option.selected = (item.config.scoring?.exclude || []).includes(
          option.value,
        );
      for (const option of form.elements.requiredDocumentIds.options)
        option.selected = (item.config.requiredDocumentIds || []).includes(
          Number(option.value),
        );
      syncScoring();
      if (item.config.requirementsImport)
        feedback(
          'This imported profile retains its advanced scoring and alternative subject routes when you save basic details.',
        );
      const required = new Set(item.config.requiredCodes || []);
      for (const option of form.elements.namedItem('requiredCodes').options)
        option.selected = required.has(option.value);
      form.elements.namedItem('verified').checked =
        item.config.status === 'verified' && item.config.intake === 2028;
      form.elements.namedItem('name').readOnly = true;
      form.elements.namedItem('program').readOnly = true;
      document.querySelector('#offering-submit').textContent =
        'Update offering';
      document.querySelector('#offering-cancel').hidden = false;
      form.scrollIntoView?.({ block: 'start', behavior: 'smooth' });
    }),
  );
  document.querySelector('#offering-cancel').addEventListener('click', () => {
    selectedPolicy = null;
    editing = null;
    form.reset();
    syncScoring();
    form.elements.namedItem('name').readOnly = false;
    form.elements.namedItem('program').readOnly = false;
    document.querySelector('#offering-submit').textContent = 'Save offering';
    document.querySelector('#offering-cancel').hidden = true;
  });
}

function validateFormControl(control) {
  if (
    !control.matches('input, textarea, select') ||
    control.disabled ||
    control.readOnly ||
    control.type === 'file'
  )
    return;
  control.setCustomValidity('');
  const value = control.value;
  if (control.required && !value.trim())
    control.setCustomValidity(
      'Complete this field. Spaces alone are not valid.',
    );
  if (
    ['firstName', 'lastName'].includes(control.name) &&
    value &&
    !personNamePatternUi.test(value.trim())
  )
    control.setCustomValidity(
      'Use letters, spaces, apostrophes or hyphens for names. Numbers and other symbols are not allowed.',
    );
  if (control.name === 'saIdNumber' && !isValidSouthAfricanIdNumberUi(value))
    control.setCustomValidity(
      'Enter a valid South African ID number with a valid, non-future date.',
    );
  const limits = {
    firstName: 100,
    lastName: 100,
    email: 100,
    phone: 10,
    saIdNumber: 13,
    source: 255,
    SCHOOL_NAME: 150,
    EMIS_NUMBER: 30,
    UNIVERSITY_NAME: 150,
    WEBSITE: 255,
    STREET_NAME: 150,
    CITY_NAME: 100,
    PROVINCE_NAME: 50,
    SUBJECT_NAME: 100,
    SUBJECT_CODE: 20,
    EXAM_TYPE_NAME: 50,
    STUDY_MODE_NAME: 50,
    notes: 400,
  };
  if (limits[control.name]) {
    control.maxLength = limits[control.name];
    if (value.length > limits[control.name])
      control.setCustomValidity(
        'Use at most ' + limits[control.name] + ' characters.',
      );
  }
  if (['source', 'WEBSITE'].includes(control.name) && value) {
    try {
      const url = new URL(value);
      if (
        url.protocol !== 'https:' ||
        !url.hostname.includes('.') ||
        url.username ||
        url.password ||
        /\s/.test(value)
      )
        throw Error();
    } catch {
      control.setCustomValidity(
        'Enter a complete HTTPS URL, for example https://www.university.ac.za.',
      );
    }
  }
  if (
    control.name === 'SUBJECT_CODE' &&
    value &&
    !/^[A-Z][A-Z0-9_-]{0,19}$/.test(value)
  )
    control.setCustomValidity(
      'Use an uppercase subject code beginning with a letter.',
    );
}
export async function startFullApp() {
  document.addEventListener('input', (event) =>
    validateFormControl(event.target),
  );
  document.addEventListener('change', (event) =>
    validateFormControl(event.target),
  );
  document.addEventListener(
    'submit',
    (event) => {
      const form = event.target;
      if (!form.matches('form')) return;
      form
        .querySelectorAll('input, textarea, select')
        .forEach(validateFormControl);
      if (
        [...form.querySelectorAll('input, textarea, select')].some((control) =>
          control.type === 'file'
            ? control.required && !control.files?.length
            : !control.checkValidity(),
        )
      ) {
        event.preventDefault();
        event.stopImmediatePropagation();
        form.reportValidity();
      }
    },
    true,
  );
  const toggle = document.querySelector('#sidebar-toggle');
  toggle?.addEventListener('click', () => {
    const mobile = window.matchMedia('(max-width: 700px)').matches;
    const state = document.body.classList.toggle(
      mobile ? 'nav-open' : 'nav-collapsed',
    );
    toggle.setAttribute('aria-expanded', String(mobile ? state : !state));
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      document.body.classList.remove('nav-open');
      toggle?.setAttribute('aria-expanded', 'false');
    }
  });
  document.querySelector('#navigation')?.addEventListener('click', (e) => {
    if (
      e.target.closest('a') &&
      window.matchMedia('(max-width: 700px)').matches
    ) {
      document.body.classList.remove('nav-open');
      toggle?.setAttribute('aria-expanded', 'false');
    }
  });
  document.querySelector('.shell')?.addEventListener('click', (e) => {
    if (
      document.body.classList.contains('nav-open') &&
      e.target === e.currentTarget
    ) {
      document.body.classList.remove('nav-open');
      toggle?.setAttribute('aria-expanded', 'false');
    }
  });
  try {
    if (page === 'login') {
      await login();
      document.body.dataset.ready = 'true';
      return;
    }
    // Cosmetic public settings must not gate authentication or the workspace.
    void api('/api/public-config')
      .then((config) => {
        supportEmail = config.supportEmail || '';
        emailEnabled = config.emailEnabled === true;
      })
      .catch(() => {});
    try {
      const me = await api('/api/me');
      user = me.user;
      csrf = me.csrf;
    } catch (e) {
      if (e.status === 401) {
        location.replace('/login.html');
        return;
      }
      throw e;
    }
    if (!user || !Object.hasOwn(navigationGroups, user.role)) {
      throw new Error(
        'Your account has no supported portal role. Contact your IT administrator.',
      );
    }
    const declared = document.body.dataset.role;
    if (declared !== user.role) {
      location.replace('/' + user.role + '/overview.html');
      return;
    }
    shell();
    markPathwayVisit();
    show(
      title('Loading your workspace', 'Loading your role-specific records…'),
    );
    catalog = await request('/api/catalog');
    if (page === 'overview') await dashboard();
    else if (page === 'profile') await profile();
    else if (page === 'results' || page === 'verification') await resultsPage();
    else if (page === 'requirements') await requirements();
    else if (page === 'university') await universityProfile();
    else if (page === 'documents') await documentsPage();
    else if (page === 'applications' || page === 'decisions')
      await applicationsPage();
    else if (
      page === 'universities' ||
      page === 'directories' ||
      page === 'policies'
    )
      await directory();
    else if (page === 'accounts') await accounts();
    else if (page === 'offerings') await offeringAdmin();
    else if (page === 'prospectuses') await prospectuses();
    else if (page === 'audit') {
      const out = await request('/api/admin/audit');
      show(
        title(
          'Audit History',
          'Account, verification and application actions are recorded with UTC timestamps.',
        ) +
          /* HTML */ `
            <section class="panel">
              ${table(
                ['Time', 'Account', 'Action', 'Summary'],
                out.events.map(
                  (v) => /* HTML */ `
                    <tr>
                      <td>${esc(v.CREATED_AT)}</td>
                      <td>${esc(v.actor || 'System')}</td>
                      <td>${esc(auditAction(v.EVENT))}</td>
                      <td>${esc(auditDetail(v.DETAIL))}</td>
                    </tr>
                  `,
                ),
              )}
            </section>
          `,
      );
    } else if (page === 'learners') {
      const out = await request('/api/teacher/learners');
      show(
        title('My Learners', 'Learners enrolled at your school.') +
          /* HTML */ `
            <section class="panel">
              ${table(
                ['Name', 'Email'],
                out.learners.map(
                  (l) => /* HTML */ `
                    <tr>
                      <td>${esc(l.name)}</td>
                      <td>${esc(l.email)}</td>
                    </tr>
                  `,
                ),
              )}
            </section>
          `,
      );
    } else if (page === 'subjects') await subjectsPage();
    else if (page === 'lookups') await academicRecords();
    else show(title('Workspace', 'Select a page from the navigation.'));
    document.body.dataset.ready = 'true';
  } catch (error) {
    if (error.status === 401 && page !== 'login') {
      location.replace('/login.html');
      return;
    }
    show(
      title('Unable to load workspace', error.message) +
        '<button id="reload-workspace" type="button">Try again</button> <a href="/login.html">Back to sign in</a>',
    );
    document
      .querySelector('#reload-workspace')
      .addEventListener('click', () => location.reload());
  }
}
