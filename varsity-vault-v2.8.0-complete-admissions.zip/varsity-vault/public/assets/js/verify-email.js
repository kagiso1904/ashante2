import { api } from './api.js';
const button = document.querySelector('#verify-button'),
  feedback = document.querySelector('#feedback'),
  token = new URLSearchParams(location.search).get('token') || '';
button.addEventListener('click', async () => {
  button.disabled = true;
  try {
    const result = await api('/api/auth/email/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token }),
    });
    feedback.textContent = result.message;
    button.hidden = true;
  } catch (error) {
    feedback.textContent = error.message;
  } finally {
    button.disabled = false;
  }
});
