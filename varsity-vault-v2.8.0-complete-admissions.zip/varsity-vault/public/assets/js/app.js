// Catch module/import failures as well as rejected startup work. A broken import
// previously left the original "Loading workspace" HTML on screen indefinitely.
function startupFailure() {
  const main = document.querySelector('#main');
  if (!main) return;
  document.body.dataset.ready = 'error';
  const heading = document.createElement('h1');
  heading.textContent = 'Unable to start your workspace';
  const message = document.createElement('p');
  message.textContent =
    'The application files could not be loaded. Confirm the server is running, then reload. If you have just updated Varsity Vault, press Ctrl+Shift+R.';
  const retry = document.createElement('button');
  retry.type = 'button';
  retry.textContent = 'Reload workspace';
  retry.addEventListener('click', () => location.reload());
  const home = document.createElement('a');
  home.href = '/';
  home.textContent = 'Back to home';
  main.replaceChildren(
    heading,
    message,
    retry,
    document.createTextNode(' '),
    home,
  );
}
const importTimer = setTimeout(startupFailure, 15000);
import('./full.js?v=2.8.0')
  .then(({ startFullApp }) => {
    clearTimeout(importTimer);
    return startFullApp();
  })
  .catch(() => {
    clearTimeout(importTimer);
    startupFailure();
  });
